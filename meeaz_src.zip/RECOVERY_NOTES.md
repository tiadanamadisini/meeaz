# Nota pemulihan — MeeazProject

Projek ini dipulihkan daripada `Meeaz_Project.apk` (debug build). Kod Dart `lib/` adalah SALINAN TEPAT
fail asal (siap komen), sebab debug APK menyimpan teks sumber dalam `kernel_blob.bin`.

## Yang dipulihkan
- Semua fail `lib/**/*.dart` (53 fail), assets (`assets/`, `.env`)
- `pubspec.yaml` DIBINA SEMULA: senarai package + versi diambil daripada jejak pub-cache dalam APK.
  `model_viewer_plus`, `webview_flutter`, `cupertino_icons` versi `any` (tak dapat dikesan) - jalankan `flutter pub get`.
  Kalau ada error import hilang, tambah package berkenaan.

## Yang TIDAK dapat dipulihkan (kena buat semula)
- Folder `android/` (Kotlin/Java native). Bina semula dengan:
    flutter create --org com.meeaz --project-name MeeazProject .
  Application ID asal: `com.meeaz.app` (set dalam android/app/build.gradle)
- Native Kotlin: `com.meeaz.app.ForexGraphHostActivity` + MethodChannel `com.meeaz.app/forex_graph`
  (dipanggil dari lib/monetary/services/forex_graph_bridge.dart). Guna Filament/gltfio. Kod native ini cuma wujud
  sebagai bytecode dalam classes*.dex -> boleh decompile dengan jadx, tapi hasilnya bukan kod asal.
- Keystore / signing key, README, test, git history.

## Permission Android asal (letak dalam AndroidManifest.xml)
INTERNET, ACCESS_NETWORK_STATE, CAMERA, RECORD_AUDIO, MODIFY_AUDIO_SETTINGS, POST_NOTIFICATIONS, VIBRATE,
USE_BIOMETRIC, USE_FINGERPRINT, READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE, READ_MEDIA_IMAGES

## Langkah seterusnya
1. flutter create (lihat atas), salin `lib/`, `assets/`, `.env`, `pubspec.yaml` ke dalam
2. flutter pub get && flutter analyze
3. PERCAYA: `.env` mengandungi BACKEND_URL (dan mungkin rahsia lain) - jangan push ke git awam.
