#!/usr/bin/env python3
"""Lengkapkan folder android/ yang dijana `flutter create` supaya sama dengan app Meeaz asal.

- applicationId com.meeaz.app (sama dengan app asal)
- minSdk 24, desugaring (flutter_local_notifications), permission asal
- MainActivity guna FlutterFragmentActivity (diperlukan local_auth / cap jari)
"""
import pathlib, re, sys

root = pathlib.Path(__file__).resolve().parent.parent / 'android'
app = root / 'app'

# ---- build.gradle(.kts) ----
kts = app / 'build.gradle.kts'
groovy = app / 'build.gradle'
if kts.exists():
    g = kts.read_text()
    g = re.sub(r'applicationId\s*=\s*"[^"]*"', 'applicationId = "com.meeaz.app"', g)
    g = re.sub(r'minSdk\s*=\s*[^\n]+', 'minSdk = 24', g)
    if 'isCoreLibraryDesugaringEnabled' not in g:
        g = re.sub(r'compileOptions\s*\{', 'compileOptions {\n        isCoreLibraryDesugaringEnabled = true', g, count=1)
    if 'desugar_jdk_libs' not in g:
        g += '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
    kts.write_text(g)
    print('patched', kts)
elif groovy.exists():
    g = groovy.read_text()
    g = re.sub(r'applicationId\s+"[^"]*"', 'applicationId "com.meeaz.app"', g)
    g = re.sub(r'applicationId\s*=\s*"[^"]*"', 'applicationId = "com.meeaz.app"', g)
    g = re.sub(r'minSdk(Version)?\s*=?\s*[^\n]+', 'minSdkVersion 24', g)
    if 'coreLibraryDesugaringEnabled' not in g:
        g = re.sub(r'compileOptions\s*\{', 'compileOptions {\n        coreLibraryDesugaringEnabled true', g, count=1)
    if 'desugar_jdk_libs' not in g:
        g += "\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n}\n"
    groovy.write_text(g)
    print('patched', groovy)
else:
    sys.exit('build.gradle tak dijumpai')

# ---- AndroidManifest.xml ----
man = app / 'src' / 'main' / 'AndroidManifest.xml'
m = man.read_text()
perms = ['INTERNET', 'ACCESS_NETWORK_STATE', 'CAMERA', 'RECORD_AUDIO', 'MODIFY_AUDIO_SETTINGS',
         'POST_NOTIFICATIONS', 'VIBRATE', 'USE_BIOMETRIC', 'USE_FINGERPRINT', 'READ_EXTERNAL_STORAGE',
         'READ_MEDIA_IMAGES']
lines = ''.join(f'    <uses-permission android:name="android.permission.{p}"/>\n' for p in perms if p not in m)
lines += '    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28"/>\n'
m = re.sub(r'(<manifest[^>]*>\s*\n)', r'\1' + lines.replace('\\', r'\\'), m, count=1)
m = m.replace('android:label="meeaz_project"', 'android:label="Meeaz Project"')
if 'android:hardwareAccelerated' not in m:
    m = m.replace('<application', '<application\n        android:hardwareAccelerated="true"', 1)
man.write_text(m)
print('patched', man)

# ---- MainActivity: FlutterFragmentActivity (local_auth) ----
for f in (app / 'src' / 'main').rglob('MainActivity.*'):
    t = f.read_text()
    t = t.replace('io.flutter.embedding.android.FlutterActivity', 'io.flutter.embedding.android.FlutterFragmentActivity')
    t = re.sub(r'\bFlutterActivity\b', 'FlutterFragmentActivity', t)
    f.write_text(t)
    print('patched', f)

# ---- ikon asal Meeaz ----
import shutil
icons = pathlib.Path(__file__).resolve().parent / 'icons'
for d in icons.glob('mipmap-*'):
    dst = app / 'src' / 'main' / 'res' / d.name
    dst.mkdir(parents=True, exist_ok=True)
    shutil.copy(d / 'ic_launcher.png', dst / 'ic_launcher.png')
    print('ikon', d.name)

# ---- jalankan build + simpan log (dalam GitHub Actions) ----
import subprocess, os
if os.environ.get('GITHUB_ACTIONS'):
    rc = subprocess.call(['bash', str(pathlib.Path(__file__).resolve().parent / 'run_build.sh')])
    if rc != 0:
        sys.exit(rc)
