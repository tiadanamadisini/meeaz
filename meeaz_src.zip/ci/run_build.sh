#!/bin/bash
# Dipanggil dari patch_android.py dalam GitHub Actions.
# Build APK + simpan log ke branch 'logs' (supaya boleh dibaca tanpa buka Actions).
cd "$(dirname "$0")/.."
LOG=/tmp/meeaz_build.log
(
  set -ex
  flutter --version
  flutter pub get
  flutter analyze --no-fatal-infos --no-fatal-warnings 2>&1 | grep -E " error " || true
  flutter build apk --release --target-platform android-arm64
) > "$LOG" 2>&1
RC=$?
tail -c 60000 "$LOG"

if [ -n "$GITHUB_WORKSPACE" ]; then
  H=$(cd "$GITHUB_WORKSPACE" && git config --get http.https://github.com/.extraheader)
  T=$(mktemp -d)
  cp "$LOG" "$T/log.txt"
  echo "rc=$RC run=$GITHUB_RUN_NUMBER" > "$T/status.txt"
  (
    cd "$T" && git init -q && git checkout -q -b logs && git add . &&
    git -c user.name=meeaz-bot -c user.email=bot@users.noreply.github.com commit -q -m "log run $GITHUB_RUN_NUMBER rc=$RC" &&
    git -c "http.https://github.com/.extraheader=$H" push -q -f "https://github.com/$GITHUB_REPOSITORY.git" HEAD:logs
  ) || echo "gagal simpan log ke branch"
fi
exit $RC
