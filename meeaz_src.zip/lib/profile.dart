import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'theme/app_theme.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final TextEditingController _namaController = TextEditingController();
  final TextEditingController _lamaController = TextEditingController();
  final TextEditingController _baruController = TextEditingController();
  final TextEditingController _sahkanController = TextEditingController();
  final ImagePicker _imagePicker = ImagePicker();

  bool _sedangMuat = true;
  String? _gambarPengguna;

  static const Color _roseAccent = AppColors.brand;

  Color get _inkText => Theme.of(context).colorScheme.onSurface;

  @override
  void initState() {
    super.initState();
    _muatNama();
  }

  Future<void> _muatNama() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _namaController.text =
          prefs.getString('nama_pengguna') ?? 'Pengguna Meeaz';
      _gambarPengguna = prefs.getString('gambar_pengguna');
      _sedangMuat = false;
    });
  }

  Future<void> _pilihGambar() async {
    final file = await _imagePicker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 85,
      maxWidth: 900,
    );
    if (file == null) return;
    final bytes = await file.readAsBytes();
    final encoded = base64Encode(bytes);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('gambar_pengguna', encoded);
    if (mounted) {
      setState(() => _gambarPengguna = encoded);
      _tunjukMesej('Gambar profile berjaya disimpan.');
    }
  }

  Future<void> _simpanNama() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('nama_pengguna', _namaController.text);
    _tunjukMesej('Nama berjaya disimpan!');
    if (mounted) FocusScope.of(context).unfocus();
  }

  Future<void> _tukarKataLaluan() async {
    final prefs = await SharedPreferences.getInstance();
    final kataLaluanSemasa = prefs.getString('kata_laluan') ?? '0000';

    if (_lamaController.text != kataLaluanSemasa) {
      _tunjukMesej('Kata laluan lama salah.');
      return;
    }
    final hasLetter = RegExp(r'[a-zA-Z]').hasMatch(_baruController.text);
    final hasNumber = RegExp(r'[0-9]').hasMatch(_baruController.text);

    if (_baruController.text.length < 8 || !hasLetter || !hasNumber) {
      _tunjukMesej(
          'Password baharu mesti sekurang-kurangnya 8 aksara, mengandungi huruf dan nombor.');
      return;
    }
    if (_baruController.text != _sahkanController.text) {
      _tunjukMesej('Pengesahan tidak sepadan.');
      return;
    }

    await prefs.setString('kata_laluan', _baruController.text);
    _lamaController.clear();
    _baruController.clear();
    _sahkanController.clear();
    if (mounted) FocusScope.of(context).unfocus();
    _tunjukMesej('Kata laluan berjaya ditukar!');
  }

  void _tunjukMesej(String mesej) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(mesej),
        backgroundColor: _inkText,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  @override
  void dispose() {
    _namaController.dispose();
    _lamaController.dispose();
    _baruController.dispose();
    _sahkanController.dispose();
    super.dispose();
  }

  InputDecoration _fieldDecoration(
      BuildContext context, String label, IconData icon) {
    final textColor = Theme.of(context).colorScheme.onSurface;
    return InputDecoration(
      labelText: label,
      labelStyle: TextStyle(color: textColor.withValues(alpha: 0.55)),
      prefixIcon:
          Icon(icon, color: textColor.withValues(alpha: 0.45), size: 20),
      filled: true,
      fillColor: Theme.of(context).colorScheme.surface,
      contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(AppRadius.lg),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(AppRadius.lg),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(AppRadius.lg),
        borderSide: const BorderSide(color: _roseAccent, width: 1.4),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ImageProvider<Object> gambarProfile;
    if (_gambarPengguna == null) {
      gambarProfile = const AssetImage('assets/pfp.jpg');
    } else {
      gambarProfile = MemoryImage(base64Decode(_gambarPengguna!));
    }

    return Container(
      child: _sedangMuat
          ? const Scaffold(
              backgroundColor: Colors.transparent,
              body:
                  Center(child: CircularProgressIndicator(color: _roseAccent)),
            )
          : Scaffold(
              backgroundColor: Colors.transparent,
              body: SafeArea(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(20, 28, 20, 32),
                  child: Column(
                    children: [
                      Stack(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Theme.of(context)
                                    .colorScheme
                                    .outlineVariant,
                              ),
                            ),
                            child: CircleAvatar(
                              radius: 52,
                              backgroundImage: gambarProfile,
                            ),
                          ),
                          Positioned(
                            right: 0,
                            bottom: 0,
                            child: IconButton(
                              onPressed: _pilihGambar,
                              tooltip: 'Tukar gambar profile',
                              icon: const Icon(Icons.camera_alt_rounded),
                              color: Colors.white,
                              style: IconButton.styleFrom(
                                  backgroundColor: _roseAccent),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        _namaController.text,
                        style: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.w700,
                          color: Theme.of(context).colorScheme.onSurface,
                        ),
                      ),
                      const SizedBox(height: 32),
                      _SectionCard(
                        title: 'Nama Panggilan',
                        children: [
                          TextField(
                            controller: _namaController,
                            style: TextStyle(
                                color: Theme.of(context).colorScheme.onSurface),
                            decoration: _fieldDecoration(
                                context, 'Nama', Icons.person_outline),
                          ),
                          const SizedBox(height: 14),
                          _PrimaryButton(
                            label: 'Simpan Nama',
                            onTap: _simpanNama,
                            color: _roseAccent,
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      _SectionCard(
                        title: 'Tukar Kata Laluan',
                        children: [
                          TextField(
                            controller: _lamaController,
                            obscureText: true,
                            style: TextStyle(
                                color: Theme.of(context).colorScheme.onSurface),
                            decoration: _fieldDecoration(context,
                                'Kata Laluan Lama', Icons.lock_outline),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: _baruController,
                            obscureText: true,
                            style: TextStyle(
                                color: Theme.of(context).colorScheme.onSurface),
                            decoration: _fieldDecoration(
                                context, 'Kata Laluan Baru', Icons.lock),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: _sahkanController,
                            obscureText: true,
                            style: TextStyle(
                                color: Theme.of(context).colorScheme.onSurface),
                            decoration: _fieldDecoration(
                                context, 'Sahkan Kata Laluan', Icons.lock),
                          ),
                          const SizedBox(height: 14),
                          _PrimaryButton(
                            label: 'Tukar Kata Laluan',
                            onTap: _tukarKataLaluan,
                            color: _inkText,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
}

/// Kad rata dengan tajuk kecil di atas — bungkus setiap seksyen supaya
/// tak nampak macam borang panjang tanpa struktur.
class _SectionCard extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _SectionCard({required this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(color: Theme.of(context).colorScheme.outlineVariant),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Theme.of(context).colorScheme.onSurface,
            ),
          ),
          const SizedBox(height: 14),
          ...children,
        ],
      ),
    );
  }
}

/// Butang penuh lebar dengan sudut bulat lembut, konsisten dengan
/// butang hantar dalam chat screen.
class _PrimaryButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final Color color;

  const _PrimaryButton({
    required this.label,
    required this.onTap,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          elevation: 0,
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
        child: Text(
          label,
          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
        ),
      ),
    );
  }
}
