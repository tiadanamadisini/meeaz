import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:local_auth/local_auth.dart';
import 'package:internet_connection_checker_plus/internet_connection_checker_plus.dart';
import 'dart:ui';

import 'home.dart';
import 'profile.dart';
import 'screens/chat_screen.dart';
import 'screens/translation_screen.dart';
import 'settings.dart';
import 'theme/app_theme.dart';

// Palet sama seperti chat/home/profile — satu identiti visual seluruh app.
const Color _bgTop = AppColors.background;
const Color _bgBottom = AppColors.surfaceAlt;
const Color _inkText = AppColors.textPrimary;
const Color _roseAccent = AppColors.brand;
final ValueNotifier<ThemeMode> appThemeMode = ValueNotifier(ThemeMode.light);
final ValueNotifier<String> appLanguage = ValueNotifier('Bahasa Melayu');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Enable Edge-to-Edge support - membuang bar hitam di atas dan bawah.
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
    systemNavigationBarColor: Colors.transparent,
    systemNavigationBarIconBrightness: Brightness.dark,
  ));

  await dotenv.load(fileName: ".env");
  final prefs = await SharedPreferences.getInstance();
  appThemeMode.value =
      prefs.getBool('dark_mode') == true ? ThemeMode.dark : ThemeMode.light;
  appLanguage.value = prefs.getString('bahasa_aplikasi') ?? 'Bahasa Melayu';
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  bool _appTidakAktif = false;
  bool _tiadaInternet = false;
  StreamSubscription<InternetStatus>? _internetSubscription;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    // Pastikan mod Edge-to-Edge aktif secara konsisten
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

    _semakInternet();
    _internetSubscription =
        InternetConnection().onStatusChange.listen((status) {
      if (!mounted) return;
      setState(() => _tiadaInternet = status == InternetStatus.disconnected);
    });
  }

  Future<void> _semakInternet() async {
    final adaInternet = await InternetConnection().hasInternetAccess;
    if (mounted) setState(() => _tiadaInternet = !adaInternet);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _internetSubscription?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    setState(() {
      _appTidakAktif = state == AppLifecycleState.inactive ||
          state == AppLifecycleState.paused;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: appThemeMode,
      builder: (context, mode, _) => MaterialApp(
        debugShowCheckedModeBanner: false,
        themeMode: mode,
        theme: AppTheme.light,
        darkTheme: AppTheme.dark,
        builder: (context, child) {
          // Memastikan ikon status bar bertukar warna ikut tema (Light/Dark)
          final isDark = Theme.of(context).brightness == Brightness.dark;
          return AnnotatedRegion<SystemUiOverlayStyle>(
            value: SystemUiOverlayStyle(
              statusBarColor: Colors.transparent,
              statusBarIconBrightness:
                  isDark ? Brightness.light : Brightness.dark,
              systemNavigationBarColor: Colors.transparent,
              systemNavigationBarIconBrightness:
                  isDark ? Brightness.light : Brightness.dark,
              systemNavigationBarContrastEnforced: false,
              statusBarBrightness: isDark ? Brightness.dark : Brightness.light,
            ),
            child: Stack(
              children: [
                if (child != null) child,
                if (_tiadaInternet) const _TiadaInternetPanel(),
              ],
            ),
          );
        },
        home: Stack(
          children: [
            const SplashScreen(),
            if (_appTidakAktif)
              Positioned.fill(
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                  child: Container(
                    color: _inkText.withValues(alpha: 0.45),
                    child: const Center(
                      child: Icon(
                        Icons.lock_outline_rounded,
                        color: Colors.white,
                        size: 44,
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _TiadaInternetPanel extends StatelessWidget {
  const _TiadaInternetPanel();

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Positioned.fill(
      child: Material(
        color: colors.scrim.withValues(alpha: 0.48),
        child: Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            height: MediaQuery.of(context).size.height * 0.5,
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(28, 34, 28, 28),
            decoration: BoxDecoration(
              color: colors.surface,
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(30),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.2),
                  blurRadius: 24,
                  offset: const Offset(0, -8),
                ),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: colors.errorContainer,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.wifi_off_rounded,
                    size: 42,
                    color: colors.onErrorContainer,
                  ),
                ),
                const SizedBox(height: 22),
                Text(
                  'Tiada jaringan internet',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: colors.onSurface,
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  'No network\nSila hidupkan Wi-Fi atau data mudah alih. Panel ini akan tertutup secara automatik apabila internet kembali.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: colors.onSurface.withValues(alpha: 0.65),
                    fontSize: 14,
                    height: 1.45,
                  ),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: 42,
                  height: 4,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      color: colors.outlineVariant,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// 1. Splash Screen
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    _fadeAnimation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeIn,
    );

    _scaleAnimation = Tween<double>(begin: 0.7, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutBack),
    );

    _controller.forward();

    Future.delayed(const Duration(seconds: 3), () async {
      if (!mounted) return;
      final prefs = await SharedPreferences.getInstance();
      if (!mounted) return;
      final adaPassword = prefs.containsKey('kata_laluan');
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => adaPassword
              ? const LoginScreen()
              : const TutorialScreen(requirePassword: true),
        ),
      );
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF4A3630),
              Color(0xFF6B4E44),
              _roseAccent,
            ],
          ),
        ),
        child: Center(
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: ScaleTransition(
              scale: _scaleAnimation,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white24, width: 2),
                    ),
                    child: ClipOval(
                      child: Image.asset(
                        "assets/pfp.jpg",
                        width: 100,
                        height: 100,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  const Text(
                    'Meeaz Project',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.2,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Created by MEEAZ',
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.72),
                      fontSize: 12,
                      letterSpacing: 1.1,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 40),
                  SizedBox(
                    width: 120,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: const LinearProgressIndicator(
                        backgroundColor: Colors.white24,
                        color: Colors.white,
                        minHeight: 4,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// 2. Login Screen
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _kataLaluanController = TextEditingController();
  final LocalAuthentication _localAuth = LocalAuthentication();
  bool _sedangProses = true;
  bool _biometrikTersedia = false;

  @override
  void initState() {
    super.initState();
    _pastikanKataLaluanWujud();
    _semakBiometrik().then((_) => _autoBukaBiometrik());
  }

  Future<void> _semakBiometrik() async {
    try {
      final tersedia = await _localAuth.canCheckBiometrics ||
          await _localAuth.isDeviceSupported();
      if (mounted) setState(() => _biometrikTersedia = tersedia);
    } catch (_) {}
  }

  Future<void> _autoBukaBiometrik() async {
    final prefs = await SharedPreferences.getInstance();
    final aktif = prefs.getBool('biometrik_aktif') ?? false;
    if (aktif && _biometrikTersedia) {
      _bukaDenganBiometrik(auto: true);
    }
  }

  Future<void> _bukaDenganBiometrik({bool auto = false}) async {
    final prefs = await SharedPreferences.getInstance();
    final sudahTunjukRationale =
        prefs.getBool('biometrik_rationale_dilihat') ?? false;

    if (!sudahTunjukRationale && !auto) {
      bool donotshow = false;
      final proceed = await showDialog<bool>(
        context: context,
        builder: (ctx) => StatefulBuilder(
          builder: (context, setDialogState) => AlertDialog(
            title: const Text('Pengesahan Biometrik'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                    'Kami menggunakan biometrik peranti anda (cap jari/muka) untuk memastikan hanya anda yang boleh mengakses aplikasi ini dengan selamat.'),
                const SizedBox(height: 12),
                CheckboxListTile(
                  title: const Text('Jangan paparkan lagi',
                      style: TextStyle(fontSize: 14)),
                  value: donotshow,
                  onChanged: (val) =>
                      setDialogState(() => donotshow = val ?? false),
                  controlAffinity: ListTileControlAffinity.leading,
                  contentPadding: EdgeInsets.zero,
                ),
              ],
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: const Text('Batal')),
              TextButton(
                onPressed: () async {
                  if (donotshow)
                    await prefs.setBool('biometrik_rationale_dilihat', true);
                  Navigator.pop(ctx, true);
                },
                child: const Text('Teruskan'),
              ),
            ],
          ),
        ),
      );
      if (proceed != true) return;
    }

    try {
      final berjaya = await _localAuth.authenticate(
        localizedReason: 'Sahkan identiti untuk buka Meeaz Project',
        options: const AuthenticationOptions(
          biometricOnly: false,
          stickyAuth: true,
          useErrorDialogs: true,
        ),
      );
      if (berjaya && mounted) {
        _masukKeAplikasi();
      }
    } catch (_) {
      if (!auto && mounted) _tunjukDialogSalahDanKeluar();
    }
  }

  Future<void> _pastikanKataLaluanWujud() async {
    if (!mounted) return;
    setState(() {
      _sedangProses = false;
    });
  }

  Future<void> _semakKataLaluan() async {
    final prefs = await SharedPreferences.getInstance();
    final kataLaluanTersimpan = prefs.getString('kata_laluan') ?? '0000';

    if (_kataLaluanController.text == kataLaluanTersimpan) {
      if (mounted) {
        _masukKeAplikasi();
      }
    } else {
      _tunjukDialogSalahDanKeluar();
    }
  }

  Future<void> _masukKeAplikasi() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    final sudahLihatTutorial = prefs.getBool('tutorial_sudah_dilihat') == true;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => sudahLihatTutorial
            ? const HalamanNavigasiUtama()
            : const TutorialScreen(),
      ),
    );
  }

  void _tunjukDialogSalahDanKeluar() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          backgroundColor: _bgTop,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
          title: const Text('Kata Laluan Salah',
              style: TextStyle(color: _inkText, fontWeight: FontWeight.w700)),
          content: Text('Aplikasi akan ditutup.',
              style: TextStyle(color: _inkText.withValues(alpha: 0.7))),
          actions: [
            TextButton(
              onPressed: () {
                SystemNavigator.pop();
              },
              child: const Text('Keluar', style: TextStyle(color: _roseAccent)),
            ),
          ],
        );
      },
    );
  }

  @override
  void dispose() {
    _kataLaluanController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_sedangProses) {
      return const Scaffold(
        backgroundColor: _bgTop,
        body: Center(child: CircularProgressIndicator(color: _roseAccent)),
      );
    }

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [_bgTop, _bgBottom],
          ),
        ),
        child: Stack(
          children: [
            SafeArea(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 30),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: _roseAccent.withValues(alpha: 0.2),
                              blurRadius: 20,
                              offset: const Offset(0, 8),
                            ),
                          ],
                        ),
                        child: const Icon(Icons.lock_outline_rounded,
                            color: _roseAccent, size: 40),
                      ),
                      const SizedBox(height: 24),
                      const Text(
                        'Masukkan Kata Laluan',
                        style: TextStyle(
                          color: _inkText,
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 24),
                      TextField(
                        controller: _kataLaluanController,
                        obscureText: true,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: _inkText,
                          fontSize: 18,
                          letterSpacing: 4,
                        ),
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none,
                          ),
                          hintText: 'Taip password anda',
                          hintStyle: TextStyle(
                              color: _inkText.withValues(alpha: 0.3),
                              letterSpacing: 0,
                              fontSize: 14),
                          contentPadding:
                              const EdgeInsets.symmetric(vertical: 16),
                        ),
                      ),
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: _semakKataLaluan,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _roseAccent,
                            foregroundColor: Colors.white,
                            elevation: 0,
                            padding: const EdgeInsets.symmetric(vertical: 15),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                          child: const Text('Masuk',
                              style: TextStyle(fontWeight: FontWeight.w600)),
                        ),
                      ),
                      if (_biometrikTersedia) ...[
                        const SizedBox(height: 12),
                        TextButton.icon(
                          onPressed: _bukaDenganBiometrik,
                          icon: const Icon(Icons.fingerprint_rounded),
                          label: const Text('Buka dengan biometrik / peranti'),
                          style: TextButton.styleFrom(
                              foregroundColor: _roseAccent),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TutorialScreen extends StatefulWidget {
  final bool requirePassword;

  const TutorialScreen({super.key, this.requirePassword = false});

  @override
  State<TutorialScreen> createState() => _TutorialScreenState();
}

class _TutorialScreenState extends State<TutorialScreen> {
  final _pageController = PageController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  int _page = 0;

  static const _slides = [
    (
      'Selamat datang',
      'Berbual dengan Kaoruko Waguri, kawan sembang awak yang sentiasa ada.',
      Icons.chat_bubble_rounded
    ),
    (
      'Mini-Games Bersama',
      'Main game quiz atau puzzle dengan Kaoruko untuk uji sejauh mana awak kenal dia!',
      Icons.videogame_asset_rounded
    ),
    (
      'AI Selfie Mode',
      'Jana gambar selfie bersama Kaoruko mengikut waktu peranti—pagi, petang, atau malam.',
      Icons.camera_enhance_rounded
    ),
    (
      'Voice Call Intim',
      'Alami panggilan suara simulasi dengan Kaoruko untuk rasa lebih dekat.',
      Icons.call_rounded
    ),
    (
      'Live Widget & Wallpaper',
      'Kaoruko sentiasa ada di Home Screen anda melalui widget interaktif dan wallpaper.',
      Icons.wallpaper_rounded
    ),
    (
      'Live Translate Kamera',
      'Imbas dan terjemah teks secara langsung guna kamera, macam Google Lens!',
      Icons.translate_rounded
    ),
    (
      'Belajar & Dokumen',
      'Hantar PDF/PPTX untuk study bersama. Kaoruko akan bantu terangkan kandungan dokumen.',
      Icons.school_rounded
    ),
    (
      'Simpan Highlight',
      'Upload gambar dari Home, tambah description, dan simpan memori indah awak.',
      Icons.add_photo_alternate_rounded
    ),
    (
      'Data Peribadi Selamat',
      'Semua chat disimpan secara lokal. Awak boleh export dan import data bila-bila masa.',
      Icons.lock_rounded
    ),
  ];

  Future<void> _selesai() async {
    if (widget.requirePassword) {
      final password = _passwordController.text;
      final confirmation = _confirmPasswordController.text;

      final hasLetter = RegExp(r'[a-zA-Z]').hasMatch(password);
      final hasNumber = RegExp(r'[0-9]').hasMatch(password);

      if (password.length < 8 || !hasLetter || !hasNumber) {
        _tunjukMesej(
            'Password mesti sekurang-kurangnya 8 aksara, mengandungi huruf dan nombor.');
        return;
      }
      if (password != confirmation) {
        _tunjukMesej('Password dan pengesahan tidak sepadan.');
        return;
      }
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('kata_laluan', password);
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('tutorial_sudah_dilihat', true);
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const HalamanNavigasiUtama()),
    );
  }

  @override
  void dispose() {
    _pageController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  void _tunjukMesej(String mesej) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(mesej)));
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.topRight,
              child: widget.requirePassword
                  ? const SizedBox(height: 48)
                  : TextButton(onPressed: _selesai, child: const Text('Skip')),
            ),
            Expanded(
              child: PageView.builder(
                controller: _pageController,
                itemCount: _slides.length,
                onPageChanged: (value) => setState(() => _page = value),
                itemBuilder: (context, index) {
                  final slide = _slides[index];
                  return Padding(
                    padding: const EdgeInsets.all(30),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(28),
                          decoration: BoxDecoration(
                            color: colors.primaryContainer,
                            shape: BoxShape.circle,
                          ),
                          child:
                              Icon(slide.$3, size: 64, color: colors.primary),
                        ),
                        const SizedBox(height: 30),
                        Text(slide.$1,
                            textAlign: TextAlign.center,
                            style: Theme.of(context)
                                .textTheme
                                .headlineSmall
                                ?.copyWith(fontWeight: FontWeight.w700)),
                        const SizedBox(height: 14),
                        Text(slide.$2,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: colors.onSurface.withValues(alpha: 0.68),
                                height: 1.5)),
                      ],
                    ),
                  );
                },
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                  _slides.length,
                  (index) => AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        width: index == _page ? 24 : 8,
                        height: 8,
                        decoration: BoxDecoration(
                            color: index == _page
                                ? colors.primary
                                : colors.outlineVariant,
                            borderRadius: BorderRadius.circular(8)),
                      )),
            ),
            if (widget.requirePassword && _page == _slides.length - 1)
              Padding(
                padding: const EdgeInsets.fromLTRB(22, 12, 22, 0),
                child: Column(
                  children: [
                    TextField(
                      controller: _passwordController,
                      obscureText: true,
                      maxLength: 16,
                      decoration: const InputDecoration(
                        labelText: 'Cipta password',
                        hintText: 'Minimum 8 aksara (huruf + nombor)',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    TextField(
                      controller: _confirmPasswordController,
                      obscureText: true,
                      maxLength: 16,
                      decoration: const InputDecoration(
                        labelText: 'Sahkan password',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ],
                ),
              ),
            Padding(
              padding: const EdgeInsets.all(22),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _page == _slides.length - 1
                      ? _selesai
                      : () => _pageController.nextPage(
                          duration: const Duration(milliseconds: 250),
                          curve: Curves.easeOut),
                  child: Text(_page == _slides.length - 1
                      ? 'Mula sekarang'
                      : 'Seterusnya'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// 3. Halaman Navigasi Utama
class HalamanNavigasiUtama extends StatefulWidget {
  const HalamanNavigasiUtama({super.key});

  @override
  State<HalamanNavigasiUtama> createState() => _HalamanNavigasiUtamaState();
}

class _HalamanNavigasiUtamaState extends State<HalamanNavigasiUtama> {
  int _pilihanIndeks = 0;
  late final List<Widget> _senaraiSkrin;

  @override
  void initState() {
    super.initState();
    _senaraiSkrin = [
      HomeScreen(onOpenChat: () => _tukarMenu(1)),
      const ChatScreen(),
      const TranslationScreen(),
      const ProfileScreen(),
      SettingsScreen(
        darkMode: appThemeMode.value == ThemeMode.dark,
        onDarkModeChanged: _tukarTema,
      ),
    ];
  }

  Future<void> _tukarTema(bool gelap) async {
    appThemeMode.value = gelap ? ThemeMode.dark : ThemeMode.light;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('dark_mode', gelap);
  }

  void _tukarMenu(int index) {
    setState(() {
      _pilihanIndeks = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _pilihanIndeks,
        children: _senaraiSkrin,
      ),
      bottomNavigationBar: ValueListenableBuilder<String>(
        valueListenable: appLanguage,
        builder: (context, bahasa, _) => NavigationBar(
          selectedIndex: _pilihanIndeks,
          onDestinationSelected: _tukarMenu,
          destinations: [
            NavigationDestination(
              icon: const Icon(CupertinoIcons.house),
              selectedIcon: const Icon(CupertinoIcons.house_fill),
              label: bahasa == 'English' ? 'Home' : 'Utama',
            ),
            NavigationDestination(
              icon: const Icon(CupertinoIcons.chat_bubble),
              selectedIcon: const Icon(CupertinoIcons.chat_bubble_fill),
              label: bahasa == 'English' ? 'Chat' : 'Sembang',
            ),
            NavigationDestination(
              icon: const Icon(CupertinoIcons.textformat),
              selectedIcon: const Icon(CupertinoIcons.textformat),
              label: bahasa == 'English' ? 'Translate' : 'Terjemah',
            ),
            NavigationDestination(
              icon: const Icon(CupertinoIcons.person),
              selectedIcon: const Icon(CupertinoIcons.person_fill),
              label: bahasa == 'English' ? 'Profile' : 'Profil',
            ),
            NavigationDestination(
              icon: const Icon(CupertinoIcons.settings),
              selectedIcon: const Icon(CupertinoIcons.settings_solid),
              label: bahasa == 'English' ? 'Settings' : 'Tetapan',
            ),
          ],
        ),
      ),
    );
  }
}
