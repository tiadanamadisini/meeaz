enum Sender { user, kaoruko }

class Message {
  final String id;
  final String text;
  final Sender sender;
  final DateTime timestamp;

  // Untuk feature "reply" — simpan sedikit info mesej asal yang dibalas.
  final String? replyToText;
  final Sender? replyToSender;

  // Untuk feature jana gambar — data imej dalam bentuk base64 (kalau ada).
  final String? imageBase64;

  // Jenis MIME imej (contoh: 'image/jpeg', 'image/png') — perlu bila
  // imej ni dihantar semula ke Gemini sebagai inline_data (untuk gambar
  // yang PENGGUNA hantar, bukan gambar jana-an Kaoruko).
  final String? imageMimeType;

  // Arahan khas (tersembunyi dari bubble) untuk gambar yang pengguna
  // hantar — contoh "tolong translate teks dalam gambar ni". Kalau
  // null, textForApi akan guna `text` biasa sebagai gantinya.
  final String? imageInstruction;

  // Untuk feature "kongsi dokumen" (PDF/PPTX) — nama fail dipaparkan
  // dalam bubble, manakala teks penuh yang di-extract dihantar ke API
  // sebagai konteks (tak dipaparkan terus dalam UI sebab boleh panjang).
  final String? documentName;
  final String? documentText;

  Message({
    String? id,
    required this.text,
    required this.sender,
    DateTime? timestamp,
    this.replyToText,
    this.replyToSender,
    this.imageBase64,
    this.imageMimeType,
    this.imageInstruction,
    this.documentName,
    this.documentText,
  })  : id = id ??
      '${DateTime.now().microsecondsSinceEpoch}-${identityHashCode(text)}',
        timestamp = timestamp ?? DateTime.now();

  bool get isImage => imageBase64 != null && imageBase64!.isNotEmpty;
  bool get isReply => replyToText != null && replyToText!.isNotEmpty;
  bool get isDocument => documentName != null && documentName!.isNotEmpty;

  /// Teks yang dihantar ke API — sertakan konteks "membalas mesej ..."
  /// atau kandungan dokumen supaya AI faham apa yang dirujuk, tanpa
  /// mengubah `text` asal yang dipaparkan dalam bubble.
  String get textForApi {
    if (isDocument) {
      final tajuk = 'Pengguna kongsi dokumen bernama "$documentName". '
          'Kandungan dokumen (ringkasan/petikan teks):';
      final kandungan = (documentText ?? '').trim();
      final soalanTambahan = text.trim();
      final buffer = StringBuffer('$tajuk\n$kandungan');
      if (soalanTambahan.isNotEmpty) {
        buffer.write('\n\nPesanan pengguna berkaitan dokumen ni: $soalanTambahan');
      } else {
        buffer.write(
            '\n\nTolong bantu terangkan/ajar pengguna berdasarkan dokumen ni macam study buddy.');
      }
      return buffer.toString();
    }
    if (isImage) {
      // Gambar yang PENGGUNA hantar — guna arahan khas kalau ada
      // (contoh: mod translate), kalau tak ada guna caption pengguna,
      // kalau kosong terus, default suruh Kaoruko tengok & citer gambar.
      if (sender == Sender.user) {
        if (imageInstruction != null && imageInstruction!.trim().isNotEmpty) {
          return imageInstruction!.trim();
        }
        if (text.isNotEmpty) return text;
        return 'Ni gambar yang aku hantar. Tolong tengok elok-elok apa yang '
            'ada dalam gambar ni (termasuk teks kalau ada), lepas tu jawab '
            'atau citer pasal gambar ni macam biasa.';
      }
      // Gambar jana-an Kaoruko sendiri.
      return text.isNotEmpty ? text : '[Kaoruko menghantar sebuah gambar]';
    }
    if (isReply) {
      final label = replyToSender == Sender.user ? 'Awak' : 'Kaoruko';
      return '[Membalas mesej $label: "$replyToText"] $text';
    }
    return text;
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'text': text,
    'sender': sender.index,
    'timestamp': timestamp.toIso8601String(),
    'replyToText': replyToText,
    'replyToSender': replyToSender?.index,
    'imageBase64': imageBase64,
    'imageMimeType': imageMimeType,
    'imageInstruction': imageInstruction,
    'documentName': documentName,
    'documentText': documentText,
  };

  factory Message.fromJson(Map<String, dynamic> json) => Message(
    id: json['id'] as String?,
    text: json['text'] ?? '',
    sender: Sender.values[json['sender'] ?? 0],
    timestamp: json['timestamp'] != null
        ? DateTime.parse(json['timestamp'])
        : DateTime.now(),
    replyToText: json['replyToText'] as String?,
    replyToSender: json['replyToSender'] != null
        ? Sender.values[json['replyToSender'] as int]
        : null,
    imageBase64: json['imageBase64'] as String?,
    imageMimeType: json['imageMimeType'] as String?,
    imageInstruction: json['imageInstruction'] as String?,
    documentName: json['documentName'] as String?,
    documentText: json['documentText'] as String?,
  );
}