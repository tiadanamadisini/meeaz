import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'main.dart' show appLanguage;
import 'services/backup_service.dart';
import 'theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  final bool darkMode;
  final ValueChanged<bool> onDarkModeChanged;

  const SettingsScreen({
    super.key,
    required this.darkMode,
    required this.onDarkModeChanged,
  });

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  static const rose = AppColors.brand;
  String _bahasa = 'Bahasa Melayu';
  late bool _darkMode;
  bool _biometrikAktif = false;

  @override
  void initState() {
    super.initState();
    _darkMode = widget.darkMode;
    _muatTetapan();
  }

  Future<void> _muatTetapan() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        _bahasa = prefs.getString('bahasa_aplikasi') ?? 'Bahasa Melayu';
        _biometrikAktif = prefs.getBool('biometrik_aktif') ?? false;
      });
    }
  }

  void _tukarDarkMode(bool value) {
    setState(() => _darkMode = value);
    widget.onDarkModeChanged(value);
  }

  Future<void> _tukarBiometrik(bool value) async {
    if (value) {
      try {
        final auth = LocalAuthentication();
        final available = await auth.getAvailableBiometrics();
        if (available.isEmpty) {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(_bahasa == 'English'
                  ? 'No biometrics are enrolled on this device.'
                  : 'Daftarkan cap jari atau Face ID pada peranti dahulu.'),
            ),
          );
          return;
        }
      } on PlatformException {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(_bahasa == 'English'
                ? 'Biometric authentication is unavailable.'
                : 'Pengesahan biometrik tidak tersedia.'),
          ),
        );
        return;
      }
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('biometrik_aktif', value);
    if (mounted) setState(() => _biometrikAktif = value);
  }

  Future<void> _tukarBahasa(String? bahasa) async {
    if (bahasa == null) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('bahasa_aplikasi', bahasa);
    appLanguage.value = bahasa;
    if (mounted) setState(() => _bahasa = bahasa);
  }

  @override
  Widget build(BuildContext context) {
    final textColor = Theme.of(context).colorScheme.onSurface;
    final english = _bahasa == 'English';
    return Scaffold(
      appBar:
          AppBar(title: Text(english ? 'Settings' : 'Tetapan'), elevation: 0),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 30),
        children: [
          _section(
            context,
            title: english ? 'Appearance' : 'Paparan',
            children: [
              SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                title: Text(english ? 'Dark mode' : 'Mod gelap',
                    style: TextStyle(color: textColor)),
                subtitle: Text(
                    english ? 'Change app theme' : 'Tukar tema aplikasi',
                    style: TextStyle(color: textColor.withValues(alpha: 0.6))),
                value: _darkMode,
                onChanged: _tukarDarkMode,
                activeThumbColor: rose,
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(english ? 'Language' : 'Bahasa',
                    style: TextStyle(color: textColor)),
                trailing: DropdownButton<String>(
                  value: _bahasa,
                  items: const [
                    DropdownMenuItem(
                        value: 'Bahasa Melayu', child: Text('Melayu')),
                    DropdownMenuItem(value: 'English', child: Text('English')),
                  ],
                  onChanged: _tukarBahasa,
                ),
              ),
              SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                title: Text(
                    english
                        ? 'Biometric Authentication'
                        : 'Pengesahan Biometrik',
                    style: TextStyle(color: textColor)),
                subtitle: Text(
                    english
                        ? 'Use fingerprint or face ID to login'
                        : 'Guna cap jari atau ID muka untuk log masuk',
                    style: TextStyle(color: textColor.withValues(alpha: 0.6))),
                value: _biometrikAktif,
                onChanged: _tukarBiometrik,
                activeThumbColor: rose,
              ),
            ],
          ),
          const SizedBox(height: 16),
          _section(
            context,
            title: english ? 'Backup & Restore' : 'Simpanan & Pemulihan',
            children: [
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.cloud_upload_rounded, color: rose),
                title: Text(english ? 'Export All Data' : 'Eksport Semua Data',
                    style: TextStyle(color: textColor)),
                subtitle: Text(
                    english
                        ? 'Save chat, highlights & profile'
                        : 'Simpan chat, highlight & profil',
                    style: TextStyle(color: textColor.withValues(alpha: 0.6))),
                onTap: () => BackupService.exportSemuaData(),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.cloud_download_rounded, color: rose),
                title: Text(english ? 'Import All Data' : 'Import Semua Data',
                    style: TextStyle(color: textColor)),
                subtitle: Text(
                    english
                        ? 'Restore from backup file'
                        : 'Pulihkan dari fail backup',
                    style: TextStyle(color: textColor.withValues(alpha: 0.6))),
                onTap: () async {
                  final success = await BackupService.importSemuaData();
                  if (success && mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                          content: Text(english
                              ? 'Data restored! Please restart app.'
                              : 'Data dipulihkan! Sila buka semula app.')),
                    );
                  }
                },
              ),
            ],
          ),
          const SizedBox(height: 16),
          _section(
            context,
            title: english ? 'About app' : 'Tentang aplikasi',
            children: [
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.info_outline_rounded, color: rose),
                title: Text('Meeaz Project',
                    style: TextStyle(
                        color: textColor, fontWeight: FontWeight.w700)),
                subtitle: Text(
                    'Versi 1.0.0\nSembang bersama Kaoruko Waguri\nDibangunkan oleh MEEAZ',
                    style: TextStyle(
                        color: textColor.withValues(alpha: 0.65), height: 1.4)),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.language_rounded, color: rose),
                title: Text('Portfolio developer',
                    style: TextStyle(color: textColor)),
                subtitle: Text('tiadanamadisini.github.io/portfolio',
                    style: TextStyle(color: textColor.withValues(alpha: 0.6))),
                onTap: _bukaPortfolio,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _section(BuildContext context,
      {required String title, required List<Widget> children}) {
    return Container(
      padding: const EdgeInsets.fromLTRB(0, 12, 0, 8),
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(color: Theme.of(context).colorScheme.outlineVariant),
        ),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title.toUpperCase(),
            style: Theme.of(context).textTheme.labelLarge?.copyWith(
                  color: Theme.of(context).colorScheme.primary,
                )),
        const SizedBox(height: 6),
        ...children,
      ]),
    );
  }

  Future<void> _bukaPortfolio() async {
    final uri = Uri.parse('https://tiadanamadisini.github.io/portfolio/');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }
}
