import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:gal/gal.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'main.dart';
import 'monetary/homemain.dart'; // Import homemain.dart
import 'screens/features_screens.dart';
import 'screens/games_hub_screen.dart';
import 'theme/app_theme.dart';

class HomeScreen extends StatefulWidget {
  final VoidCallback? onOpenChat;

  const HomeScreen({super.key, this.onOpenChat});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _namaPengguna = 'Pengguna Meeaz';
  List<Map<String, String>> _highlights = [];
  final ImagePicker _imagePicker = ImagePicker();
  static const _highlightStorageKey = 'home_highlights';

  static const Color _roseAccent = Color(0xFFC97C6D);

  Color get _inkText => Theme.of(context).colorScheme.onSurface;

  @override
  void initState() {
    super.initState();
    _muatNama();
  }

  Future<void> _muatNama() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _namaPengguna = prefs.getString('nama_pengguna') ?? 'Pengguna Meeaz';
      final saved = prefs.getString(_highlightStorageKey);
      if (saved != null && saved.isNotEmpty) {
        final decoded = jsonDecode(saved) as List<dynamic>;
        _highlights = decoded.map((item) {
          final map = item as Map<String, dynamic>;
          return {
            'image': map['image']?.toString() ?? '',
            'name': map['name']?.toString() ?? '',
            'description': map['description']?.toString() ?? '',
          };
        }).toList();
      }
    });
  }

  Future<void> _tambahHighlight() async {
    final prefs = await SharedPreferences.getInstance();
    final ignore = prefs.getBool('perm_gallery_ignore') ?? false;

    var status = await (Platform.isAndroid
        ? Permission.storage.status
        : Permission.photos.status);
    if (status.isDenied && !ignore) {
      if (mounted) {
        bool donotshow = false;
        final result = await showDialog<bool>(
          context: context,
          builder: (ctx) => StatefulBuilder(
            builder: (context, setDialogState) => AlertDialog(
              title: const Text('Akses Galeri'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                      'Aplikasi memerlukan akses galeri untuk memuat naik highlight anda.'),
                  const SizedBox(height: 12),
                  CheckboxListTile(
                    title: const Text('Jangan paparkan lagi',
                        style: TextStyle(fontSize: 14)),
                    value: donotshow,
                    onChanged: (val) =>
                        setDialogState(() => donotshow = val ?? false),
                    controlAffinity: ListTileControlAffinity.leading,
                    contentPadding: EdgeInsets.zero,
                  ),
                ],
              ),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(ctx, false),
                    child: const Text('Batal')),
                TextButton(
                  onPressed: () async {
                    if (donotshow)
                      await prefs.setBool('perm_gallery_ignore', true);
                    Navigator.pop(ctx, true);
                  },
                  child: const Text('Benarkan'),
                ),
              ],
            ),
          ),
        );

        if (result == true) {
          if (Platform.isAndroid) {
            await Permission.storage.request();
            await Permission.photos.request();
          } else {
            await Permission.photos.request();
          }
        } else {
          return;
        }
      }
    }

    final file = await _imagePicker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 88,
      maxWidth: 1600,
    );
    if (file == null || !mounted) return;

    final details = await _showHighlightForm(File(file.path));
    if (details == null) return;

    final bytes = await File(file.path).readAsBytes();
    final item = {
      'image': base64Encode(bytes),
      'name': details.$1,
      'description': details.$2,
    };
    final updated = [..._highlights, item];
    await prefs.setString(_highlightStorageKey, jsonEncode(updated));
    if (mounted) setState(() => _highlights = updated);
  }

  Future<(String, String)?> _showHighlightForm(File image) async {
    final nameController = TextEditingController();
    final descriptionController = TextEditingController();
    final result = await showModalBottomSheet<(String, String)?>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) => Padding(
        padding: EdgeInsets.fromLTRB(
          20,
          18,
          20,
          MediaQuery.of(sheetContext).viewInsets.bottom + 20,
        ),
        child: ListView(
          shrinkWrap: true,
          children: [
            const Text('Tambah Highlight',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
            const SizedBox(height: 14),
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Image.file(image, height: 180, fit: BoxFit.cover),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Nama',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: descriptionController,
              minLines: 3,
              maxLines: 6,
              decoration: const InputDecoration(
                labelText: 'Description',
                hintText: 'Tulis penerangan lebih daripada 20 patah perkataan',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed: () {
                final name = nameController.text.trim();
                final description = descriptionController.text.trim();
                if (name.isEmpty || description.isEmpty) {
                  ScaffoldMessenger.of(sheetContext).showSnackBar(
                    const SnackBar(
                        content: Text('Sila isi nama dan description.')),
                  );
                  return;
                }
                Navigator.of(sheetContext).pop((name, description));
              },
              icon: const Icon(Icons.upload_rounded),
              label: const Text('Upload'),
            ),
          ],
        ),
      ),
    );
    nameController.dispose();
    descriptionController.dispose();
    return result;
  }

  Future<void> _showHighlightDetail(Map<String, String> highlight) async {
    final bytes = base64Decode(highlight['image']!);
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
        child: ListView(
          shrinkWrap: true,
          children: [
            Text(highlight['name'] ?? '',
                style:
                    const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
            const SizedBox(height: 14),
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: InteractiveViewer(child: Image.memory(bytes)),
            ),
            const SizedBox(height: 14),
            Text(highlight['description'] ?? '',
                style: const TextStyle(height: 1.5)),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: () async {
                try {
                  // TASK 7: Rationale for saving image
                  final hasAccess = await Gal.hasAccess();
                  if (!hasAccess) {
                    final result = await showDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('Simpan Gambar'),
                        content: const Text(
                            'Aplikasi memerlukan kebenaran untuk menyimpan gambar ke galeri peranti anda.'),
                        actions: [
                          TextButton(
                              onPressed: () => Navigator.pop(ctx, false),
                              child: const Text('Batal')),
                          TextButton(
                              onPressed: () => Navigator.pop(ctx, true),
                              child: const Text('Benarkan')),
                        ],
                      ),
                    );
                    if (result != true) return;
                  }

                  if (!await Gal.hasAccess() && !await Gal.requestAccess())
                    return;
                  await Gal.putImageBytes(Uint8List.fromList(bytes),
                      name:
                          'highlight_${DateTime.now().millisecondsSinceEpoch}');
                  if (sheetContext.mounted) {
                    ScaffoldMessenger.of(sheetContext).showSnackBar(
                        const SnackBar(
                            content: Text('Gambar berjaya disimpan.')));
                  }
                } catch (error) {
                  if (sheetContext.mounted) {
                    ScaffoldMessenger.of(sheetContext).showSnackBar(
                        SnackBar(content: Text('Gagal simpan gambar: $error')));
                  }
                }
              },
              icon: const Icon(Icons.download_rounded),
              label: const Text('Download gambar'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Theme.of(context).scaffoldBackgroundColor,
              Theme.of(context).colorScheme.surfaceContainerLowest,
            ],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Selamat datang,',
                  style: TextStyle(
                    fontSize: 14,
                    color: _inkText.withValues(alpha: 0.55),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  _namaPengguna,
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.w700,
                    color: Theme.of(context).colorScheme.onSurface,
                  ),
                ),
                const SizedBox(height: 24),
                _LiveWidget(accent: _roseAccent, onTap: widget.onOpenChat),
                const SizedBox(height: 24),
                _HeroCard(
                  imagePath: 'assets/pfp.jpg',
                  title: 'Kaoruko Waguri',
                  subtitle: 'Waguri Kaoruko, kawan yang dekat dengan awak',
                  accent: _roseAccent,
                  onTap: widget.onOpenChat,
                ),
                const SizedBox(height: 28),
                _FeatureGrid(accent: _roseAccent),
                const SizedBox(height: 28),
                Text(
                  'Highlight',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Theme.of(context).colorScheme.onSurface,
                  ),
                ),
                const SizedBox(height: 12),
                if (_highlights.isEmpty)
                  Text(
                    'Belum ada highlight. Tekan butang + untuk upload gambar.',
                    style: TextStyle(color: _inkText.withValues(alpha: 0.6)),
                  )
                else
                  ..._highlights.map(
                    (highlight) => Padding(
                      padding: const EdgeInsets.only(bottom: 14),
                      child: _HighlightTile(
                        imageBytes: base64Decode(highlight['image']!),
                        title: highlight['name'] ?? '',
                        subtitle: highlight['description'] ?? '',
                        onTap: () => _showHighlightDetail(highlight),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
      floatingActionButton: Padding(
        padding:
            const EdgeInsets.only(bottom: 80), // Naikkan sedikit atas nav bar
        child: FloatingActionButton(
          onPressed: _tambahHighlight,
          tooltip: 'Upload highlight',
          backgroundColor: _roseAccent,
          foregroundColor: Colors.white,
          child: const Icon(Icons.add_a_photo_rounded),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }
}

class _LiveWidget extends StatefulWidget {
  final Color accent;
  final VoidCallback? onTap;
  const _LiveWidget({required this.accent, this.onTap});

  @override
  State<_LiveWidget> createState() => _LiveWidgetState();
}

class _LiveWidgetState extends State<_LiveWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Stack(
            children: [
              AnimatedBuilder(
                animation: _controller,
                builder: (context, child) {
                  return Container(
                    padding: EdgeInsets.all(2 + (_controller.value * 2)),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: widget.accent.withValues(alpha: 0.5),
                        width: 2,
                      ),
                    ),
                    child: child,
                  );
                },
                child: const CircleAvatar(
                  radius: 28,
                  backgroundImage: AssetImage('assets/pfp.jpg'),
                ),
              ),
              Positioned(
                right: 0,
                bottom: 0,
                child: Container(
                  width: 14,
                  height: 14,
                  decoration: BoxDecoration(
                    color: const Color(0xFF6FBF73),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 2),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Kaoruko sedang aktif',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                ),
                Text(
                  'Ketuk untuk mula berbual sekarang!',
                  style: TextStyle(
                    fontSize: 12,
                    color: Theme.of(context)
                        .colorScheme
                        .onSurface
                        .withValues(alpha: 0.5),
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: widget.onTap,
            icon: Icon(Icons.chat_bubble_rounded, color: widget.accent),
            style: IconButton.styleFrom(
              backgroundColor: widget.accent.withValues(alpha: 0.1),
            ),
          ),
        ],
      ),
    );
  }
}

/// Kad hero besar di bahagian atas — gambar penuh dengan overlay gradient
/// dan teks di bawah, bukan card putih generik.
class _HeroCard extends StatelessWidget {
  final String imagePath;
  final String title;
  final String subtitle;
  final Color accent;
  final VoidCallback? onTap;

  const _HeroCard({
    required this.imagePath,
    required this.title,
    required this.subtitle,
    required this.accent,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppRadius.lg),
        child: SizedBox(
          height: 200,
          width: double.infinity,
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.asset(imagePath, fit: BoxFit.cover),
              DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withValues(alpha: 0.55),
                    ],
                    stops: const [0.4, 1.0],
                  ),
                ),
              ),
              Positioned(
                left: 18,
                right: 18,
                bottom: 16,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 19,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.85),
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Tile highlight — gambar kecil di kiri, teks di kanan, kad rata dengan
/// shadow lembut.
class _HighlightTile extends StatelessWidget {
  final List<int> imageBytes;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _HighlightTile({
    required this.imageBytes,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(AppRadius.lg),
          border:
              Border.all(color: Theme.of(context).colorScheme.outlineVariant),
        ),
        padding: const EdgeInsets.all(10),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(AppRadius.sm),
              child: Image.memory(
                Uint8List.fromList(imageBytes),
                width: 64,
                height: 64,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: Theme.of(context).colorScheme.onSurface,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 12.5,
                      color: Theme.of(context)
                          .colorScheme
                          .onSurface
                          .withValues(alpha: 0.55),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FeatureGrid extends StatelessWidget {
  final Color accent;

  const _FeatureGrid({required this.accent});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _FeatureCard(
          icon: Icons.videogame_asset_rounded,
          title: 'Game Hub',
          subtitle: 'Main dengan Kaoruko',
          color: const Color(0xFF8EACCD),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const GamesHubScreen()),
          ),
        ),
        _FeatureCard(
          icon: Icons.camera_enhance_rounded,
          title: 'AI Photo Mode',
          subtitle: 'Selfie bersama',
          color: const Color(0xFFD7B1D7),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => PhotoModeScreen()),
          ),
        ),
        _FeatureCard(
          icon: Icons.auto_awesome_mosaic_rounded,
          title: 'Meeaz Main',
          subtitle: 'Urus kewangan Waguri',
          color: accent,
          onTap: () {
            // Navigasi ke MoneyTrackApp (Sistem Pengurusan Kewangan Waguri)
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => MoneyTrackApp(themeMode: appThemeMode.value),
              ),
            );
          },
        ),
        _FeatureCard(
          icon: Icons.call_rounded,
          title: 'Voice Call',
          subtitle: 'Panggilan Intim',
          color: accent,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => VoiceCallScreen()),
          ),
        ),
      ].asMap().entries.map((entry) {
        return Column(
          children: [
            entry.value,
            if (entry.key < 3)
              Divider(
                height: 1,
                indent: 58,
                color: Theme.of(context).colorScheme.outlineVariant,
              ),
          ],
        );
      }).toList(),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _FeatureCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 13),
          child: Row(
            children: [
              SizedBox(
                width: 42,
                height: 42,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(AppRadius.md),
                  ),
                  child: Icon(icon, color: color, size: 21),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 2),
                    Text(subtitle,
                        style: Theme.of(context).textTheme.bodySmall),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded,
                  color: Theme.of(context).colorScheme.onSurfaceVariant),
            ],
          ),
        ),
      ),
    );
  }
}
