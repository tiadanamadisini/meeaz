// ============================================================================
// GAME: DELIVERY RIDER 3D - HANTAR PESANAN & PATUH PERATURAN JALAN RAYA
// SPESIFIKASI: SATU FAIL SAHAJA (main.dart) | GAYA PSEUDO-3D ISOMETRIK (CustomPainter)
//
// NOTA PERUBAHAN UTAMA (v3):
//  - Permainan KEKAL LANDSKAP sepanjang masa (menu & gameplay).
//  - Kawalan ditukar: Stereng (kiri-tengah, boleh pusing & spring-back) +
//    Pedal Brek & Pedal Minyak (kanan, gaya pedal kereta sebenar).
//  - Ada Speedometer Analog (jarum) + Digital + status Gear (N/D/R).
//  - Ada "View Dalam Kenderaan": dashboard, tudung enjin & vignette cermin
//    depan supaya rasa macam memandu dari dalam kereta.
//  - Peta dunia terbuka digantikan dengan sistem LALUAN (route) melengkung
//    bergaya bandar Jepun — pemain TIDAK BOLEH keluar dari laluan/koridor
//    jalan (dinding tak kelihatan menyekat & beri amaran).
//  - 5 Misi bertema Kaoruko Waguri, setiap satu ada cuaca/waktu, halangan,
//    dan jarak (meter) tersendiri.
//  - GPS masa nyata (dikemaskini tiap 0.5s) + Mini-map dinamik.
//  - Kenderaan lain (trafik ambien) bergerak di kedua-dua lorong.
// ============================================================================

import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Permainan ini WAJIB landskap sepanjang masa (menu & gameplay).
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  runApp(const DeliveryRiderApp());
}

class DeliveryRiderApp extends StatelessWidget {
  const DeliveryRiderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Delivery Rider 3D',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0F172A),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF0288D1),
          secondary: Color(0xFFFFD54F),
        ),
      ),
      home: const MainMenuScreen(),
    );
  }
}

// ============================================================================
// 1. SOUND MANAGER (SystemSound Fallback & Haptics)
// ============================================================================
class SoundManager {
  static bool isMuted = false;

  static void playHorn() {
    if (isMuted) return;
    HapticFeedback.heavyImpact();
    SystemSound.play(SystemSoundType.click);
  }

  static void playBrake() {
    if (isMuted) return;
    HapticFeedback.selectionClick();
  }

  static void playViolationBuzz() {
    if (isMuted) return;
    HapticFeedback.vibrate();
    SystemSound.play(SystemSoundType.alert);
  }

  static void playPickupChime() {
    if (isMuted) return;
    HapticFeedback.mediumImpact();
    SystemSound.play(SystemSoundType.click);
  }

  static void playVictoryFanfare() {
    if (isMuted) return;
    HapticFeedback.heavyImpact();
    SystemSound.play(SystemSoundType.click);
  }

  static void playCoin() {
    if (isMuted) return;
    HapticFeedback.lightImpact();
    SystemSound.play(SystemSoundType.click);
  }

  static void playBump() {
    if (isMuted) return;
    HapticFeedback.mediumImpact();
  }

  static void playGpsBeep() {
    if (isMuted) return;
    HapticFeedback.selectionClick();
  }
}

// ============================================================================
// 2. ENUM & DATA MODEL ASAS
// ============================================================================
enum VehicleCategory { motorcycle, car }

enum VehicleId {
  scooter('Scooter Kilat 110', VehicleCategory.motorcycle, 55.0, 3.2, 4.2, 0.65, 0, 0xFFFF5722, 'Motosikal permulaan lincah.'),
  kapcai('Kapcai Delivery 135', VehicleCategory.motorcycle, 72.0, 3.8, 3.8, 0.70, 200, 0xFF2196F3, 'Pantas & seimbang di bandar.'),
  superbike('Superbike R-900', VehicleCategory.motorcycle, 100.0, 5.0, 4.4, 0.55, 500, 0xFFE91E63, 'Kelajuan melampau, licin hujan!'),
  compact('Kereta Kompak Mini', VehicleCategory.car, 65.0, 2.6, 3.0, 0.88, 150, 0xFF4CAF50, 'Stabil di jalan basah & sempit.'),
  sportSedan('Sedan Turbo GT', VehicleCategory.car, 88.0, 3.7, 3.4, 0.85, 450, 0xFFFFEB3B, 'Laju & selesa dengan stereng jitu.'),
  deliveryVan('Van Kargo 4x4', VehicleCategory.car, 60.0, 2.2, 2.4, 0.95, 300, 0xFF9C27B0, 'Grip tinggi, muatan kargo banyak.');

  final String name;
  final VehicleCategory category;
  final double maxSpeed;
  final double accel;
  final double handling;
  final double slipResistance;
  final int price;
  final int defaultColor;
  final String desc;
  const VehicleId(this.name, this.category, this.maxSpeed, this.accel, this.handling, this.slipResistance, this.price, this.defaultColor, this.desc);
}

enum WeatherMode {
  day('Pagi Cerah', 1.0, 1.0, Color(0xFF87CEEB), Color(0xFF374151)),
  goldenAfternoon('Petang Keemasan', 0.88, 0.95, Color(0xFFFFB74D), Color(0xFF4E342E)),
  night('Malam Neon', 0.35, 0.98, Color(0xFF0F172A), Color(0xFF1E293B)),
  rain('Hujan Damai', 0.65, 0.62, Color(0xFF475569), Color(0xFF1F2937)),
  snow('Salji Melayang', 0.82, 0.42, Color(0xFFCBD5E1), Color(0xFFE2E8F0));

  final String title;
  final double brightness;
  final double friction;
  final Color skyColor;
  final Color roadColor;
  const WeatherMode(this.title, this.brightness, this.friction, this.skyColor, this.roadColor);
}

enum TrafficLightColor { green, yellow, red }

enum ViolationType {
  redLight('−20 POIN: Langgar Lampu Merah!', 20),
  stopSign('−15 POIN: Tak Berhenti Penuh Tanda STOP!', 15),
  speeding('−10 POIN: Melebihi Had Laju!', 10),
  collision('−20 POIN: Perlanggaran!', 20),
  obstacleHit('−15 POIN: Langgar Halangan Jalan!', 15),
  offRoute('−5 POIN: Terkeluar Dari Laluan!', 5);

  final String title;
  final int deduction;
  const ViolationType(this.title, this.deduction);
}

class ActiveViolation {
  final String message;
  final int points;
  double ttl;
  ActiveViolation(this.message, this.points, [this.ttl = 2.5]);
}

double _distTo(double x1, double y1, double x2, double y2) {
  final dx = x1 - x2;
  final dy = y1 - y2;
  return math.sqrt(dx * dx + dy * dy);
}

/// Kenderaan pemain.
class PlayerVehicle {
  VehicleId vehicleId;
  Color color;
  String plate;
  double x, y;
  double vx = 0, vy = 0;
  double angle = 0;
  double leanAngle = 0;
  double currentSpeed = 0;
  bool hasPickedUp = false;
  bool reversing = false;

  double speedingTimer = 0;
  double collisionCooldown = 0;
  double bumpCooldown = 0;
  double stopHoldTimer = 0;
  bool insideStopZone = false;
  bool stoppedAtSignThisPass = false;
  final Map<String, bool> lightArmed = {};
  int totalViolations = 0;

  PlayerVehicle({
    required this.vehicleId,
    required this.color,
    required this.plate,
    required this.x,
    required this.y,
  });
}

/// Kenderaan trafik ambien yang bergerak di sepanjang laluan (dua lorong).
class RouteTrafficNpc {
  double progress;
  final double lateralRatio;
  final double speed;
  final bool isMoto;
  final Color color;
  double x = 0, y = 0, angle = 0;

  RouteTrafficNpc({
    required this.progress,
    required this.lateralRatio,
    required this.speed,
    required this.isMoto,
    required this.color,
  });
}

/// Lampu isyarat yang benar-benar bertukar warna mengikut masa.
class TrafficLight {
  final String id;
  final double x, y;
  TrafficLightColor color = TrafficLightColor.green;
  double timer = 0;

  TrafficLight({required this.id, required this.x, required this.y});

  void update(double dt) {
    timer += dt;
    switch (color) {
      case TrafficLightColor.green:
        if (timer > 5.0) {
          color = TrafficLightColor.yellow;
          timer = 0;
        }
        break;
      case TrafficLightColor.yellow:
        if (timer > 1.2) {
          color = TrafficLightColor.red;
          timer = 0;
        }
        break;
      case TrafficLightColor.red:
        if (timer > 4.0) {
          color = TrafficLightColor.green;
          timer = 0;
        }
        break;
    }
  }
}

class BuildingSpec {
  final double bx, by, bw, bh, h3d;
  final Color roof, front, side;
  const BuildingSpec(this.bx, this.by, this.bw, this.bh, this.h3d, this.roof, this.front, this.side);
  Rect get footprint => Rect.fromLTWH(bx, by, bw, bh);
}

// ============================================================================
// 3. STORAGE MANAGER (SharedPreferences)
// ============================================================================
class StorageManager {
  static SharedPreferences? _prefs;

  static Future<void> init() async {
    _prefs ??= await SharedPreferences.getInstance();
  }

  static int get coins => _prefs?.getInt('coins') ?? 150;
  static set coins(int val) => _prefs?.setInt('coins', val);

  static String get vehicleName => _prefs?.getString('vehicle') ?? VehicleId.scooter.name;
  static set vehicleName(String val) => _prefs?.setString('vehicle', val);

  static int get customColor => _prefs?.getInt('custom_color') ?? 0xFFFF5722;
  static set customColor(int val) => _prefs?.setInt('custom_color', val);

  static String get plate => _prefs?.getString('plate') ?? 'KILAT-07';
  static set plate(String val) => _prefs?.setString('plate', val);

  static int get completed => _prefs?.getInt('completed') ?? 0;
  static set completed(int val) => _prefs?.setInt('completed', val);

  static bool isUnlocked(VehicleId v) {
    if (v.price == 0) return true;
    final list = _prefs?.getStringList('unlocked_list') ?? [VehicleId.scooter.name];
    return list.contains(v.name);
  }

  static void unlock(VehicleId v) {
    final list = _prefs?.getStringList('unlocked_list') ?? [VehicleId.scooter.name];
    if (!list.contains(v.name)) {
      list.add(v.name);
      _prefs?.setStringList('unlocked_list', list);
    }
  }

  static int get unlockedMissionIndex => _prefs?.getInt('unlocked_mission') ?? 0;
  static void unlockMission(int idx) {
    if (idx > unlockedMissionIndex) _prefs?.setInt('unlocked_mission', idx);
  }

  static int starsFor(String missionId) => _prefs?.getInt('stars_$missionId') ?? 0;
  static void saveStars(String missionId, int s) {
    if (s > starsFor(missionId)) _prefs?.setInt('stars_$missionId', s);
  }
}

// ============================================================================
// 4. MATEMATIK LALUAN (ROUTE) — SATU SUMBER UNTUK VISUAL & FIZIK
// ============================================================================
class RoutePoint {
  final Offset pos;
  final Offset perp;
  final double angle;
  RoutePoint(this.pos, this.perp, this.angle);
}

class RouteProjection {
  final double progress;
  final double lateralOffset;
  final double segmentAngle;
  final int segmentIndex;
  RouteProjection(this.progress, this.lateralOffset, this.segmentAngle, this.segmentIndex);
}

/// Bina laluan bermula (startX,startY) menghala startAngleDeg, ikut senarai
/// panjang segmen (meter) & sudut belok (darjah) antara setiap segmen.
List<Offset> buildRoute(double startX, double startY, double startAngleDeg, List<double> segLens, List<double> turnDegs) {
  final pts = <Offset>[Offset(startX, startY)];
  double angle = startAngleDeg * math.pi / 180;
  double x = startX, y = startY;
  for (int i = 0; i < segLens.length; i++) {
    x += math.cos(angle) * segLens[i];
    y += math.sin(angle) * segLens[i];
    pts.add(Offset(x, y));
    if (i < turnDegs.length) angle += turnDegs[i] * math.pi / 180;
  }
  return pts;
}

List<double> buildCumLen(List<Offset> route) {
  final cum = <double>[0];
  double acc = 0;
  for (int i = 0; i < route.length - 1; i++) {
    acc += (route[i + 1] - route[i]).distance;
    cum.add(acc);
  }
  return cum;
}

RoutePoint pointAtDistance(List<Offset> route, List<double> cumLen, double dist) {
  dist = dist.clamp(0, cumLen.last);
  int seg = 0;
  for (int i = 0; i < cumLen.length - 1; i++) {
    seg = i;
    if (dist <= cumLen[i + 1]) break;
  }
  final a = route[seg], b = route[seg + 1];
  final segLen = cumLen[seg + 1] - cumLen[seg];
  final t = segLen > 0 ? (dist - cumLen[seg]) / segLen : 0.0;
  final pos = Offset(a.dx + (b.dx - a.dx) * t, a.dy + (b.dy - a.dy) * t);
  final angle = math.atan2(b.dy - a.dy, b.dx - a.dx);
  final perp = Offset(-math.sin(angle), math.cos(angle));
  return RoutePoint(pos, perp, angle);
}

RouteProjection projectOntoRoute(List<Offset> route, List<double> cumLen, Offset p) {
  double best = double.infinity;
  int bestSeg = 0;
  double bestT = 0;
  for (int i = 0; i < route.length - 1; i++) {
    final a = route[i], b = route[i + 1];
    final ab = b - a;
    final len2 = ab.dx * ab.dx + ab.dy * ab.dy;
    final t = len2 > 0 ? (((p.dx - a.dx) * ab.dx + (p.dy - a.dy) * ab.dy) / len2).clamp(0.0, 1.0) : 0.0;
    final proj = Offset(a.dx + ab.dx * t, a.dy + ab.dy * t);
    final d = (p - proj).distance;
    if (d < best) {
      best = d;
      bestSeg = i;
      bestT = t;
    }
  }
  final a = route[bestSeg], b = route[bestSeg + 1];
  final segLen = (b - a).distance;
  final progress = cumLen[bestSeg] + segLen * bestT;
  final angle = math.atan2(b.dy - a.dy, b.dx - a.dx);
  final abx = b.dx - a.dx, aby = b.dy - a.dy;
  final apx = p.dx - a.dx, apy = p.dy - a.dy;
  final cross = abx * apy - aby * apx;
  final segLenSafe = segLen > 0 ? segLen : 1;
  final lateral = cross / segLenSafe;
  return RouteProjection(progress, lateral, angle, bestSeg);
}

// ============================================================================
// 5. HALANGAN (OBSTACLE) SEPANJANG LALUAN
// ============================================================================
enum ObstacleType { student, bicycle, book, cat, bin, pothole, cafeTable, chair, deliveryVan, toybox, tricycle, puddle, bench, duck, goldCoin }

enum ObstacleBehavior { solidBlock, hazardHit, bump, cosmetic, collectible }

ObstacleBehavior behaviorOf(ObstacleType t) {
  switch (t) {
    case ObstacleType.student:
    case ObstacleType.cat:
    case ObstacleType.duck:
      return ObstacleBehavior.hazardHit;
    case ObstacleType.bicycle:
    case ObstacleType.book:
    case ObstacleType.bin:
    case ObstacleType.cafeTable:
    case ObstacleType.chair:
    case ObstacleType.deliveryVan:
    case ObstacleType.toybox:
    case ObstacleType.tricycle:
    case ObstacleType.bench:
      return ObstacleBehavior.solidBlock;
    case ObstacleType.pothole:
      return ObstacleBehavior.bump;
    case ObstacleType.puddle:
      return ObstacleBehavior.cosmetic;
    case ObstacleType.goldCoin:
      return ObstacleBehavior.collectible;
  }
}

class ObstacleSpec {
  final ObstacleType type;
  final double distAlong;
  final double lateralRatio;
  final bool moving;
  const ObstacleSpec({required this.type, required this.distAlong, this.lateralRatio = 0, this.moving = false});
}

class ObstacleRuntime {
  final ObstacleType type;
  final Offset anchor;
  final Offset perp;
  final bool moving;
  final double lateralRatio;
  final double phase;
  bool collected = false;

  ObstacleRuntime({
    required this.type,
    required this.anchor,
    required this.perp,
    required this.moving,
    required this.lateralRatio,
    required this.phase,
  });

  Offset currentPos(double time, double roadHalfWidth) {
    if (moving) {
      final osc = math.sin(time * 0.9 + phase);
      return anchor + perp * (osc * roadHalfWidth * 0.8);
    }
    return anchor + perp * (lateralRatio * roadHalfWidth);
  }
}

// ============================================================================
// 6. MISI (5 LOKASI BERTEMA KAORUKO WAGURI)
// ============================================================================
class MissionDef {
  final String id;
  final String title;
  final String subtitle;
  final WeatherMode weather;
  final List<double> segLens;
  final List<double> turnDegs;
  final List<ObstacleSpec> obstacles;
  final List<double> lightDist;
  final List<double> stopSignDist;
  final double timeLimit;
  final int rewardCoins;
  final int rewardPoints;

  double get distanceMeters => segLens.fold(0.0, (a, b) => a + b);

  const MissionDef({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.weather,
    required this.segLens,
    required this.turnDegs,
    required this.obstacles,
    required this.lightDist,
    required this.stopSignDist,
    required this.timeLimit,
    required this.rewardCoins,
    required this.rewardPoints,
  });
}

class MissionCatalog {
  static final List<MissionDef> all = [
    const MissionDef(
      id: 'sekolah_kaoruko',
      title: 'Sekolah Kaoruko',
      subtitle: 'Pagi Cerah • 1,000m',
      weather: WeatherMode.day,
      segLens: [250, 300, 250, 200],
      turnDegs: [-30, 45, -20],
      obstacles: [
        ObstacleSpec(type: ObstacleType.student, distAlong: 150, moving: true),
        ObstacleSpec(type: ObstacleType.bicycle, distAlong: 300, lateralRatio: 0.5),
        ObstacleSpec(type: ObstacleType.student, distAlong: 450, moving: true),
        ObstacleSpec(type: ObstacleType.book, distAlong: 520, lateralRatio: 0.2),
        ObstacleSpec(type: ObstacleType.book, distAlong: 535, lateralRatio: -0.15),
        ObstacleSpec(type: ObstacleType.bicycle, distAlong: 600, lateralRatio: -0.4),
        ObstacleSpec(type: ObstacleType.student, distAlong: 780, moving: true),
      ],
      lightDist: [600],
      stopSignDist: [250],
      timeLimit: 95,
      rewardCoins: 70,
      rewardPoints: 150,
    ),
    const MissionDef(
      id: 'rumah_kaoruko',
      title: 'Rumah Kaoruko',
      subtitle: 'Petang Keemasan • 1,150m',
      weather: WeatherMode.goldenAfternoon,
      segLens: [300, 250, 300, 300],
      turnDegs: [40, -35, 25],
      obstacles: [
        ObstacleSpec(type: ObstacleType.cat, distAlong: 200, moving: true),
        ObstacleSpec(type: ObstacleType.bin, distAlong: 350, lateralRatio: 0.6),
        ObstacleSpec(type: ObstacleType.pothole, distAlong: 450),
        ObstacleSpec(type: ObstacleType.cat, distAlong: 500, moving: true),
        ObstacleSpec(type: ObstacleType.bin, distAlong: 700, lateralRatio: -0.5),
        ObstacleSpec(type: ObstacleType.pothole, distAlong: 900),
        ObstacleSpec(type: ObstacleType.cat, distAlong: 850, moving: true),
      ],
      lightDist: [500],
      stopSignDist: [950],
      timeLimit: 105,
      rewardCoins: 85,
      rewardPoints: 170,
    ),
    const MissionDef(
      id: 'kedai_kek_rintaro',
      title: 'Kedai Kek Rintaro',
      subtitle: 'Malam Neon • 1,300m',
      weather: WeatherMode.night,
      segLens: [350, 300, 350, 300],
      turnDegs: [-45, 50, -30],
      obstacles: [
        ObstacleSpec(type: ObstacleType.cafeTable, distAlong: 300, lateralRatio: 0.5),
        ObstacleSpec(type: ObstacleType.chair, distAlong: 310, lateralRatio: 0.65),
        ObstacleSpec(type: ObstacleType.cafeTable, distAlong: 700, lateralRatio: -0.5),
        ObstacleSpec(type: ObstacleType.chair, distAlong: 710, lateralRatio: -0.35),
        ObstacleSpec(type: ObstacleType.deliveryVan, distAlong: 500, lateralRatio: 0.55),
        ObstacleSpec(type: ObstacleType.deliveryVan, distAlong: 950, moving: true),
      ],
      lightDist: [400, 1100],
      stopSignDist: [850],
      timeLimit: 115,
      rewardCoins: 100,
      rewardPoints: 190,
    ),
    const MissionDef(
      id: 'rumah_adik_adik',
      title: 'Rumah Adik-adik',
      subtitle: 'Hujan Damai • 1,400m',
      weather: WeatherMode.rain,
      segLens: [350, 350, 350, 350],
      turnDegs: [30, -30, 35],
      obstacles: [
        ObstacleSpec(type: ObstacleType.toybox, distAlong: 250, lateralRatio: 0.5),
        ObstacleSpec(type: ObstacleType.tricycle, distAlong: 500, moving: true),
        ObstacleSpec(type: ObstacleType.puddle, distAlong: 350),
        ObstacleSpec(type: ObstacleType.puddle, distAlong: 700),
        ObstacleSpec(type: ObstacleType.puddle, distAlong: 1050),
        ObstacleSpec(type: ObstacleType.toybox, distAlong: 900, lateralRatio: -0.5),
        ObstacleSpec(type: ObstacleType.tricycle, distAlong: 1100, moving: true),
      ],
      lightDist: [600],
      stopSignDist: [1250],
      timeLimit: 125,
      rewardCoins: 110,
      rewardPoints: 210,
    ),
    const MissionDef(
      id: 'taman_tasik_kaoru',
      title: 'Taman Tasik Kaoru',
      subtitle: 'Piknik Tasik Bonus • 1,500m',
      weather: WeatherMode.day,
      segLens: [250, 200, 250, 200, 250, 150, 200],
      turnDegs: [60, -70, 55, -60, 65, -55],
      obstacles: [
        ObstacleSpec(type: ObstacleType.bench, distAlong: 200, lateralRatio: 0.6),
        ObstacleSpec(type: ObstacleType.duck, distAlong: 350, moving: true),
        ObstacleSpec(type: ObstacleType.bench, distAlong: 700, lateralRatio: -0.6),
        ObstacleSpec(type: ObstacleType.duck, distAlong: 800, moving: true),
        ObstacleSpec(type: ObstacleType.bench, distAlong: 1200, lateralRatio: 0.6),
        ObstacleSpec(type: ObstacleType.duck, distAlong: 1300, moving: true),
        ObstacleSpec(type: ObstacleType.goldCoin, distAlong: 140),
        ObstacleSpec(type: ObstacleType.goldCoin, distAlong: 280, lateralRatio: 0.3),
        ObstacleSpec(type: ObstacleType.goldCoin, distAlong: 420, lateralRatio: -0.3),
        ObstacleSpec(type: ObstacleType.goldCoin, distAlong: 560),
        ObstacleSpec(type: ObstacleType.goldCoin, distAlong: 700, lateralRatio: 0.2),
        ObstacleSpec(type: ObstacleType.goldCoin, distAlong: 840, lateralRatio: -0.2),
        ObstacleSpec(type: ObstacleType.goldCoin, distAlong: 980),
        ObstacleSpec(type: ObstacleType.goldCoin, distAlong: 1120, lateralRatio: 0.3),
        ObstacleSpec(type: ObstacleType.goldCoin, distAlong: 1260, lateralRatio: -0.3),
        ObstacleSpec(type: ObstacleType.goldCoin, distAlong: 1400),
      ],
      lightDist: [300],
      stopSignDist: [],
      timeLimit: 140,
      rewardCoins: 130,
      rewardPoints: 250,
    ),
  ];
}

/// Bina bangunan bergaya bandar Jepun secara prosedural sepanjang laluan.
const List<List<Color>> _japanesePalette = [
  [Color(0xFF8D6E63), Color(0xFF6D4C41), Color(0xFF4E342E)],
  [Color(0xFFB0BEC5), Color(0xFF90A4AE), Color(0xFF607D8B)],
  [Color(0xFFD7CCC8), Color(0xFFBCAAA4), Color(0xFF8D6E63)],
  [Color(0xFFEF9A9A), Color(0xFFE57373), Color(0xFFC62828)],
  [Color(0xFF9FA8DA), Color(0xFF7986CB), Color(0xFF3F51B5)],
  [Color(0xFFA5D6A7), Color(0xFF81C784), Color(0xFF388E3C)],
];

List<BuildingSpec> generateJapaneseBuildings(List<Offset> route, List<double> cumLen, double totalLen, double roadHalfWidth) {
  final rng = math.Random(42);
  final list = <BuildingSpec>[];
  double d = 60;
  while (d < totalLen - 60) {
    final rp = pointAtDistance(route, cumLen, d);
    for (final side in [-1.0, 1.0]) {
      final w = 50 + rng.nextDouble() * 35;
      final h = 45 + rng.nextDouble() * 85;
      final depth = 26 + rng.nextDouble() * 28;
      final baseOffset = roadHalfWidth + 24 + rng.nextDouble() * 18;
      final pos = rp.pos + rp.perp * (side * baseOffset);
      final palette = _japanesePalette[rng.nextInt(_japanesePalette.length)];
      list.add(BuildingSpec(pos.dx - w / 2, pos.dy - h / 2, w, h, depth, palette[0], palette[1], palette[2]));
    }
    d += 65 + rng.nextDouble() * 35;
  }
  return list;
}

/// Data lokasi & keadaan larian semasa satu misi (dibina sekali sahaja).
class MissionRuntime {
  static const double roadHalfWidth = 70;
  final MissionDef def;
  late final List<Offset> route;
  late final List<double> cumLen;
  late final double totalLen;
  late final List<BuildingSpec> buildings;
  late final List<ObstacleRuntime> obstacles;
  late final List<TrafficLight> lights;
  late final List<Offset> stopSigns;
  late final Rect routeBounds;

  MissionRuntime(this.def) {
    route = buildRoute(0, 0, 0, def.segLens, def.turnDegs);
    cumLen = buildCumLen(route);
    totalLen = cumLen.last;
    buildings = generateJapaneseBuildings(route, cumLen, totalLen, roadHalfWidth);
    obstacles = def.obstacles.map((spec) {
      final rp = pointAtDistance(route, cumLen, spec.distAlong);
      return ObstacleRuntime(type: spec.type, anchor: rp.pos, perp: rp.perp, moving: spec.moving, lateralRatio: spec.lateralRatio, phase: spec.distAlong * 0.37);
    }).toList();
    lights = def.lightDist.map((d) {
      final rp = pointAtDistance(route, cumLen, d);
      return TrafficLight(id: 'L$d', x: rp.pos.dx, y: rp.pos.dy);
    }).toList();
    stopSigns = def.stopSignDist.map((d) => pointAtDistance(route, cumLen, d).pos).toList();

    double minX = 0, maxX = 0, minY = 0, maxY = 0;
    for (final p in route) {
      minX = math.min(minX, p.dx);
      maxX = math.max(maxX, p.dx);
      minY = math.min(minY, p.dy);
      maxY = math.max(maxY, p.dy);
    }
    routeBounds = Rect.fromLTRB(minX - 100, minY - 100, maxX + 100, maxY + 100);
  }
}

// ============================================================================
// 7. PAINTER KENDERAAN & HALANGAN
// ============================================================================
void paintVehicleShape(Canvas canvas, {required bool isMoto, required Color color, double lean = 0}) {
  if (isMoto) {
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(12, -3 + lean, 10, 6), const Radius.circular(2)), Paint()..color = const Color(0xFF212121));
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(-16, -3 + lean, 10, 6), const Radius.circular(2)), Paint()..color = const Color(0xFF212121));
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(-12, -5 + lean, 24, 10), const Radius.circular(3)), Paint()..color = color);
    canvas.drawCircle(Offset(-2, lean), 6, Paint()..color = const Color(0xFF263238));
    canvas.drawCircle(Offset(2, lean), 4.5, Paint()..color = const Color(0xFFFFC107));
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(-20, -7 + lean, 12, 14), const Radius.circular(2)), Paint()..color = const Color(0xFFFF3D00));
  } else {
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-18, -12, 38, 24), const Radius.circular(5)), Paint()..color = color);
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-8, -9, 20, 18), const Radius.circular(3)), Paint()..color = const Color(0xFF37474F));
  }
}

void _paintObstacle(Canvas canvas, Offset o, ObstacleType type) {
  switch (type) {
    case ObstacleType.student:
      canvas.drawOval(Rect.fromCenter(center: Offset(o.dx, o.dy + 8), width: 14, height: 6), Paint()..color = Colors.black.withValues(alpha: 0.25));
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(o.dx, o.dy), width: 10, height: 16), const Radius.circular(3)), Paint()..color = const Color(0xFF3F51B5));
      canvas.drawCircle(Offset(o.dx, o.dy - 12), 5.5, Paint()..color = const Color(0xFFFFCC80));
      break;
    case ObstacleType.cat:
      canvas.drawOval(Rect.fromCenter(center: o, width: 16, height: 9), Paint()..color = const Color(0xFFFF9800));
      canvas.drawCircle(Offset(o.dx + 8, o.dy - 3), 5, Paint()..color = const Color(0xFFFF9800));
      break;
    case ObstacleType.duck:
      canvas.drawOval(Rect.fromCenter(center: o, width: 16, height: 10), Paint()..color = Colors.yellow.shade700);
      canvas.drawCircle(Offset(o.dx + 7, o.dy - 4), 5, Paint()..color = Colors.yellow.shade700);
      canvas.drawCircle(Offset(o.dx + 10, o.dy - 4), 2, Paint()..color = Colors.orange);
      break;
    case ObstacleType.bicycle:
    case ObstacleType.tricycle:
      canvas.drawCircle(o - const Offset(7, 0), 6, Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xFF212121));
      canvas.drawCircle(o + const Offset(7, 0), 6, Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xFF212121));
      canvas.drawLine(o - const Offset(7, 0), o + const Offset(7, 0), Paint()
        ..strokeWidth = 2
        ..color = const Color(0xFF1E88E5));
      break;
    case ObstacleType.book:
      canvas.drawRect(Rect.fromCenter(center: o, width: 12, height: 9), Paint()..color = const Color(0xFFEF5350));
      break;
    case ObstacleType.bin:
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: o, width: 16, height: 20), const Radius.circular(3)), Paint()..color = const Color(0xFF455A64));
      break;
    case ObstacleType.pothole:
      canvas.drawOval(Rect.fromCenter(center: o, width: 26, height: 14), Paint()..color = Colors.black.withValues(alpha: 0.55));
      break;
    case ObstacleType.puddle:
      canvas.drawOval(Rect.fromCenter(center: o, width: 30, height: 16), Paint()..color = const Color(0xFF4FC3F7).withValues(alpha: 0.55));
      break;
    case ObstacleType.cafeTable:
      canvas.drawCircle(o, 11, Paint()..color = const Color(0xFF8D6E63));
      canvas.drawCircle(o, 11, Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xFF5D4037));
      break;
    case ObstacleType.chair:
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: o, width: 12, height: 12), const Radius.circular(2)), Paint()..color = const Color(0xFF6D4C41));
      break;
    case ObstacleType.deliveryVan:
      canvas.save();
      canvas.translate(o.dx, o.dy);
      paintVehicleShape(canvas, isMoto: false, color: const Color(0xFFEC407A));
      canvas.restore();
      break;
    case ObstacleType.toybox:
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: o, width: 18, height: 14), const Radius.circular(3)), Paint()..color = const Color(0xFFFFB300));
      break;
    case ObstacleType.bench:
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: o, width: 26, height: 8), const Radius.circular(2)), Paint()..color = const Color(0xFF6D4C41));
      break;
    case ObstacleType.goldCoin:
      canvas.drawCircle(o, 8, Paint()..color = const Color(0xFFFFD54F));
      canvas.drawCircle(o, 8, Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5
        ..color = const Color(0xFFFF8F00));
      break;
  }
}

// ============================================================================
// 8. PAINTER BANDAR (LALUAN MELENGKUNG BERGAYA JEPUN)
// ============================================================================
class CityGamePainter extends CustomPainter {
  final MissionRuntime mission;
  final PlayerVehicle player;
  final List<RouteTrafficNpc> npcs;
  final List<TrafficLight> lights;
  final WeatherMode weather;
  final double camX;
  final double camY;
  final double time;
  final double startProgress;
  final double endProgress;

  CityGamePainter({
    required this.mission,
    required this.player,
    required this.npcs,
    required this.lights,
    required this.weather,
    required this.camX,
    required this.camY,
    required this.time,
    required this.startProgress,
    required this.endProgress,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final halfW = size.width / 2;
    final halfH = size.height / 2;
    double toX(double wx) => halfW + (wx - camX);
    double toY(double wy) => halfH + (wy - camY);

    final groundColor = weather == WeatherMode.night
        ? const Color(0xFF15261E)
        : weather == WeatherMode.snow
        ? const Color(0xFFE8F5E9)
        : const Color(0xFF81C784);
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), Paint()..color = groundColor);

    // --- Jalan (ribbon melengkung) ---
    final roadPath = Path();
    for (int i = 0; i < mission.route.length; i++) {
      final p = mission.route[i];
      if (i == 0) {
        roadPath.moveTo(toX(p.dx), toY(p.dy));
      } else {
        roadPath.lineTo(toX(p.dx), toY(p.dy));
      }
    }
    canvas.drawPath(
      roadPath,
      Paint()
        ..color = weather.roadColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = MissionRuntime.roadHalfWidth * 2
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round,
    );
    // Garisan tengah putus-putus
    final dashPaint = Paint()
      ..color = Colors.white.withValues(alpha: 0.85)
      ..strokeWidth = 3;
    double along = 0;
    while (along < mission.totalLen) {
      final a = pointAtDistance(mission.route, mission.cumLen, along);
      final b = pointAtDistance(mission.route, mission.cumLen, math.min(along + 14, mission.totalLen));
      canvas.drawLine(Offset(toX(a.pos.dx), toY(a.pos.dy)), Offset(toX(b.pos.dx), toY(b.pos.dy)), dashPaint);
      along += 28;
    }

    // --- Bahu jalan / kerb bergaris (penanda sempadan keras "tak boleh keluar jalan") ---
    final curbPathL = Path();
    final curbPathR = Path();
    for (int i = 0; i < mission.route.length; i++) {
      final rp = pointAtDistance(mission.route, mission.cumLen, mission.cumLen[i]);
      final lp = rp.pos + rp.perp * MissionRuntime.roadHalfWidth;
      final rpr = rp.pos - rp.perp * MissionRuntime.roadHalfWidth;
      if (i == 0) {
        curbPathL.moveTo(toX(lp.dx), toY(lp.dy));
        curbPathR.moveTo(toX(rpr.dx), toY(rpr.dy));
      } else {
        curbPathL.lineTo(toX(lp.dx), toY(lp.dy));
        curbPathR.lineTo(toX(rpr.dx), toY(rpr.dy));
      }
    }
    final curbPaint = Paint()
      ..color = const Color(0xFFFFEE58).withValues(alpha: 0.85)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(curbPathL, curbPaint);
    canvas.drawPath(curbPathR, curbPaint);

    // --- Pokok sakura (bunga sakura) menghiasi tepi jalan bergaya bandar Jepun ---
    double sakuraD = 90;
    while (sakuraD < mission.totalLen - 40) {
      final rp = pointAtDistance(mission.route, mission.cumLen, sakuraD);
      final side = (sakuraD ~/ 90).isOdd ? 1.0 : -1.0;
      final tp = rp.pos + rp.perp * (side * (MissionRuntime.roadHalfWidth + 16));
      final tx = toX(tp.dx);
      final ty = toY(tp.dy);
      canvas.drawRect(Rect.fromLTWH(tx - 2, ty - 18, 4, 18), Paint()..color = const Color(0xFF6D4C41));
      final blossomPaint = Paint()..color = const Color(0xFFF8BBD0).withValues(alpha: 0.92);
      for (final off in const [Offset(-9, -22), Offset(9, -22), Offset(0, -30), Offset(-6, -14), Offset(6, -14)]) {
        canvas.drawCircle(Offset(tx + off.dx, ty + off.dy), 9, blossomPaint);
      }
      sakuraD += 180;
    }

    // --- Beacon pickup / dropoff ---
    final pulse = (math.sin(time * 4) * 0.2 + 0.8);
    final start = mission.route.first;
    final end = mission.route.last;
    if (!player.hasPickedUp) {
      final px = toX(start.dx);
      final py = toY(start.dy);
      canvas.drawCircle(Offset(px, py), 45 * pulse, Paint()..color = const Color(0xFF4CAF50).withValues(alpha: 0.35 * pulse));
      canvas.drawCircle(Offset(px, py), 18, Paint()
        ..color = const Color(0xFF81C784)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4);
      final fy = py - 32 - math.sin(time * 5) * 6;
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(px - 14, fy - 14, 28, 28), const Radius.circular(4)), Paint()..color = const Color(0xFFFF9800));
    } else if (endProgress < mission.totalLen) {
      final dx = toX(end.dx);
      final dy = toY(end.dy);
      canvas.drawCircle(Offset(dx, dy), 45 * pulse, Paint()..color = const Color(0xFF00E5FF).withValues(alpha: 0.35 * pulse));
      canvas.drawCircle(Offset(dx, dy), 18, Paint()
        ..color = const Color(0xFF00B0FF)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4);
      final fy = dy - 32 - math.sin(time * 5) * 6;
      canvas.drawCircle(Offset(dx, fy), 14, Paint()..color = const Color(0xFFE91E63));
      canvas.drawCircle(Offset(dx, fy), 5, Paint()..color = Colors.white);
    }

    // --- Torii gate hiasan di permulaan laluan (identiti bandar Jepun) ---
    final toriiX = toX(start.dx - 60);
    final toriiY = toY(start.dy - 10);
    canvas.drawRect(Rect.fromLTWH(toriiX - 22, toriiY - 46, 6, 46), Paint()..color = const Color(0xFFD32F2F));
    canvas.drawRect(Rect.fromLTWH(toriiX + 16, toriiY - 46, 6, 46), Paint()..color = const Color(0xFFD32F2F));
    canvas.drawRect(Rect.fromLTWH(toriiX - 28, toriiY - 52, 60, 8), Paint()..color = const Color(0xFFB71C1C));
    canvas.drawRect(Rect.fromLTWH(toriiX - 22, toriiY - 38, 44, 5), Paint()..color = const Color(0xFF6D4C41));

    // --- Bangunan bergaya Jepun ---
    for (final b in mission.buildings) {
      final sx = toX(b.bx);
      final sy = toY(b.by);
      final shadowPath = Path()
        ..moveTo(sx + b.bw, sy)
        ..lineTo(sx + b.bw + b.h3d * 0.7, sy + b.h3d * 0.7)
        ..lineTo(sx + b.bw + b.h3d * 0.7, sy + b.bh + b.h3d * 0.7)
        ..lineTo(sx, sy + b.bh)
        ..close();
      canvas.drawPath(shadowPath, Paint()..color = Colors.black.withValues(alpha: 0.22));
      canvas.drawRect(Rect.fromLTWH(sx, sy, b.bw, b.bh), Paint()..color = b.front);
      final roofPath = Path()
        ..moveTo(sx, sy)
        ..lineTo(sx, sy - b.h3d)
        ..lineTo(sx + b.bw, sy - b.h3d)
        ..lineTo(sx + b.bw, sy)
        ..close();
      canvas.drawPath(roofPath, Paint()..color = b.side);
      canvas.drawRect(Rect.fromLTWH(sx, sy - b.h3d, b.bw, b.bh * 0.4), Paint()..color = b.roof);
      if (weather == WeatherMode.night) {
        canvas.drawRect(Rect.fromLTWH(sx + b.bw * 0.25, sy + b.bh * 0.2, 8, 8), Paint()..color = Colors.amber.withValues(alpha: 0.85));
        canvas.drawRect(Rect.fromLTWH(sx + b.bw * 0.6, sy + b.bh * 0.45, 8, 8), Paint()..color = Colors.amber.withValues(alpha: 0.7));
      }
    }

    // --- Tiang utiliti (hiasan bandar Jepun) ---
    double poleD = 40;
    while (poleD < mission.totalLen - 40) {
      final rp = pointAtDistance(mission.route, mission.cumLen, poleD);
      final side = (poleD ~/ 40).isEven ? 1.0 : -1.0;
      final pp = rp.pos + rp.perp * (side * (MissionRuntime.roadHalfWidth + 10));
      final px = toX(pp.dx);
      final py = toY(pp.dy);
      canvas.drawLine(Offset(px, py), Offset(px, py - 46), Paint()
        ..strokeWidth = 2.5
        ..color = const Color(0xFF616161));
      canvas.drawLine(Offset(px - 10, py - 40), Offset(px + 10, py - 40), Paint()
        ..strokeWidth = 1.5
        ..color = const Color(0xFF757575));
      // Tanglung kertas (chōchin) tergantung — identiti jalan bandar Jepun.
      final lanternColor = weather == WeatherMode.night ? const Color(0xFFFFAB40) : const Color(0xFFEF5350);
      canvas.drawOval(Rect.fromCenter(center: Offset(px, py - 30), width: 10, height: 14), Paint()..color = lanternColor.withValues(alpha: weather == WeatherMode.night ? 0.95 : 0.7));
      canvas.drawLine(Offset(px, py - 38), Offset(px, py - 34), Paint()
        ..strokeWidth = 1
        ..color = const Color(0xFF3E2723));
      poleD += 120;
    }

    // --- Lampu isyarat ---
    for (final light in lights) {
      final lx = toX(light.x);
      final ly = toY(light.y);
      canvas.drawRect(Rect.fromLTWH(lx - 3, ly - 40, 6, 40), Paint()..color = const Color(0xFF424242));
      final col = switch (light.color) {
        TrafficLightColor.green => const Color(0xFF00E676),
        TrafficLightColor.yellow => const Color(0xFFFFEB3B),
        TrafficLightColor.red => const Color(0xFFFF1744),
      };
      canvas.drawCircle(Offset(lx, ly - 46), 9, Paint()..color = Colors.black87);
      canvas.drawCircle(Offset(lx, ly - 46), 7, Paint()..color = col);
    }

    // --- Tanda STOP ---
    for (final s in mission.stopSigns) {
      final ssx = toX(s.dx);
      final ssy = toY(s.dy);
      canvas.drawRect(Rect.fromLTWH(ssx - 2, ssy - 34, 4, 34), Paint()..color = const Color(0xFF616161));
      canvas.drawCircle(Offset(ssx, ssy - 42), 13, Paint()..color = const Color(0xFFD32F2F));
      canvas.drawRect(Rect.fromLTWH(ssx - 9, ssy - 44, 18, 4), Paint()..color = Colors.white);
    }

    // --- Halangan sepanjang laluan ---
    for (final ob in mission.obstacles) {
      if (ob.collected) continue;
      final p = ob.currentPos(time, MissionRuntime.roadHalfWidth);
      _paintObstacle(canvas, Offset(toX(p.dx), toY(p.dy)), ob.type);
    }

    // --- Trafik ambien (kenderaan lain di jalan) ---
    for (final npc in npcs) {
      final rx = toX(npc.x);
      final ry = toY(npc.y);
      canvas.drawOval(Rect.fromLTWH(rx - 18, ry - 9, 36, 18), Paint()..color = Colors.black.withValues(alpha: 0.3));
      canvas.save();
      canvas.translate(rx, ry);
      canvas.rotate(npc.angle);
      paintVehicleShape(canvas, isMoto: npc.isMoto, color: npc.color);
      canvas.restore();
    }

    // --- Pemain ---
    final prx = toX(player.x);
    final pry = toY(player.y);
    canvas.drawOval(Rect.fromLTWH(prx - 18, pry - 9, 36, 18), Paint()..color = Colors.black.withValues(alpha: 0.35));
    canvas.save();
    canvas.translate(prx, pry);
    canvas.rotate(player.angle);
    final isMoto = player.vehicleId.category == VehicleCategory.motorcycle;
    paintVehicleShape(canvas, isMoto: isMoto, color: player.color, lean: isMoto ? player.leanAngle * 0.4 : 0);
    canvas.restore();

    // --- Lapisan cuaca ---
    if (weather == WeatherMode.night) {
      canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), Paint()..color = const Color(0xFF0D1B2A).withValues(alpha: 0.42));
    } else if (weather == WeatherMode.goldenAfternoon) {
      canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), Paint()..color = const Color(0xFFFFA726).withValues(alpha: 0.14));
    } else if (weather == WeatherMode.rain) {
      final rainPaint = Paint()
        ..color = Colors.white.withValues(alpha: 0.4)
        ..strokeWidth = 1.5;
      final t = time * 900;
      for (int i = 0; i < 100; i++) {
        final rx = (i * 137.5 + t * 0.3) % size.width;
        final ry = (i * 73.1 + t) % size.height;
        canvas.drawLine(Offset(rx, ry), Offset(rx - 4, ry + 16), rainPaint);
      }
    } else if (weather == WeatherMode.snow) {
      final snowPaint = Paint()..color = Colors.white.withValues(alpha: 0.8);
      final t = time * 150;
      for (int i = 0; i < 70; i++) {
        final sx = (i * 123.4 + math.sin(t * 0.05 + i) * 30) % size.width;
        final sy = (i * 67.8 + t) % size.height;
        canvas.drawCircle(Offset(sx, sy), (i % 3 + 2).toDouble(), snowPaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CityGamePainter oldDelegate) => true;
}

// ============================================================================
// 9. MINI-MAP, SPEEDOMETER & COCKPIT OVERLAY
// ============================================================================
class MiniMapPainter extends CustomPainter {
  final List<Offset> route;
  final Rect bounds;
  final double progress;
  final double totalLen;

  MiniMapPainter({required this.route, required this.bounds, required this.progress, required this.totalLen});

  Offset _map(Offset p, Size size) {
    final nx = (p.dx - bounds.left) / bounds.width;
    final ny = (p.dy - bounds.top) / bounds.height;
    return Offset(8 + nx * (size.width - 16), 8 + ny * (size.height - 16));
  }

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(0, 0, size.width, size.height), const Radius.circular(12)), Paint()..color = Colors.black.withValues(alpha: 0.55));

    final path = Path();
    for (int i = 0; i < route.length; i++) {
      final m = _map(route[i], size);
      if (i == 0) {
        path.moveTo(m.dx, m.dy);
      } else {
        path.lineTo(m.dx, m.dy);
      }
    }
    canvas.drawPath(path, Paint()
      ..color = Colors.white.withValues(alpha: 0.35)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round);

    // laluan yang telah dilalui
    final travelledPath = Path();
    double acc = 0;
    bool started = false;
    for (int i = 0; i < route.length - 1; i++) {
      final segLen = (route[i + 1] - route[i]).distance;
      if (acc + segLen < progress) {
        final m1 = _map(route[i], size);
        final m2 = _map(route[i + 1], size);
        if (!started) {
          travelledPath.moveTo(m1.dx, m1.dy);
          started = true;
        }
        travelledPath.lineTo(m2.dx, m2.dy);
      } else if (acc < progress) {
        final t = (progress - acc) / segLen;
        final cut = Offset(route[i].dx + (route[i + 1].dx - route[i].dx) * t, route[i].dy + (route[i + 1].dy - route[i].dy) * t);
        final m1 = _map(route[i], size);
        final m2 = _map(cut, size);
        if (!started) {
          travelledPath.moveTo(m1.dx, m1.dy);
          started = true;
        }
        travelledPath.lineTo(m2.dx, m2.dy);
        break;
      }
      acc += segLen;
    }
    canvas.drawPath(travelledPath, Paint()
      ..color = const Color(0xFF00E676)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.4
      ..strokeCap = StrokeCap.round);

    final playerRp = pointAtDistance(route, buildCumLen(route), progress);
    final pm = _map(playerRp.pos, size);
    canvas.drawCircle(pm, 5, Paint()..color = const Color(0xFF00E676));
    canvas.drawCircle(pm, 5, Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..color = Colors.white);

    final destM = _map(route.last, size);
    canvas.drawCircle(destM, 5, Paint()..color = const Color(0xFFFF1744));
  }

  @override
  bool shouldRepaint(covariant MiniMapPainter oldDelegate) => true;
}

class AnalogSpeedometerPainter extends CustomPainter {
  final double speed;
  final double maxSpeed;
  AnalogSpeedometerPainter({required this.speed, required this.maxSpeed});

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2 - 4;
    canvas.drawCircle(c, r, Paint()..color = Colors.black.withValues(alpha: 0.75));
    canvas.drawCircle(c, r, Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5
      ..color = Colors.white24);

    for (int i = 0; i <= 10; i++) {
      final a = math.pi * 0.75 + (math.pi * 1.5) * (i / 10);
      final p1 = c + Offset(math.cos(a), math.sin(a)) * (r - 8);
      final p2 = c + Offset(math.cos(a), math.sin(a)) * (r - 2);
      canvas.drawLine(p1, p2, Paint()
        ..strokeWidth = 2
        ..color = i % 5 == 0 ? Colors.white : Colors.white54);
    }

    final frac = (speed / maxSpeed).clamp(0.0, 1.0);
    final needleAngle = math.pi * 0.75 + (math.pi * 1.5) * frac;
    final tip = c + Offset(math.cos(needleAngle), math.sin(needleAngle)) * (r - 12);
    canvas.drawLine(c, tip, Paint()
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round
      ..color = frac > 0.85 ? const Color(0xFFFF1744) : const Color(0xFF00E5FF));
    canvas.drawCircle(c, 4, Paint()..color = Colors.white);
  }

  @override
  bool shouldRepaint(covariant AnalogSpeedometerPainter oldDelegate) => true;
}

class CockpitOverlayPainter extends CustomPainter {
  CockpitOverlayPainter();

  @override
  void paint(Canvas canvas, Size size) {
    // Vignette pilar A cermin depan (penjuru atas kiri & kanan)
    final leftPillar = Path()
      ..moveTo(0, 0)
      ..lineTo(size.width * 0.12, 0)
      ..lineTo(0, size.height * 0.35)
      ..close();
    final rightPillar = Path()
      ..moveTo(size.width, 0)
      ..lineTo(size.width * 0.88, 0)
      ..lineTo(size.width, size.height * 0.35)
      ..close();
    final pillarPaint = Paint()..color = Colors.black.withValues(alpha: 0.55);
    canvas.drawPath(leftPillar, pillarPaint);
    canvas.drawPath(rightPillar, pillarPaint);

    // Dashboard / tudung enjin di bawah skrin
    final dashHeight = size.height * 0.16;
    final dashPath = Path()
      ..moveTo(0, size.height)
      ..lineTo(0, size.height - dashHeight * 0.4)
      ..quadraticBezierTo(size.width * 0.5, size.height - dashHeight * 1.15, size.width, size.height - dashHeight * 0.4)
      ..lineTo(size.width, size.height)
      ..close();
    canvas.drawPath(dashPath, Paint()..color = const Color(0xFF1A1F26).withValues(alpha: 0.92));
    canvas.drawPath(
      dashPath,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = Colors.white10,
    );

    // Cermin pandang belakang kecil di tengah atas
    final mirrorRect = RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(size.width / 2, 14), width: 90, height: 16), const Radius.circular(6));
    canvas.drawRRect(mirrorRect, Paint()..color = Colors.black.withValues(alpha: 0.5));
    canvas.drawRRect(mirrorRect, Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..color = Colors.white24);
  }

  @override
  bool shouldRepaint(covariant CockpitOverlayPainter oldDelegate) => false;
}

// ============================================================================
// 10. WIDGET KAWALAN: STERENG & PEDAL
// ============================================================================
class SteeringWheelControl extends StatefulWidget {
  final ValueChanged<double> onChanged;
  const SteeringWheelControl({super.key, required this.onChanged});

  @override
  State<SteeringWheelControl> createState() => _SteeringWheelControlState();
}

class _SteeringWheelControlState extends State<SteeringWheelControl> with SingleTickerProviderStateMixin {
  double _angle = 0;
  static const double _maxAngle = 2.1; // ~120 darjah
  AnimationController? _springCtrl;

  void _report() => widget.onChanged((_angle / _maxAngle).clamp(-1.0, 1.0));

  void _onPanUpdate(DragUpdateDetails d, Size wheelSize) {
    _springCtrl?.stop();
    final center = Offset(wheelSize.width / 2, wheelSize.height / 2);
    final local = d.localPosition - center;
    double a = math.atan2(local.dy, local.dx) + math.pi / 2;
    if (a > math.pi) a -= 2 * math.pi;
    if (a < -math.pi) a += 2 * math.pi;
    setState(() => _angle = a.clamp(-_maxAngle, _maxAngle));
    _report();
  }

  void _onPanEnd(DragEndDetails d) {
    _springCtrl?.dispose();
    final start = _angle;
    _springCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 320));
    final anim = Tween<double>(begin: start, end: 0).animate(CurvedAnimation(parent: _springCtrl!, curve: Curves.easeOut));
    anim.addListener(() {
      setState(() => _angle = anim.value);
      _report();
    });
    _springCtrl!.forward();
  }

  @override
  void dispose() {
    _springCtrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const size = 130.0;
    return GestureDetector(
      onPanUpdate: (d) => _onPanUpdate(d, const Size(size, size)),
      onPanEnd: _onPanEnd,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.black45, border: Border.all(color: Colors.white24, width: 2)),
        child: Center(
          child: Transform.rotate(
            angle: _angle,
            child: Container(
              width: size - 14,
              height: size - 14,
              decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: const Color(0xFFECEFF1), width: 7)),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Container(width: 4, height: (size - 14) / 2 - 6, color: const Color(0xFFECEFF1)),
                  Transform.rotate(angle: math.pi / 3, child: Container(width: 4, height: (size - 14) / 2 - 6, color: const Color(0xFFECEFF1))),
                  Transform.rotate(angle: -math.pi / 3, child: Container(width: 4, height: (size - 14) / 2 - 6, color: const Color(0xFFECEFF1))),
                  Container(width: 26, height: 26, decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF0288D1))),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class PedalButton extends StatefulWidget {
  final String label;
  final IconData icon;
  final Color color;
  final ValueChanged<bool> onPressedChanged;
  const PedalButton({super.key, required this.label, required this.icon, required this.color, required this.onPressedChanged});

  @override
  State<PedalButton> createState() => _PedalButtonState();
}

class _PedalButtonState extends State<PedalButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) {
        setState(() => _pressed = true);
        widget.onPressedChanged(true);
      },
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onPressedChanged(false);
      },
      onTapCancel: () {
        setState(() => _pressed = false);
        widget.onPressedChanged(false);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 90),
        width: 78,
        height: 78,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _pressed ? widget.color : widget.color.withValues(alpha: 0.78),
          border: Border.all(color: Colors.white24, width: _pressed ? 3 : 1.5),
          boxShadow: _pressed ? [] : [BoxShadow(color: Colors.black.withValues(alpha: 0.4), blurRadius: 6, offset: const Offset(0, 3))],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(widget.icon, color: Colors.white),
            Text(widget.label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: Colors.white)),
          ],
        ),
      ),
    );
  }
}

// ============================================================================
// 11. MAIN MENU SCREEN (LANDSKAP)
// ============================================================================
class MainMenuScreen extends StatefulWidget {
  const MainMenuScreen({super.key});
  @override
  State<MainMenuScreen> createState() => _MainMenuScreenState();
}

class _MainMenuScreenState extends State<MainMenuScreen> {
  bool _soundOn = true;

  @override
  void initState() {
    super.initState();
    StorageManager.init().then((_) {
      if (mounted) setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Row(
          children: [
            // Kiri: jenama & status
            Expanded(
              flex: 4,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 56,
                          height: 56,
                          decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFFFF9800)),
                          child: const Icon(Icons.two_wheeler, size: 34, color: Colors.white),
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Text('DELIVERY RIDER 3D', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Colors.white)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    const Text('Hantar pesanan Kaoruko tepat waktu & patuh peraturan jalan raya.', style: TextStyle(color: Color(0xFF64B5F6), fontWeight: FontWeight.w600, fontSize: 12)),
                    const SizedBox(height: 20),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(color: const Color(0xFF1E293B), borderRadius: BorderRadius.circular(14)),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.monetization_on, color: Color(0xFFFFD54F), size: 20),
                          const SizedBox(width: 6),
                          Text('${StorageManager.coins} Coins', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                          const SizedBox(width: 16),
                          IconButton(
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(),
                            icon: Icon(_soundOn ? Icons.volume_up : Icons.volume_off, color: Colors.white, size: 20),
                            onPressed: () => setState(() {
                              _soundOn = !_soundOn;
                              SoundManager.isMuted = !_soundOn;
                            }),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Kanan: tindakan
            Expanded(
              flex: 3,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: double.infinity,
                      height: 56,
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF00C853), shape: roundedBorder(16)),
                        icon: const Icon(Icons.map_rounded),
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const MissionSelectScreen())).then((_) {
                            if (mounted) setState(() {});
                          });
                        },
                        label: const Text('PILIH MISI PENGHANTARAN', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: Colors.white)),
                      ),
                    ),
                    const SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: OutlinedButton.icon(
                        style: OutlinedButton.styleFrom(shape: roundedBorder(14), side: const BorderSide(color: Color(0xFF0288D1))),
                        icon: const Icon(Icons.storefront, color: Color(0xFF4FC3F7)),
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const ShopScreen())).then((_) {
                            if (mounted) setState(() {});
                          });
                        },
                        label: const Text('KEDAI & KUSTOM KENDERAAN', style: TextStyle(color: Color(0xFF4FC3F7), fontWeight: FontWeight.bold)),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Text('${StorageManager.completed} Penghantaran Selesai', style: const TextStyle(color: Colors.white54, fontSize: 12)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

RoundedRectangleBorder roundedBorder(double radius) => RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius));

// ============================================================================
// 12. SKRIN PILIH MISI (5 LOKASI KAORUKO WAGURI)
// ============================================================================
class MissionSelectScreen extends StatefulWidget {
  const MissionSelectScreen({super.key});
  @override
  State<MissionSelectScreen> createState() => _MissionSelectScreenState();
}

class _MissionSelectScreenState extends State<MissionSelectScreen> {
  @override
  Widget build(BuildContext context) {
    final unlocked = StorageManager.unlockedMissionIndex;
    return Scaffold(
      appBar: AppBar(title: const Text('Pilih Misi Penghantaran')),
      body: Padding(
        padding: const EdgeInsets.all(14),
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: MissionCatalog.all.length,
          separatorBuilder: (_, __) => const SizedBox(width: 14),
          itemBuilder: (_, i) {
            final m = MissionCatalog.all[i];
            final lock = i > unlocked;
            final stars = StorageManager.starsFor(m.id);
            return GestureDetector(
              onTap: () async {
                if (lock) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Selesaikan misi sebelumnya dahulu!')));
                  return;
                }
                await Navigator.push(context, MaterialPageRoute(builder: (_) => GameplayScreen(mission: m, missionIndex: i)));
                if (mounted) setState(() {});
              },
              child: Container(
                width: 220,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: lock ? const Color(0xFF1E293B).withValues(alpha: 0.5) : const Color(0xFF1E293B),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: lock ? Colors.transparent : const Color(0xFF0288D1), width: 1.4),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(lock ? Icons.lock : Icons.route, color: lock ? Colors.grey : const Color(0xFF4FC3F7), size: 30),
                    const SizedBox(height: 10),
                    Text(m.title, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: lock ? Colors.grey : Colors.white)),
                    const SizedBox(height: 4),
                    Text(m.subtitle, style: TextStyle(fontSize: 12, color: lock ? Colors.grey : const Color(0xFFFFD54F))),
                    const SizedBox(height: 10),
                    if (!lock)
                      Row(children: List.generate(3, (idx) => Icon(idx < stars ? Icons.star : Icons.star_border, color: Colors.amber, size: 16))),
                    const Spacer(),
                    if (!lock)
                      Text('${m.rewardCoins} Coins • ${m.rewardPoints} Pts', style: const TextStyle(fontSize: 11, color: Colors.white54)),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

// ============================================================================
// 13. KEDAI KENDERAAN
// ============================================================================
const List<int> _paletteColors = [
  0xFFFF5722, 0xFF2196F3, 0xFFE91E63, 0xFF4CAF50,
  0xFFFFEB3B, 0xFF9C27B0, 0xFF00BCD4, 0xFFFFFFFF,
];

class ShopScreen extends StatefulWidget {
  const ShopScreen({super.key});
  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> with SingleTickerProviderStateMixin {
  late AnimationController _anim;
  VehicleId _selected = VehicleId.scooter;
  int _color = 0xFFFF5722;
  late TextEditingController _plateCtrl;

  @override
  void initState() {
    super.initState();
    _anim = AnimationController(vsync: this, duration: const Duration(seconds: 8))..repeat();
    _selected = VehicleId.values.firstWhere((v) => v.name == StorageManager.vehicleName, orElse: () => VehicleId.scooter);
    _color = StorageManager.customColor;
    _plateCtrl = TextEditingController(text: StorageManager.plate);
  }

  @override
  void dispose() {
    _anim.dispose();
    _plateCtrl.dispose();
    super.dispose();
  }

  void _buy() {
    if (StorageManager.coins >= _selected.price) {
      setState(() {
        StorageManager.coins -= _selected.price;
        StorageManager.unlock(_selected);
        StorageManager.vehicleName = _selected.name;
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Coins tidak mencukupi untuk beli kenderaan ini!')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final unlocked = StorageManager.isUnlocked(_selected);
    final equipped = StorageManager.vehicleName == _selected.name;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Kedai Kenderaan'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(child: Text('${StorageManager.coins} Coins 🪙', style: const TextStyle(fontWeight: FontWeight.bold))),
          )
        ],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 760),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Container(
                height: 160,
                decoration: BoxDecoration(color: const Color(0xFF1E293B), borderRadius: BorderRadius.circular(20)),
                child: AnimatedBuilder(
                  animation: _anim,
                  builder: (ctx, child) {
                    return CustomPaint(
                      painter: _VehiclePreviewPainter(vehicle: _selected, color: Color(_color), angle: _anim.value * 2 * math.pi),
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                height: 80,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: VehicleId.values.map((v) {
                    final isSel = v == _selected;
                    return GestureDetector(
                      onTap: () => setState(() => _selected = v),
                      child: Container(
                        width: 140,
                        margin: const EdgeInsets.only(right: 10),
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(color: isSel ? const Color(0xFF0288D1) : const Color(0xFF1E293B), borderRadius: BorderRadius.circular(12)),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(v.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                            Text(StorageManager.isUnlocked(v) ? 'Dimiliki' : '${v.price} Coins', style: const TextStyle(fontSize: 11, color: Color(0xFFFFD54F))),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
              const SizedBox(height: 16),
              const Text('Warna Kenderaan', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: _paletteColors.map((c) {
                  final sel = c == _color;
                  return GestureDetector(
                    onTap: () => setState(() => _color = c),
                    child: Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(color: Color(c), shape: BoxShape.circle, border: Border.all(color: sel ? Colors.white : Colors.white24, width: sel ? 3 : 1)),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),
              const Text('Nombor Plat', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              TextField(
                controller: _plateCtrl,
                maxLength: 10,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'Cth: KILAT-07'),
              ),
              const SizedBox(height: 8),
              if (unlocked)
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: equipped ? const Color(0xFF2E7D32) : const Color(0xFF0288D1), minimumSize: const Size(double.infinity, 48)),
                  onPressed: () {
                    setState(() {
                      StorageManager.vehicleName = _selected.name;
                      StorageManager.customColor = _color;
                      StorageManager.plate = _plateCtrl.text.trim().isEmpty ? 'KILAT-07' : _plateCtrl.text.trim();
                    });
                  },
                  child: Text(equipped ? 'Sedang Dipasang ✓' : 'Pasang Kenderaan'),
                )
              else
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFF8F00), minimumSize: const Size(double.infinity, 48)),
                  onPressed: _buy,
                  child: Text('Beli (${_selected.price} Coins)'),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _VehiclePreviewPainter extends CustomPainter {
  final VehicleId vehicle;
  final Color color;
  final double angle;
  _VehiclePreviewPainter({required this.vehicle, required this.color, required this.angle});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    canvas.drawOval(Rect.fromLTWH(cx - 70, cy + 15, 140, 40), Paint()..color = const Color(0xFF334155));

    canvas.save();
    canvas.translate(cx, cy);
    canvas.rotate(angle);
    if (vehicle.category == VehicleCategory.motorcycle) {
      canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-20, -8, 40, 16), const Radius.circular(4)), Paint()..color = color);
      canvas.drawCircle(const Offset(-4, 0), 10, Paint()..color = const Color(0xFF263238));
      canvas.drawCircle(const Offset(4, 0), 7, Paint()..color = const Color(0xFFFFC107));
    } else {
      canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-35, -20, 70, 40), const Radius.circular(8)), Paint()..color = color);
      canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-15, -15, 35, 30), const Radius.circular(4)), Paint()..color = const Color(0xFF37474F));
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _VehiclePreviewPainter old) => true;
}

// ============================================================================
// 14. GAMEPLAY SCREEN & HUD
// ============================================================================
class GameplayScreen extends StatefulWidget {
  final MissionDef mission;
  final int missionIndex;
  const GameplayScreen({super.key, required this.mission, required this.missionIndex});
  @override
  State<GameplayScreen> createState() => _GameplayScreenState();
}

class _GameplayScreenState extends State<GameplayScreen> with SingleTickerProviderStateMixin {
  late AnimationController _gameLoop;
  late MissionRuntime _runtime;
  late PlayerVehicle _player;
  late List<RouteTrafficNpc> _npcs;
  final List<ActiveViolation> _violations = [];

  double _wheelValue = 0;
  bool _gasPressed = false;
  bool _brakePressed = false;
  double _timeRemaining = 60;
  int _score = 100;
  int _bonusCoins = 0;
  bool _cleanLicense = true;
  double _camX = 0;
  double _camY = 0;
  double _elapsed = 0;
  bool _gameOver = false;
  bool _started = false; // BAIKI: fizik & masa hanya jalan lepas dialog arahan ditutup

  double _offRouteCooldown = 0;
  bool _offRouteFlash = false;
  double _offRouteFlashTimer = 0;

  String _gpsText = 'Bersedia...';
  Timer? _gpsTimer;

  @override
  void initState() {
    super.initState();
    _runtime = MissionRuntime(widget.mission);
    _timeRemaining = widget.mission.timeLimit;
    _score = widget.mission.rewardPoints;

    final vId = VehicleId.values.firstWhere((v) => v.name == StorageManager.vehicleName, orElse: () => VehicleId.scooter);
    final start = _runtime.route.first;
    _player = PlayerVehicle(vehicleId: vId, color: Color(StorageManager.customColor), plate: StorageManager.plate, x: start.dx, y: start.dy);
    _camX = start.dx;
    _camY = start.dy;

    const npcCount = 9;
    const npcColors = [
      Color(0xFF26C6DA), Color(0xFFFFA726), Color(0xFF66BB6A), Color(0xFFCE93D8),
      Color(0xFFEF5350), Color(0xFF42A5F5), Color(0xFFFFCA28), Color(0xFF8D6E63), Color(0xFF78909C),
    ];
    _npcs = List.generate(npcCount, (i) {
      final lane = i.isEven ? -0.32 : 0.32;
      final dir = i.isEven ? 1.0 : -1.0;
      return RouteTrafficNpc(
        progress: (_runtime.totalLen / npcCount) * i,
        lateralRatio: lane,
        speed: (i % 3 == 0 ? 70.0 : 55.0) * dir,
        isMoto: i % 3 == 0,
        color: npcColors[i % npcColors.length],
      );
    });

    _gameLoop = AnimationController(vsync: this, duration: const Duration(seconds: 1))..repeat();
    _gameLoop.addListener(_updatePhysics);

    _gpsTimer = Timer.periodic(const Duration(milliseconds: 500), (t) => _updateGps());
    WidgetsBinding.instance.addPostFrameCallback((_) => _tunjukResepiPopup());
  }

  @override
  void dispose() {
    _gameLoop.dispose();
    _gpsTimer?.cancel();
    super.dispose();
  }

  void _updateGps() {
    if (!mounted || _gameOver || !_started) return;
    final proj = projectOntoRoute(_runtime.route, _runtime.cumLen, Offset(_player.x, _player.y));
    final remain = _runtime.totalLen - proj.progress;
    String text;
    if (_offRouteFlash) {
      text = '⚠️ PUSING BALIK! (Di Luar Jalan)';
    } else if (remain < 50) {
      text = '🏁 Destinasi di hadapan (<50m)';
    } else if (proj.segmentIndex < widget.mission.turnDegs.length) {
      final distToTurn = _runtime.cumLen[proj.segmentIndex + 1] - proj.progress;
      final turnDeg = widget.mission.turnDegs[proj.segmentIndex];
      final label = turnDeg > 0 ? 'Kanan' : 'Kiri';
      text = 'Belok $label ${distToTurn.clamp(0, 9999).round()}m';
    } else {
      text = 'Terus • Destinasi ${remain.round()}m';
    }
    setState(() => _gpsText = text);
  }

  void _tunjukResepiPopup() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text(widget.mission.title),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.mission.subtitle, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFFFD54F))),
            const SizedBox(height: 8),
            Text('Jarak: ${widget.mission.distanceMeters.round()}m • Had Masa: ${widget.mission.timeLimit.round()}s'),
            const SizedBox(height: 8),
            const Text('Ikut GPS, elak halangan jalan, dan patuh lampu isyarat & tanda STOP. Jangan terkeluar dari laluan!', style: TextStyle(fontSize: 12)),
          ],
        ),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFE91E63), foregroundColor: Colors.white),
            onPressed: () {
              // BAIKI: masa & fizik cuma bermula lepas pemain tekan "MULA HANTAR!"
              if (mounted) setState(() => _started = true);
              Navigator.pop(context);
            },
            child: const Text('MULA HANTAR!'),
          ),
        ],
      ),
    );
  }

  void _triggerViolation(ViolationType type) {
    _score = (_score - type.deduction).clamp(0, 999999);
    _cleanLicense = false;
    _player.totalViolations++;
    _violations.insert(0, ActiveViolation(type.title, type.deduction));
    if (_violations.length > 5) _violations.removeLast();
    SoundManager.playViolationBuzz();
  }

  void _updatePhysics() {
    if (!mounted || _gameOver || !_started) return;
    const dt = 0.016;
    _elapsed += dt;
    _timeRemaining = math.max(0, _timeRemaining - dt);

    final vDef = _player.vehicleId;
    final friction = widget.mission.weather.friction * vDef.slipResistance;

    // --- Kawalan stereng ---
    final speedFrac = (_player.currentSpeed / vDef.maxSpeed).clamp(0.0, 1.0);
    _player.angle += _wheelValue * dt * vDef.handling * 1.8 * (0.4 + speedFrac);
    _player.leanAngle = (_wheelValue * 25).clamp(-25, 25);

    // --- Pedal minyak & brek ---
    if (_gasPressed) {
      final thrust = vDef.accel * 20 * dt;
      _player.vx += math.cos(_player.angle) * thrust;
      _player.vy += math.sin(_player.angle) * thrust;
      _player.reversing = false;
    }
    if (_brakePressed) {
      if (_player.currentSpeed > 3) {
        _player.vx *= (1 - dt * 5.5);
        _player.vy *= (1 - dt * 5.5);
        _player.reversing = false;
        SoundManager.playBrake();
      } else {
        final revThrust = vDef.accel * 9 * dt;
        _player.vx -= math.cos(_player.angle) * revThrust;
        _player.vy -= math.sin(_player.angle) * revThrust;
        _player.reversing = true;
      }
    }
    if (!_gasPressed && !_brakePressed) {
      _player.vx *= (1 - dt * (1.2 - friction * 0.3));
      _player.vy *= (1 - dt * (1.2 - friction * 0.3));
      _player.reversing = false;
    }

    // Had laju maksimum kenderaan
    final spdNow = math.sqrt(_player.vx * _player.vx + _player.vy * _player.vy);
    final capSpeed = vDef.maxSpeed * 0.95;
    if (spdNow > capSpeed && spdNow > 0.001) {
      _player.vx = _player.vx / spdNow * capSpeed;
      _player.vy = _player.vy / spdNow * capSpeed;
    }

    _player.x += _player.vx * dt;
    _player.y += _player.vy * dt;
    _player.currentSpeed = math.sqrt(_player.vx * _player.vx + _player.vy * _player.vy) * 0.65;

    // --- Sempadan laluan keras: TAK BOLEH KELUAR JALAN/PETA (sisi + hujung) ---
    final route = _runtime.route;
    final proj = projectOntoRoute(route, _runtime.cumLen, Offset(_player.x, _player.y));
    bool hitBoundary = false;
    if (proj.lateralOffset.abs() > MissionRuntime.roadHalfWidth) {
      final sign = proj.lateralOffset.sign;
      final centerRp = pointAtDistance(route, _runtime.cumLen, proj.progress);
      final boundary = centerRp.pos + centerRp.perp * (sign * MissionRuntime.roadHalfWidth);
      _player.x = boundary.dx;
      _player.y = boundary.dy;
      final outward = centerRp.perp.dx * sign * _player.vx + centerRp.perp.dy * sign * _player.vy;
      if (outward > 0) {
        _player.vx -= centerRp.perp.dx * sign * outward;
        _player.vy -= centerRp.perp.dy * sign * outward;
      }
      hitBoundary = true;
    }
    // Sempadan hujung laluan: halang reverse sebelum permulaan / lajak selepas destinasi (dinding tak kelihatan).
    final a0 = route[0], b0 = route[1];
    final ab0 = b0 - a0;
    final len2_0 = ab0.dx * ab0.dx + ab0.dy * ab0.dy;
    final t0 = len2_0 > 0 ? (((_player.x - a0.dx) * ab0.dx + (_player.y - a0.dy) * ab0.dy) / len2_0) : 0.0;
    if (proj.segmentIndex == 0 && t0 < 0) {
      final angle0 = math.atan2(ab0.dy, ab0.dx);
      final perp0 = Offset(-math.sin(angle0), math.cos(angle0));
      final lateral0 = ((_player.x - a0.dx) * perp0.dx + (_player.y - a0.dy) * perp0.dy).clamp(-MissionRuntime.roadHalfWidth, MissionRuntime.roadHalfWidth);
      final cap0 = a0 + perp0 * lateral0;
      _player.x = cap0.dx;
      _player.y = cap0.dy;
      final fwd0 = ab0.distance > 0 ? ab0 / ab0.distance : const Offset(1, 0);
      final along0 = _player.vx * fwd0.dx + _player.vy * fwd0.dy;
      if (along0 < 0) {
        _player.vx -= fwd0.dx * along0;
        _player.vy -= fwd0.dy * along0;
      }
      hitBoundary = true;
    }
    final lastIdx = route.length - 1;
    final aN = route[lastIdx - 1], bN = route[lastIdx];
    final abN = bN - aN;
    final len2N = abN.dx * abN.dx + abN.dy * abN.dy;
    final tN = len2N > 0 ? (((_player.x - aN.dx) * abN.dx + (_player.y - aN.dy) * abN.dy) / len2N) : 0.0;
    if (proj.segmentIndex == lastIdx - 1 && tN > 1) {
      final angleN = math.atan2(abN.dy, abN.dx);
      final perpN = Offset(-math.sin(angleN), math.cos(angleN));
      final lateralN = ((_player.x - bN.dx) * perpN.dx + (_player.y - bN.dy) * perpN.dy).clamp(-MissionRuntime.roadHalfWidth, MissionRuntime.roadHalfWidth);
      final capN = bN + perpN * lateralN;
      _player.x = capN.dx;
      _player.y = capN.dy;
      final fwdN = abN.distance > 0 ? abN / abN.distance : const Offset(1, 0);
      final alongN = _player.vx * fwdN.dx + _player.vy * fwdN.dy;
      if (alongN > 0) {
        _player.vx -= fwdN.dx * alongN;
        _player.vy -= fwdN.dy * alongN;
      }
      hitBoundary = true;
    }
    if (hitBoundary) {
      _offRouteFlash = true;
      _offRouteFlashTimer = 1.0;
      if (_offRouteCooldown <= 0) {
        _triggerViolation(ViolationType.offRoute);
        _offRouteCooldown = 1.2;
      }
    }
    if (_offRouteCooldown > 0) _offRouteCooldown -= dt;
    if (_offRouteFlashTimer > 0) {
      _offRouteFlashTimer -= dt;
      if (_offRouteFlashTimer <= 0) _offRouteFlash = false;
    }

    // --- Trafik ambien di jalan ---
    for (final npc in _npcs) {
      npc.progress += npc.speed * dt;
      if (npc.progress > _runtime.totalLen) npc.progress -= _runtime.totalLen;
      if (npc.progress < 0) npc.progress += _runtime.totalLen;
      final rp = pointAtDistance(_runtime.route, _runtime.cumLen, npc.progress);
      final pos = rp.pos + rp.perp * (npc.lateralRatio * MissionRuntime.roadHalfWidth);
      npc.x = pos.dx;
      npc.y = pos.dy;
      npc.angle = npc.speed < 0 ? rp.angle + math.pi : rp.angle;
    }
    for (final light in _runtime.lights) {
      light.update(dt);
    }

    final nearPickup = proj.progress < 60 && !_player.hasPickedUp;
    final nearDropoff = _player.hasPickedUp && (_runtime.totalLen - proj.progress) < 60;

    if (_player.collisionCooldown > 0) _player.collisionCooldown -= dt;
    if (_player.bumpCooldown > 0) _player.bumpCooldown -= dt;

    // --- Perlanggaran bangunan ---
    for (final b in _runtime.buildings) {
      final inflated = Rect.fromLTWH(b.bx - 12, b.by - 12, b.bw + 24, b.bh + 24);
      if (inflated.contains(Offset(_player.x, _player.y))) {
        final cx = b.bx + b.bw / 2;
        final cy = b.by + b.bh / 2;
        var dx = _player.x - cx;
        var dy = _player.y - cy;
        final dist = math.sqrt(dx * dx + dy * dy).clamp(0.001, double.infinity);
        dx /= dist;
        dy /= dist;
        _player.x = cx + dx * (inflated.width / 2);
        _player.y = cy + dy * (inflated.height / 2);
        _player.vx = 0;
        _player.vy = 0;
        if (_player.collisionCooldown <= 0) {
          _triggerViolation(ViolationType.collision);
          _player.collisionCooldown = 1.0;
        }
        break;
      }
    }

    // --- Perlanggaran kenderaan lain ---
    for (final npc in _npcs) {
      final dist = _distTo(_player.x, _player.y, npc.x, npc.y);
      if (dist < 30) {
        if (_player.collisionCooldown <= 0) {
          _triggerViolation(ViolationType.collision);
          _player.collisionCooldown = 1.0;
        }
        if (dist > 0.001) {
          _player.vx += (_player.x - npc.x) / dist * 40;
          _player.vy += (_player.y - npc.y) / dist * 40;
        }
      }
    }

    // --- Halangan sepanjang laluan ---
    for (final ob in _runtime.obstacles) {
      if (ob.collected) continue;
      final p = ob.currentPos(_elapsed, MissionRuntime.roadHalfWidth);
      final dist = _distTo(_player.x, _player.y, p.dx, p.dy);
      final behavior = behaviorOf(ob.type);
      if (behavior == ObstacleBehavior.collectible) {
        if (dist < 24) {
          ob.collected = true;
          _bonusCoins += 10;
          SoundManager.playCoin();
          _violations.insert(0, ActiveViolation('🪙 +10 Coins Emas!', 0));
        }
        continue;
      }
      if (dist < 24) {
        if (behavior == ObstacleBehavior.solidBlock || behavior == ObstacleBehavior.hazardHit) {
          if (_player.collisionCooldown <= 0) {
            _triggerViolation(ViolationType.obstacleHit);
            _player.collisionCooldown = 1.0;
            _player.vx *= 0.2;
            _player.vy *= 0.2;
          }
        } else if (behavior == ObstacleBehavior.bump) {
          if (_player.bumpCooldown <= 0) {
            _player.vx *= 0.45;
            _player.vy *= 0.45;
            _player.bumpCooldown = 1.2;
            SoundManager.playBump();
            _violations.insert(0, ActiveViolation('💥 BUMP! Elak lubang jalan!', 0));
          }
        }
      }
    }

    // --- Had laju ---
    final limit = vDef.maxSpeed * 0.7;
    if (_player.currentSpeed > limit) {
      _player.speedingTimer += dt;
      if (_player.speedingTimer > 1.5) {
        _triggerViolation(ViolationType.speeding);
        _player.speedingTimer = 0;
      }
    } else {
      _player.speedingTimer = 0;
    }

    // --- Lampu merah ---
    for (final light in _runtime.lights) {
      final d = _distTo(_player.x, _player.y, light.x, light.y);
      final armed = _player.lightArmed.putIfAbsent(light.id, () => true);
      if (d < 45 && light.color == TrafficLightColor.red && _player.currentSpeed > 8 && armed) {
        _triggerViolation(ViolationType.redLight);
        _player.lightArmed[light.id] = false;
      } else if (d > 150) {
        _player.lightArmed[light.id] = true;
      }
    }

    // --- Tanda STOP ---
    for (final s in _runtime.stopSigns) {
      final dSign = _distTo(_player.x, _player.y, s.dx, s.dy);
      if (dSign < 70) {
        if (!_player.insideStopZone) {
          _player.insideStopZone = true;
          _player.stoppedAtSignThisPass = false;
          _player.stopHoldTimer = 0;
        }
        if (_player.currentSpeed < 3) {
          _player.stopHoldTimer += dt;
          if (_player.stopHoldTimer > 0.6) _player.stoppedAtSignThisPass = true;
        } else {
          _player.stopHoldTimer = 0;
        }
      } else if (_player.insideStopZone) {
        _player.insideStopZone = false;
        if (!_player.stoppedAtSignThisPass) {
          _triggerViolation(ViolationType.stopSign);
        }
      }
    }

    // --- Kamera ikut pemain ---
    _camX += (_player.x - _camX) * (dt * 6);
    _camY += (_player.y - _camY) * (dt * 6);

    for (final v in _violations) {
      v.ttl -= dt;
    }
    _violations.removeWhere((v) => v.ttl <= 0);

    // --- Ambil / hantar pesanan ---
    if (!_player.hasPickedUp) {
      if (nearPickup) {
        _player.hasPickedUp = true;
        SoundManager.playPickupChime();
        _violations.insert(0, ActiveViolation('📦 Bungkusan Diambil! Hantar segera!', 0));
      }
    } else if (nearDropoff) {
      _gameOver = true;
      _gameLoop.stop();
      SoundManager.playVictoryFanfare();
      final totalCoins = widget.mission.rewardCoins + _bonusCoins + (_cleanLicense ? 25 : 0);
      StorageManager.coins += totalCoins;
      StorageManager.completed += 1;
      final stars = _cleanLicense && _score >= widget.mission.rewardPoints * 0.9
          ? 3
          : _score >= widget.mission.rewardPoints * 0.6
          ? 2
          : 1;
      StorageManager.saveStars(widget.mission.id, stars);
      StorageManager.unlockMission(widget.missionIndex + 1);
      _showVictoryDialog(totalCoins, stars);
    }

    if (_timeRemaining <= 0 && !_gameOver) {
      _gameOver = true;
      _gameLoop.stop();
      _showFailDialog();
    }

    if (mounted) setState(() {});
  }

  void _showVictoryDialog(int totalCoins, int stars) {
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1E293B),
        title: const Text('HANTARAN SELESAI! 🎉', style: TextStyle(color: Color(0xFFFFD54F))),
        content: Text(
          'Tahniah! Anda berjaya menghantar pesanan ke ${widget.mission.title}.\n'
              'Bintang: ${'⭐' * stars}\n'
              'Skor: $_score Pts\n'
              'Pelanggaran: ${_player.totalViolations}\n'
              'Coins: +$totalCoins${_cleanLicense ? ' (+25 bonus lesen bersih!)' : ''} 🪙',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Menu Misi'),
          )
        ],
      ),
    );
  }

  void _showFailDialog() {
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1E293B),
        title: const Text('MASA TAMAT! ⏱️', style: TextStyle(color: Color(0xFFFF5252))),
        content: const Text('Pesanan gagal dihantar tepat waktu. Cuba lagi?'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Menu Misi'),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final proj = projectOntoRoute(_runtime.route, _runtime.cumLen, Offset(_player.x, _player.y));
    final flashOn = _offRouteFlash && (math.sin(_elapsed * 12) > 0);
    final gear = _player.currentSpeed < 1 && !_gasPressed && !_brakePressed
        ? 'N'
        : (_player.reversing ? 'R' : 'D');

    return Scaffold(
      body: Stack(
        children: [
          CustomPaint(
            size: Size.infinite,
            painter: CityGamePainter(
              mission: _runtime,
              player: _player,
              npcs: _npcs,
              lights: _runtime.lights,
              weather: widget.mission.weather,
              camX: _camX,
              camY: _camY,
              time: _elapsed,
              startProgress: 0,
              endProgress: proj.progress,
            ),
          ),
          // "View Dalam Kenderaan": dashboard, pilar & cermin
          Positioned.fill(child: IgnorePointer(child: CustomPaint(painter: CockpitOverlayPainter()))),

          // HUD Atas
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // GPS + status kiri atas
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          decoration: BoxDecoration(
                            color: flashOn ? const Color(0xFFD50000) : Colors.black87,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(mainAxisSize: MainAxisSize.min, children: [
                            const Icon(Icons.navigation_rounded, color: Colors.white, size: 16),
                            const SizedBox(width: 6),
                            Text(_gpsText, style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 13)),
                          ]),
                        ),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(color: _timeRemaining <= 15 ? Colors.red : Colors.green.shade700, borderRadius: BorderRadius.circular(12)),
                          child: Row(mainAxisSize: MainAxisSize.min, children: [
                            const Icon(Icons.timer, color: Colors.white, size: 14),
                            const SizedBox(width: 4),
                            Text('${_timeRemaining.toInt()}s | $_score Pts', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
                          ]),
                        ),
                        const SizedBox(height: 6),
                        ..._violations.take(3).map((v) {
                          final opacity = (v.ttl / 2.5).clamp(0.0, 1.0);
                          final isViolation = v.points > 0;
                          return Opacity(
                            opacity: opacity,
                            child: Container(
                              margin: const EdgeInsets.only(bottom: 4),
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                              decoration: BoxDecoration(color: (isViolation ? const Color(0xFFB71C1C) : const Color(0xFF2E7D32)).withValues(alpha: 0.85), borderRadius: BorderRadius.circular(10)),
                              child: Text(v.message, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11)),
                            ),
                          );
                        }),
                      ],
                    ),
                  ),
                  // Mini-map kanan atas
                  SizedBox(
                    width: 150,
                    height: 110,
                    child: CustomPaint(
                      painter: MiniMapPainter(route: _runtime.route, bounds: _runtime.routeBounds, progress: proj.progress, totalLen: _runtime.totalLen),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Speedometer analog + digital (tengah atas dashboard)
          Positioned(
            bottom: 6,
            left: 0,
            right: 0,
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    width: 86,
                    height: 86,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        CustomPaint(size: const Size(86, 86), painter: AnalogSpeedometerPainter(speed: _player.currentSpeed, maxSpeed: _player.vehicleId.maxSpeed)),
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text('${_player.currentSpeed.toInt()}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: Colors.white)),
                            const Text('km/j', style: TextStyle(fontSize: 9, color: Colors.white70)),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
                    decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(8)),
                    child: Text(gear, style: const TextStyle(color: Color(0xFF00E5FF), fontWeight: FontWeight.w900, fontSize: 13)),
                  ),
                ],
              ),
            ),
          ),

          // Stereng (kiri-tengah)
          Positioned(
            left: 18,
            top: 0,
            bottom: 0,
            child: Center(
              child: SteeringWheelControl(onChanged: (v) => _wheelValue = v),
            ),
          ),

          // Pedal brek & minyak (kanan) — brek di kiri pasangan, minyak paling kanan
          Positioned(
            right: 18,
            bottom: 26,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                PedalButton(label: 'BREK', icon: Icons.do_not_step, color: const Color(0xFFB71C1C), onPressedChanged: (v) => _brakePressed = v),
                const SizedBox(width: 14),
                PedalButton(label: 'MINYAK', icon: Icons.speed, color: const Color(0xFF2E7D32), onPressedChanged: (v) => _gasPressed = v),
              ],
            ),
          ),

          // Hon (atas pedal)
          Positioned(
            right: 26,
            bottom: 116,
            child: GestureDetector(
              onTap: SoundManager.playHorn,
              child: Container(
                width: 50,
                height: 50,
                decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFFFFB300)),
                child: const Icon(Icons.campaign, color: Colors.black, size: 22),
              ),
            ),
          ),
        ],
      ),
    );
  }
}