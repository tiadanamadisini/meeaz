import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:file_picker/file_picker.dart';
import 'package:gal/gal.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';
import '../models/message.dart';
import '../services/chat_service.dart';
import '../services/image_service.dart';
import '../services/notification_service.dart';
import '../services/document_service.dart';
import '../services/memory_service.dart';
import '../services/voice_service.dart';
import 'kaoruko_profile_screen.dart';
import 'translation_screen.dart';
import 'features_screens.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final List<Message> _messages = [];
  final TextEditingController _controller = TextEditingController();
  final ChatService _chatService = ChatService();
  final ImageService _imageService = ImageService();
  final ScrollController _scrollController = ScrollController();
  final NotificationService _notificationService = NotificationService();
  final DocumentService _documentService = DocumentService();
  final VoiceService _voiceService = VoiceService();
  final ImagePicker _imagePicker = ImagePicker();

  bool _isLoading = false;
  bool _isGeneratingImage = false;
  bool _isReadingDocument = false;
  bool _isSendingImage = false;
  bool _isListening = false;
  static const String _storageKey = 'kaoruko_chat_history';

  // Mesej yang sedang dipilih untuk dibalas (feature reply). Null = tiada.
  Message? _mesejUntukDibalas;

  // Kata kunci ringkas untuk kesan permintaan gambar dalam Bahasa Melayu.
  static final RegExp _permintaanGambar = RegExp(
    r'\b(gambar|gambo|poto|foto|pic|picture|selfie)\b',
    caseSensitive: false,
  );

  // Gambar Kaoruko yang sedia ada dalam assets — dipakai untuk permintaan
  // gambar GENERIK (contoh: "gambar awak", "ada gambar kaoruko tak")
  // supaya rupa dia konsisten 100% dgn rupa asal, tanpa perlu generate.
  static const List<String> _gambarAsetKaoruko = [
    'assets/pfp.jpg',
    'assets/gmbr1.jpeg',
    'assets/gmbr2.jpeg',
  ];

  // Kata-kata "filler" yang selalu muncul dalam ayat minta gambar tapi
  // tak bawa maksud scene/konteks khusus (nak, gambar, awak, dll). Kalau
  // lepas buang semua ni baki ayat dah kosong/hampir kosong, maksudnya
  // permintaan tu generik je ("gambar awak") — bukan minta scene
  // tertentu ("gambar awak makan cake").
  static final RegExp _kataFillerGambar = RegExp(
    r'\b(nak|nk|mahu|mau|minta|mintak|boleh|blh|tolong|tlg|ada|ade|dapat|'
    r'x|tak|ta|gambar|gambo|poto|foto|pic|picture|selfie|jana|generate|'
    r'tunjuk|awak|awk|kau|'
    r'korang|diri|sendiri|waguri|kaoruko|punya|punye|dong|eh|lah|la|ke|'
    r'sikit|skit|satu|satuu|please|pls|tau|tak2)\b',
    caseSensitive: false,
  );

  bool _permintaanGambarGenerik(String text) {
    final baki = text
        .replaceAll(_kataFillerGambar, ' ')
        .replaceAll(RegExp(r'[^\w\s]'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    // Kalau baki lebih dari 2-3 huruf, anggap ada konteks/scene khusus
    // (contoh "makan cake", "pakai baju sekolah") — bukan generik lagi.
    return baki.length <= 3;
  }

  static const Color _roseAccent = Color(0xFFC97C6D);

  Color get _inkText => Theme.of(context).colorScheme.onSurface;
  Color get _bubbleKaoruko => Theme.of(context).colorScheme.surface;
  Color get _bubbleUser => Theme.of(context).colorScheme.onSurface; // Better contrast in dark mode

  @override
  void initState() {
    super.initState();
    _notificationService.init().then((_) => _mintaKebenaranNotifikasi());
    _voiceService.init();
    _muatMesejTersimpan().then((_) {
      _semakKataSemangatHarian();
    });
  }

  Future<void> _mintaKebenaranNotifikasi() async {
    final status = await Permission.notification.status;
    if (status.isDenied) {
      if (mounted) {
        final result = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Notifikasi'),
            content: const Text('Kaoruko Waguri ingin menghantar notifikasi apabila dia membalas mesej anda.'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Nanti')),
              TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Boleh')),
            ],
          ),
        );
        if (result == true) {
          await _notificationService.requestPermission();
        }
      }
    }
  }

  // 1. Muat sejarah sembang dari Local Storage
  Future<void> _muatMesejTersimpan() async {
    final prefs = await SharedPreferences.getInstance();
    final String? savedData = prefs.getString(_storageKey);
    if (savedData != null && savedData.isNotEmpty) {
      try {
        final List<dynamic> jsonList = jsonDecode(savedData);
        setState(() {
          _messages.clear();
          _messages.addAll(jsonList.map((item) => Message.fromJson(item)));
        });
        _scrollToBottom();
      } catch (e) {
        debugPrint('Ralat membaca simpanan perbualan: $e');
      }
    }
  }

  // 2. Simpan sejarah sembang ke Local Storage
  Future<void> _simpanMesejKeStorage() async {
    final prefs = await SharedPreferences.getInstance();
    final String encodedData =
        jsonEncode(_messages.map((m) => m.toJson()).toList());
    await prefs.setString(_storageKey, encodedData);
  }

  Future<void> _exportChat() async {
    try {
      final payload = {
        'format': 'kaoruko_chat_export',
        'version': 1,
        'exportedAt': DateTime.now().toIso8601String(),
        'messages': _messages.map((message) => message.toJson()).toList(),
      };
      final bytes = Uint8List.fromList(utf8.encode(jsonEncode(payload)));
      await Share.shareXFiles(
        [
          XFile.fromData(
            bytes,
            name: 'kaoruko_chat_export.json',
            mimeType: 'application/json',
          ),
        ],
        text: 'Export sejarah chat Kaoruko Waguri',
      );
    } catch (error) {
      _paparNotis('Gagal export chat: $error');
    }
  }

  Future<void> _importChat() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['json'],
        withData: true,
      );
      if (result == null || result.files.isEmpty) return;

      final file = result.files.first;
      final bytes = file.bytes ??
          (file.path != null ? await File(file.path!).readAsBytes() : null);
      if (bytes == null) throw Exception('Fail tidak dapat dibaca.');

      final decoded = jsonDecode(utf8.decode(bytes));
      final rawMessages =
          decoded is Map<String, dynamic> ? decoded['messages'] : decoded;
      if (rawMessages is! List) {
        throw Exception('Format fail chat tidak sah.');
      }

      final imported = rawMessages
          .whereType<Map>()
          .map((item) => Message.fromJson(Map<String, dynamic>.from(item)))
          .toList();
      if (!mounted) return;
      setState(() {
        _messages
          ..clear()
          ..addAll(imported);
      });
      await _simpanMesejKeStorage();
      _scrollToBottom();
      _paparNotis('${imported.length} mesej berjaya diimport.');
    } catch (error) {
      _paparNotis('Gagal import chat: $error');
    }
  }

  void _paparNotis(String teks) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(teks)));
  }

  void _bukaProfilKaoruko() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            KaorukoProfileScreen(messages: List.unmodifiable(_messages)),
      ),
    );
  }

  void _bukaLiveTranslate() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const TranslationScreen()),
    );
  }

  // 3. Sistem Kata Semangat Automatik (Pagi & Malam)
  Future<void> _semakKataSemangatHarian() async {
    final prefs = await SharedPreferences.getInstance();
    final now = DateTime.now();
    final todayStr = '${now.year}-${now.month}-${now.day}';

    final String? lastMorning = prefs.getString('last_morning_greeting');
    final String? lastNight = prefs.getString('last_night_greeting');

    // Pagi (5:00 AM - 11:59 AM)
    if (now.hour >= 5 && now.hour < 12 && lastMorning != todayStr) {
      const morningText =
          'Selamat pagi! Semoga hari ini dipermudahkan dan penuh dengan keceriaan. Jangan lupa sarapan ya! 🌸';
      await _tambahMesejKaorukoOtomatik(morningText);
      await prefs.setString('last_morning_greeting', todayStr);
    }
    // Malam (9:00 PM - 11:59 PM)
    else if (now.hour >= 21 && lastNight != todayStr) {
      const nightText =
          'Selamat malam... Terima kasih sebab dah berusaha keras hari ini. Rehat secukupnya ya, mimpi yang indah! 🌙';
      await _tambahMesejKaorukoOtomatik(nightText);
      await prefs.setString('last_night_greeting', todayStr);
    }
  }

  Future<void> _tambahMesejKaorukoOtomatik(String text) async {
    final msg = Message(text: text, sender: Sender.kaoruko);
    setState(() {
      _messages.add(msg);
    });
    await _simpanMesejKeStorage();
    _scrollToBottom();
    _notificationService.showNotification(
      title: 'Kaoruko Waguri 🌸',
      body: text,
    );
  }

  Future<void> _sendMessage() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;

    final balasan = _mesejUntukDibalas;
    final mesejBaru = Message(
      text: text,
      sender: Sender.user,
      replyToText: balasan?.text,
      replyToSender: balasan?.sender,
    );

    setState(() {
      _messages.add(mesejBaru);
      _isLoading = true;
      _mesejUntukDibalas = null;
    });
    _controller.clear();
    await _simpanMesejKeStorage();
    _scrollToBottom();

    // Kalau mesej macam permintaan gambar, layan dulu sebelum hantar ke
    // chat AI biasa — generik guna asset sedia ada, specific (ada
    // scene/konteks) baru generate guna AI.
    if (_permintaanGambar.hasMatch(text)) {
      if (_permintaanGambarGenerik(text)) {
        await _hantarGambarAsetSedia();
      } else {
        await _jawabDenganGambar(text);
      }
      return;
    }

    try {
      final reply = await _chatService.sendMessage(_messages);
      if (!mounted) return;

      setState(() {
        _messages.add(Message(text: reply, sender: Sender.kaoruko));
      });
      await _simpanMesejKeStorage();

      // Hantar notifikasi peranti
      _notificationService.showNotification(
        title: 'Mesej daripada Kaoruko Waguri',
        body: reply,
      );

      // Kemas kini memori user secara senyap
      MemoryService().extractAndSummarize(_messages);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _messages.add(Message(
          text: 'Ralat: ${e.toString().replaceAll('Exception: ', '')}',
          sender: Sender.kaoruko,
        ));
      });
      await _simpanMesejKeStorage();
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
        _scrollToBottom();
      }
    }
  }

  // Untuk permintaan gambar GENERIK (contoh: "gambar awak", "ada gambar
  // kaoruko tak") — hantar terus salah satu gambar sedia ada dalam
  // assets, supaya rupa dia tetap konsisten dengan rupa asal (bukan
  // rupa AI-generate yang boleh berubah-ubah).
  Future<void> _hantarGambarAsetSedia() async {
    setState(() => _isGeneratingImage = true);
    try {
      final senaraiAcak = List<String>.from(_gambarAsetKaoruko)..shuffle();
      final asetTerpilih = senaraiAcak.first;

      final byteData = await rootBundle.load(asetTerpilih);
      final base64Str = base64Encode(byteData.buffer.asUint8List(
        byteData.offsetInBytes,
        byteData.lengthInBytes,
      ));

      if (!mounted) return;
      setState(() {
        _messages.add(Message(
          text: '',
          sender: Sender.kaoruko,
          imageBase64: base64Str,
        ));
      });
      await _simpanMesejKeStorage();
      _notificationService.showNotification(
        title: 'Kaoruko Waguri 🌸',
        body: 'Hantar gambar untuk awak!',
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _messages.add(Message(
          text: 'Ralat: ${e.toString().replaceAll('Exception: ', '')}',
          sender: Sender.kaoruko,
        ));
      });
      await _simpanMesejKeStorage();
    } finally {
      if (mounted) {
        setState(() {
          _isGeneratingImage = false;
          _isLoading = false;
        });
        _scrollToBottom();
      }
    }
  }

  // Jana gambar guna ImageService, papar sebagai bubble imej daripada
  // Kaoruko. Kalau gagal, papar mesej ralat mesra sebagai teks biasa.
  Future<void> _jawabDenganGambar(String arahan) async {
    setState(() => _isGeneratingImage = true);
    try {
      // Dapatkan konteks masa automatik mengikut spesifikasi ciri 2.1
      final timeContext = _dapatkanKonteksMasa();

      final base64Data = await _imageService.generateImage(
        arahan,
        includeKaoruko: true, // Untuk permintaan gambar Kaoruko
        timeContext: timeContext,
      );
      if (!mounted) return;

      if (base64Data == null) {
        setState(() {
          _messages.add(Message(
            text:
                'Eh maaf, Kaoruko Waguri tak dapat nak hantar gambar sekarang. Cuba lagi sekejap lagi ya 🥲',
            sender: Sender.kaoruko,
          ));
        });
      } else {
        setState(() {
          _messages.add(Message(
            text: '',
            sender: Sender.kaoruko,
            imageBase64: base64Data,
          ));
        });
        _notificationService.showNotification(
          title: 'Kaoruko Waguri 🌸',
          body: 'Hantar gambar untuk awak!',
        );
      }
      await _simpanMesejKeStorage();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _messages.add(Message(
          text: 'Ralat: ${e.toString().replaceAll('Exception: ', '')}',
          sender: Sender.kaoruko,
        ));
      });
      await _simpanMesejKeStorage();
    } finally {
      if (mounted) {
        setState(() {
          _isGeneratingImage = false;
          _isLoading = false;
        });
        _scrollToBottom();
      }
    }
  }

  // Pengguna tekan butang attach (📎) — buka file picker, extract teks
  // dari PDF/PPTX, hantar sebagai mesej "dokumen" supaya Kaoruko boleh
  // ajar berdasarkan kandungan tu (macam study buddy).
  Future<void> _pilihDanHantarDokumen() async {
    final prefs = await SharedPreferences.getInstance();
    final ignore = prefs.getBool('perm_files_ignore') ?? false;

    var status = await (Platform.isAndroid ? Permission.storage.status : Permission.photos.status);
    if (status.isDenied && !ignore) {
      if (mounted) {
        bool donotshow = false;
        final result = await showDialog<bool>(
          context: context,
          builder: (ctx) => StatefulBuilder(
            builder: (context, setDialogState) => AlertDialog(
              title: const Text('Akses Fail'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Aplikasi memerlukan akses kepada fail anda untuk memilih dokumen (PDF/PPTX).'),
                  const SizedBox(height: 12),
                  CheckboxListTile(
                    title: const Text('Jangan paparkan lagi', style: TextStyle(fontSize: 14)),
                    value: donotshow,
                    onChanged: (val) => setDialogState(() => donotshow = val ?? false),
                    controlAffinity: ListTileControlAffinity.leading,
                    contentPadding: EdgeInsets.zero,
                  ),
                ],
              ),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
                TextButton(
                  onPressed: () async {
                    if (donotshow) await prefs.setBool('perm_files_ignore', true);
                    Navigator.pop(ctx, true);
                  },
                  child: const Text('Benarkan'),
                ),
              ],
            ),
          ),
        );

        if (result == true) {
          if (Platform.isAndroid) {
            await Permission.storage.request();
          }
        } else {
          return;
        }
      }
    }

    setState(() => _isReadingDocument = true);
    try {
      final hasil = await _documentService.pilihDanExtract();
      if (hasil == null) {
        // Pengguna batal pilih fail — tak buat apa-apa.
        setState(() => _isReadingDocument = false);
        return;
      }

      final mesejDokumen = Message(
        text: '',
        sender: Sender.user,
        documentName: hasil.namaFail,
        documentText: hasil.teks,
      );

      setState(() {
        _messages.add(mesejDokumen);
        _isLoading = true;
      });
      await _simpanMesejKeStorage();
      _scrollToBottom();

      final reply = await _chatService.sendMessage(_messages);
      if (!mounted) return;
      setState(() {
        _messages.add(Message(text: reply, sender: Sender.kaoruko));
      });
      await _simpanMesejKeStorage();

      // Hantar notifikasi peranti apabila Kaoruko membalas
      _notificationService.showNotification(
        title: 'Mesej daripada Kaoruko Waguri',
        body: reply,
      );
      MemoryService().extractAndSummarize(_messages);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _messages.add(Message(
          text: 'Ralat: ${e.toString().replaceAll('Exception: ', '')}',
          sender: Sender.kaoruko,
        ));
      });
      await _simpanMesejKeStorage();
    } finally {
      if (mounted) {
        setState(() {
          _isReadingDocument = false;
          _isLoading = false;
        });
        _scrollToBottom();
      }
    }
  }

  // Teka MIME type ringkas daripada nama fail — untuk hantar ke Gemini
  // sebagai inline_data.
  String _tekaMimeType(String namaFail) {
    final ext = namaFail.split('.').last.toLowerCase();
    switch (ext) {
      case 'png':
        return 'image/png';
      case 'webp':
        return 'image/webp';
      case 'heic':
      case 'heif':
        return 'image/heic';
      default:
        return 'image/jpeg';
    }
  }

  // Butang 📎 dalam input bar — satu menu untuk SEMUA jenis lampiran:
  // dokumen (PDF/PPTX), ambil gambar (kamera), atau pilih gambar (galeri).
  void _bukaMenuLampiran() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Wrap(
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(20, 16, 20, 4),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Kongsi sesuatu dengan Kaoruko Waguri',
                    style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                  ),
                ),
              ),
              ListTile(
                leading: Icon(Icons.face_retouching_natural_rounded, color: _roseAccent),
                title: const Text('AI Selfie Mode (Bersama Kaoruko)'),
                onTap: () {
                  Navigator.pop(ctx);
                  _bukaAISelfieMode();
                },
              ),
              ListTile(
                leading: Icon(Icons.description_rounded, color: _roseAccent),
                title: const Text('Dokumen (PDF / PPTX)'),
                onTap: () {
                  Navigator.pop(ctx);
                  _pilihDanHantarDokumen();
                },
              ),
              ListTile(
                leading: Icon(Icons.camera_alt_rounded, color: _roseAccent),
                title: const Text('Ambil gambar (kamera)'),
                onTap: () {
                  Navigator.pop(ctx);
                  _hantarGambar(ImageSource.camera);
                },
              ),
              ListTile(
                leading: Icon(Icons.photo_library_rounded, color: _roseAccent),
                title: const Text('Pilih gambar dari galeri'),
                onTap: () {
                  Navigator.pop(ctx);
                  _hantarGambar(ImageSource.gallery);
                },
              ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }

  // Ambil/pilih gambar, bina Message dengan imageBase64, hantar ke
  // ChatService (Gemini vision baca gambar terus — boleh jawab soalan,
  // terangkan kandungan gambar, dsb — ikut soalan pilihan pengguna).
  Future<void> _hantarGambar(ImageSource source) async {
    final prefs = await SharedPreferences.getInstance();
    final ignoreKey = source == ImageSource.camera ? 'perm_camera_ignore' : 'perm_gallery_ignore';
    final ignore = prefs.getBool(ignoreKey) ?? false;

    final PermissionStatus status;
    if (source == ImageSource.camera) {
      status = await Permission.camera.status;
    } else {
      status = await (Platform.isAndroid ? Permission.storage.status : Permission.photos.status);
    }

    if (status.isDenied && !ignore) {
      if (mounted) {
        bool donotshow = false;
        final rationale = source == ImageSource.camera
            ? 'Aplikasi memerlukan akses kamera untuk mengambil gambar.'
            : 'Aplikasi memerlukan akses galeri untuk memilih gambar.';
        
        final result = await showDialog<bool>(
          context: context,
          builder: (ctx) => StatefulBuilder(
            builder: (context, setDialogState) => AlertDialog(
              title: Text(source == ImageSource.camera ? 'Akses Kamera' : 'Akses Galeri'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(rationale),
                  const SizedBox(height: 12),
                  CheckboxListTile(
                    title: const Text('Jangan paparkan lagi', style: TextStyle(fontSize: 14)),
                    value: donotshow,
                    onChanged: (val) => setDialogState(() => donotshow = val ?? false),
                    controlAffinity: ListTileControlAffinity.leading,
                    contentPadding: EdgeInsets.zero,
                  ),
                ],
              ),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
                TextButton(
                  onPressed: () async {
                    if (donotshow) await prefs.setBool(ignoreKey, true);
                    Navigator.pop(ctx, true);
                  },
                  child: const Text('Benarkan'),
                ),
              ],
            ),
          ),
        );

        if (result == true) {
          if (source == ImageSource.camera) {
            await Permission.camera.request();
          } else {
            if (Platform.isAndroid) {
              await Permission.storage.request();
              await Permission.photos.request();
            } else {
              await Permission.photos.request();
            }
          }
        } else {
          return;
        }
      }
    }

    final XFile? file = await _imagePicker.pickImage(
      source: source,
      imageQuality: 82,
      maxWidth: 1600,
    );
    if (file == null) return;

    final caption = _controller.text.trim();
    _controller.clear();
    setState(() => _isSendingImage = true);
    try {
      final bytes = await file.readAsBytes();
      final base64Str = base64Encode(bytes);
      final mimeType = _tekaMimeType(file.name);

      final mesejGambar = Message(
        text: caption,
        sender: Sender.user,
        imageBase64: base64Str,
        imageMimeType: mimeType,
      );

      setState(() {
        _messages.add(mesejGambar);
        _isLoading = true;
      });
      await _simpanMesejKeStorage();
      _scrollToBottom();

      final reply = await _chatService.sendMessage(_messages);
      if (!mounted) return;
      setState(() {
        _messages.add(Message(text: reply, sender: Sender.kaoruko));
      });
      await _simpanMesejKeStorage();
      _notificationService.showNotification(
        title: 'Mesej daripada Kaoruko Waguri',
        body: reply,
      );
      MemoryService().extractAndSummarize(_messages);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _messages.add(Message(
          text: 'Ralat: ${e.toString().replaceAll('Exception: ', '')}',
          sender: Sender.kaoruko,
        ));
      });
      await _simpanMesejKeStorage();
    } finally {
      if (mounted) {
        setState(() {
          _isSendingImage = false;
          _isLoading = false;
        });
        _scrollToBottom();
      }
    }
  }

  void _mulaBalasMesej(Message msg) {
    setState(() {
      _mesejUntukDibalas = msg;
    });
  }

  void _batalBalasMesej() {
    setState(() {
      _mesejUntukDibalas = null;
    });
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 120), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 350),
          curve: Curves.easeOutCubic,
        );
      }
    });
  }

  String _formatMasa(DateTime dt) {
    final jam = dt.hour.toString().padLeft(2, '0');
    final minit = dt.minute.toString().padLeft(2, '0');
    final hari = dt.day.toString().padLeft(2, '0');
    final bulan = dt.month.toString().padLeft(2, '0');
    return '$jam:$minit • $hari/$bulan';
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Theme.of(context).scaffoldBackgroundColor,
              Theme.of(context).colorScheme.surfaceContainerLowest,
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 8),
              Expanded(
                child: _messages.isEmpty
                    ? _buildEmptyState()
                    : ListView.builder(
                        controller: _scrollController,
                        padding: const EdgeInsets.fromLTRB(14, 8, 14, 8),
                        itemCount: _messages.length,
                        itemBuilder: (context, index) {
                          final msg = _messages[index];
                          final isUser = msg.sender == Sender.user;
                          final showAvatar = !isUser &&
                              (index == 0 ||
                                  _messages[index - 1].sender == Sender.user);
                          return _AnimatedBubble(
                            child: GestureDetector(
                              onLongPress: () => _mulaBalasMesej(msg),
                              child: _buildBubbleRow(msg, isUser, showAvatar),
                            ),
                          );
                        },
                      ),
              ),
              if (_isGeneratingImage) _buildImageLoadingIndicator(),
              if (_isSendingImage && !_isGeneratingImage)
                _buildImageSendingIndicator(),
              if (_isReadingDocument && !_isGeneratingImage && !_isSendingImage)
                _buildDocumentLoadingIndicator(),
              if (_isLoading &&
                  !_isGeneratingImage &&
                  !_isReadingDocument &&
                  !_isSendingImage)
                _buildTypingIndicator(),
              if (_mesejUntukDibalas != null) _buildReplyPreview(),
              _buildInputBar(),
            ],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: false,
      title: GestureDetector(
        onTap: _bukaProfilKaoruko,
        child: Row(
          children: [
            const CircleAvatar(
              radius: 18,
              backgroundImage: AssetImage('assets/pfp.jpg'),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Kaoruko Waguri',
                  style: TextStyle(
                    color: _inkText,
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  ),
                ),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 7,
                      height: 7,
                      decoration: const BoxDecoration(
                        color: Color(0xFF6FBF73),
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      'dalam talian',
                      style: TextStyle(
                        color: _inkText.withValues(alpha: 0.55),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
      actions: [
        IconButton(
          onPressed: _mulaVoiceCall,
          icon: const Icon(Icons.call_rounded, color: _roseAccent),
          tooltip: 'Panggilan Suara',
        ),
        PopupMenuButton<String>(
          tooltip: 'Chat dan profil',
          onSelected: (value) {
            if (value == 'profile') _bukaProfilKaoruko();
            if (value == 'export') _exportChat();
            if (value == 'import') _importChat();
          },
          itemBuilder: (context) => const [
            PopupMenuItem(
                value: 'profile', child: Text('Profil Kaoruko Waguri')),
            PopupMenuItem(value: 'export', child: Text('Export semua chat')),
            PopupMenuItem(value: 'import', child: Text('Import chat')),
          ],
        ),
      ],
    );
  }

  void _mulaVoiceCall() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => VoiceCallScreen()),
    );
  }

  Future<void> _bukaAISelfieMode() async {
    // 1. Tanya jika Kaoruko perlu muncul
    final bool? includeKaoruko = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('AI Selfie Mode'),
        content: const Text('Adakah Kaoruko perlu muncul secara visual dalam output ini?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Tidak')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Ya')),
        ],
      ),
    );

    if (includeKaoruko == null) return;

    bool isSelfieTogether = false;
    String? userImagePath;

    if (includeKaoruko) {
      // 2. Tanya jika bersama user
      final bool? together = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Bersama Kaoruko?'),
          content: const Text('Adakah anda mahu menjana gambar bersama Kaoruko? (Perlu muat naik gambar anda)'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Kaoruko Sahaja')),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Bersama Saya')),
          ],
        ),
      );

      if (together == true) {
        final XFile? picked = await _imagePicker.pickImage(source: ImageSource.gallery);
        if (picked != null) {
          isSelfieTogether = true;
          userImagePath = picked.path;
        }
      }
    }

    // 3. Minta permintaan user
    final TextEditingController promptController = TextEditingController();
    final String? userRequest = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Apa yang anda bayangkan?'),
        content: TextField(
          controller: promptController,
          decoration: const InputDecoration(hintText: "Contoh: Di tepi pantai, makan aiskrim"),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, promptController.text), child: const Text('Jana')),
        ],
      ),
    );

    if (userRequest == null || userRequest.trim().isEmpty) return;

    setState(() {
      _isLoading = true;
      _isGeneratingImage = true;
      _messages.add(Message(
        text: 'Jana gambar AI: $userRequest ${isSelfieTogether ? '(Bersama saya)' : ''}',
        sender: Sender.user,
      ));
    });
    _scrollToBottom();

    try {
      final String timeContext = _dapatkanKonteksMasa();
      final base64Data = await _imageService.generateImage(
        userRequest,
        includeKaoruko: includeKaoruko,
        timeContext: timeContext,
      );

      if (!mounted) return;

      if (base64Data == null) {
        setState(() {
          _messages.add(Message(
            text: 'Maaf, gagal menjana gambar selfie sekarang. Cuba lagi nanti ya.',
            sender: Sender.kaoruko,
          ));
        });
      } else {
        setState(() {
          _messages.add(Message(
            text: '',
            sender: Sender.kaoruko,
            imageBase64: base64Data,
          ));
        });
        _notificationService.showNotification(
          title: 'Kaoruko Waguri 🌸',
          body: 'Siap! Inilah gambar kita!',
        );
      }
      await _simpanMesejKeStorage();
    } catch (e) {
      if (mounted) {
        setState(() {
          _messages.add(Message(
            text: 'Ralat: $e',
            sender: Sender.kaoruko,
          ));
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _isGeneratingImage = false;
          _isLoading = false;
        });
        _scrollToBottom();
      }
    }
  }

  String _dapatkanKonteksMasa() {
    final now = DateTime.now();
    final hour = now.hour;

    // Rujukan Identiti Visual: assets/character/wagurikaoruko.jpg
    if (hour >= 5 && hour < 9) {
      return "Pagi (~7–9 pagi): pencahayaan terang, pakaian sekolah/casual, ekspresi ceria. Character reference: assets/character/wagurikaoruko.jpg.";
    } else if (hour >= 9 && hour < 17) {
      return "Tengah hari/Petang: latar terang, aktiviti luar/dalam. Character reference: assets/character/wagurikaoruko.jpg.";
    } else if (hour >= 17 && hour < 21) {
      return "Waktu petang/senja: pencahayaan hangat, cafe/taman. Character reference: assets/character/wagurikaoruko.jpg.";
    } else if (hour >= 21 && hour < 23) {
      return "Malam pukul $hour:00: selfie kamera depan, latar bilik tidur, pakaian baju tidur (pyjama) sopan, lampu meja, ekspresi santai/mengantuk. Character reference: assets/character/wagurikaoruko.jpg.";
    } else {
      return "Lewat malam (>11 malam): suasana redup, ekspresi risau/penyayang ('awak belum tidur lagi ke?'). Character reference: assets/character/wagurikaoruko.jpg.";
    }
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircleAvatar(
              radius: 42,
              backgroundImage: AssetImage('assets/pfp.jpg'),
            ),
            const SizedBox(height: 16),
            Text(
              'Mula perbualan dengan Kaoruko Waguri',
              style: TextStyle(
                color: _inkText.withValues(alpha: 0.6),
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBubbleRow(Message msg, bool isUser, bool showAvatar) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment:
            isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isUser) ...[
            showAvatar
                ? const CircleAvatar(
                    radius: 14,
                    backgroundImage: AssetImage('assets/pfp.jpg'),
                  )
                : const SizedBox(width: 28),
            const SizedBox(width: 6),
          ],
          Flexible(
            child: Container(
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * 0.72,
              ),
              padding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 10,
              ),
              decoration: BoxDecoration(
                color: isUser ? _bubbleUser : _bubbleKaoruko,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(18),
                  topRight: const Radius.circular(18),
                  bottomLeft: Radius.circular(isUser ? 18 : 4),
                  bottomRight: Radius.circular(isUser ? 4 : 18),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment:
                    isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (msg.isReply) _buildQuoteBox(msg, isUser),
                  if (msg.isDocument) _buildDocumentChip(msg, isUser),
                  if (msg.isDocument && msg.text.isEmpty)
                    const SizedBox(height: 2),
                  if (msg.isImage)
                    GestureDetector(
                      onTap: () => _lihatImej(msg),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.memory(
                          base64Decode(msg.imageBase64!),
                          width: 200,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) => Text(
                            'Gagal papar gambar',
                            style: TextStyle(
                              color: isUser ? Colors.white : _inkText,
                              fontSize: 13,
                            ),
                          ),
                        ),
                      ),
                    ),
                  if (msg.text.isNotEmpty) ...[
                    if (msg.isImage) const SizedBox(height: 6),
                    Text(
                      msg.text,
                      style: TextStyle(
                        color: isUser ? Colors.white : _inkText,
                        fontSize: 15,
                        height: 1.35,
                      ),
                    ),
                  ],
                  const SizedBox(height: 4),
                  // Paparan Tarikh & Masa
                  Text(
                    _formatMasa(msg.timestamp),
                    style: TextStyle(
                      color: isUser
                          ? Colors.white.withValues(alpha: 0.6)
                          : _inkText.withValues(alpha: 0.45),
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (isUser) const SizedBox(width: 4),
        ],
      ),
    );
  }

  Future<void> _lihatImej(Message msg) async {
    final bytes = base64Decode(msg.imageBase64!);
    await showDialog<void>(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.9),
      builder: (dialogContext) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.all(12),
          child: Stack(
            children: [
              InteractiveViewer(
                minScale: 0.5,
                maxScale: 5,
                child: Center(
                  child: Image.memory(
                    bytes,
                    fit: BoxFit.contain,
                    errorBuilder: (context, error, stackTrace) => const Text(
                      'Gagal papar gambar',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 0,
                right: 0,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    DecoratedBox(
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.55),
                        shape: BoxShape.circle,
                      ),
                      child: IconButton(
                        tooltip: 'Simpan gambar',
                        onPressed: () => _simpanImej(bytes),
                        icon: const Icon(
                          Icons.download_rounded,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    DecoratedBox(
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.55),
                        shape: BoxShape.circle,
                      ),
                      child: IconButton(
                        tooltip: 'Tutup',
                        onPressed: () => Navigator.pop(dialogContext),
                        icon: const Icon(Icons.close_rounded,
                            color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _simpanImej(List<int> bytes) async {
    try {
      final hasAccess = await Gal.hasAccess();
      if (!hasAccess && !await Gal.requestAccess()) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content:
                    Text('Kebenaran galeri diperlukan untuk simpan gambar.')),
          );
        }
        return;
      }

      await Gal.putImageBytes(
        Uint8List.fromList(bytes),
        name: 'kaoruko_${DateTime.now().millisecondsSinceEpoch}',
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gambar berjaya disimpan ke galeri.')),
        );
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal simpan gambar: $error')),
        );
      }
    }
  }

  Widget _buildTypingIndicator() {
    return Padding(
      padding: const EdgeInsets.only(left: 20, bottom: 8),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const CircleAvatar(
            radius: 12,
            backgroundImage: AssetImage('assets/pfp.jpg'),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: _bubbleKaoruko,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 6,
                ),
              ],
            ),
            child: const _TypingDots(),
          ),
        ],
      ),
    );
  }

  // Kotak kecil "quote" yang dipaparkan di dalam bubble bila mesej ni
  // membalas mesej lain.
  Widget _buildQuoteBox(Message msg, bool isUser) {
    final labelPembalas =
        msg.replyToSender == Sender.user ? 'Awak' : 'Kaoruko Waguri';
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: isUser
            ? Colors.white.withValues(alpha: 0.15)
            : _roseAccent.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border(
          left: BorderSide(
            color: isUser ? Colors.white.withValues(alpha: 0.6) : _roseAccent,
            width: 3,
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            labelPembalas,
            style: TextStyle(
              color:
                  isUser ? Colors.white.withValues(alpha: 0.85) : _roseAccent,
              fontWeight: FontWeight.w600,
              fontSize: 11.5,
            ),
          ),
          const SizedBox(height: 1),
          Text(
            msg.replyToText ?? '',
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: isUser
                  ? Colors.white.withValues(alpha: 0.75)
                  : _inkText.withValues(alpha: 0.6),
              fontSize: 12.5,
            ),
          ),
        ],
      ),
    );
  }

  // Preview di atas input bar bila pengguna sedang pilih mesej untuk
  // dibalas — boleh dibatal dengan butang X.
  Widget _buildReplyPreview() {
    final msg = _mesejUntukDibalas!;
    final labelPembalas = msg.sender == Sender.user ? 'Awak' : 'Kaoruko Waguri';
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 6),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border(left: BorderSide(color: _roseAccent, width: 3)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 6,
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Membalas $labelPembalas',
                  style: const TextStyle(
                    color: _roseAccent,
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  msg.isImage
                      ? '📷 Gambar'
                      : (msg.isDocument ? '📄 ${msg.documentName}' : msg.text),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: _inkText.withValues(alpha: 0.6),
                    fontSize: 12.5,
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: _batalBalasMesej,
            child: Icon(Icons.close_rounded,
                size: 18, color: _inkText.withValues(alpha: 0.45)),
          ),
        ],
      ),
    );
  }

  // Petunjuk kecil "sedang jana gambar..." — guna gaya sama dengan
  // typing indicator sedia ada supaya konsisten.
  Widget _buildImageLoadingIndicator() {
    return Padding(
      padding: const EdgeInsets.only(left: 20, bottom: 8),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const CircleAvatar(
            radius: 12,
            backgroundImage: AssetImage('assets/pfp.jpg'),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: _bubbleKaoruko,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 6,
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(
                  width: 12,
                  height: 12,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: _roseAccent,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'Kaoruko Waguri sedang lukis gambar...',
                  style: TextStyle(
                    color: _inkText.withValues(alpha: 0.6),
                    fontSize: 12.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Chip kecil "📄 nama_fail.pdf" dipaparkan dalam bubble untuk mesej
  // dokumen — kandungan penuh tak dipaparkan terus (boleh sangat
  // panjang), cuma nama fail sebagai penanda.
  Widget _buildDocumentChip(Message msg, bool isUser) {
    final ext = msg.documentName!.split('.').last.toUpperCase();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: isUser
            ? Colors.white.withValues(alpha: 0.12)
            : _roseAccent.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            ext == 'PDF'
                ? Icons.picture_as_pdf_rounded
                : Icons.slideshow_rounded,
            size: 18,
            color: isUser ? Colors.white70 : _roseAccent,
          ),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              msg.documentName!,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: isUser ? Colors.white : _inkText,
                fontSize: 12.5,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildImageSendingIndicator() {
    return Padding(
      padding: const EdgeInsets.only(left: 20, bottom: 8),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const CircleAvatar(
            radius: 12,
            backgroundImage: AssetImage('assets/pfp.jpg'),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: _bubbleKaoruko,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 6,
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(
                  width: 12,
                  height: 12,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: _roseAccent,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'Kaoruko Waguri sedang hantar gambar...',
                  style: TextStyle(
                    color: _inkText.withValues(alpha: 0.6),
                    fontSize: 12.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDocumentLoadingIndicator() {
    return Padding(
      padding: const EdgeInsets.only(left: 20, bottom: 8),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const CircleAvatar(
            radius: 12,
            backgroundImage: AssetImage('assets/pfp.jpg'),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: _bubbleKaoruko,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 6,
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(
                  width: 12,
                  height: 12,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: _roseAccent,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'Kaoruko Waguri sedang baca dokumen...',
                  style: TextStyle(
                    color: _inkText.withValues(alpha: 0.6),
                    fontSize: 12.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 6, 12, 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          GestureDetector(
            onTap: (_isReadingDocument || _isSendingImage || _isLoading)
                ? null
                : _bukaMenuLampiran,
            child: Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.06),
                    blurRadius: 10,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Icon(Icons.attach_file_rounded,
                  color: _roseAccent.withValues(alpha: 0.85), size: 22),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.06),
                    blurRadius: 10,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: TextField(
                controller: _controller,
                minLines: 1,
                maxLines: 5,
                textCapitalization: TextCapitalization.sentences,
                style: TextStyle(color: _inkText, fontSize: 15),
                decoration: InputDecoration(
                  hintText: 'Taip mesej...',
                  hintStyle: TextStyle(color: _inkText.withValues(alpha: 0.4)),
                  border: InputBorder.none,
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                ),
                onSubmitted: (_) => _sendMessage(),
              ),
            ),
          ),
          const SizedBox(width: 8),
          _SendButton(onTap: _sendMessage, color: _roseAccent),
        ],
      ),
    );
  }
}

class _SendButton extends StatefulWidget {
  final VoidCallback onTap;
  final Color color;
  const _SendButton({required this.onTap, required this.color});

  @override
  State<_SendButton> createState() => _SendButtonState();
}

class _SendButtonState extends State<_SendButton> {
  double _scale = 1;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _scale = 0.9),
      onTapUp: (_) => setState(() => _scale = 1),
      onTapCancel: () => setState(() => _scale = 1),
      onTap: widget.onTap,
      child: AnimatedScale(
        scale: _scale,
        duration: const Duration(milliseconds: 100),
        child: Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(
            color: widget.color,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: widget.color.withValues(alpha: 0.35),
                blurRadius: 10,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: const Icon(Icons.arrow_upward_rounded,
              color: Colors.white, size: 22),
        ),
      ),
    );
  }
}

class _AnimatedBubble extends StatefulWidget {
  final Widget child;
  const _AnimatedBubble({required this.child});

  @override
  State<_AnimatedBubble> createState() => _AnimatedBubbleState();
}

class _AnimatedBubbleState extends State<_AnimatedBubble>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _fade;
  late final Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 260),
    );
    _fade = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
    _slide = Tween<Offset>(
      begin: const Offset(0, 0.08),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(position: _slide, child: widget.child),
    );
  }
}

class _TypingDots extends StatefulWidget {
  const _TypingDots();

  @override
  State<_TypingDots> createState() => _TypingDotsState();
}

class _TypingDotsState extends State<_TypingDots>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(3, (i) {
            final t = (_controller.value - (i * 0.2)) % 1.0;
            final opacity = 0.3 + 0.7 * (1 - (t - 0.5).abs() * 2).clamp(0, 1);
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2),
              child: Opacity(
                opacity: opacity.toDouble(),
                child: Container(
                  width: 6,
                  height: 6,
                  decoration: const BoxDecoration(
                    color: Color(0xFF2E2320),
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            );
          }),
        );
      },
    );
  }
}
