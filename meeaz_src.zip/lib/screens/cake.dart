import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const CakeSimulatorApp());
}

// =========================================================================
// 1. SISTEM KESAN BUNYI (SOUND MANAGER)
// =========================================================================

class SoundManager {
  static final AudioPlayer _player = AudioPlayer();
  static bool bunyiAktif = true;

  static const String _urlPickup = 'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3';
  static const String _urlMix = 'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3';
  static const String _urlOvenDing = 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3';
  static const String _urlCoin = 'https://assets.mixkit.co/active_storage/sfx/2019/2019-preview.mp3';
  static const String _urlVictory = 'https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3';
  static const String _urlUnlock = 'https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3';
  static const String _urlWater = 'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3';
  static const String _urlStar = 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3';
  static const String _urlBuy = 'https://assets.mixkit.co/active_storage/sfx/2019/2019-preview.mp3';
  static const String _urlEquip = 'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3';

  static Future<void> mainBunyi(String url, {bool haptic = true}) async {
    if (haptic) HapticFeedback.lightImpact();
    if (!bunyiAktif) return;
    try {
      await _player.stop();
      await _player.play(UrlSource(url));
    } catch (_) {
      SystemSound.play(SystemSoundType.click);
    }
  }

  static void kutipBahan() => mainBunyi(_urlPickup);
  static void gaulAdunan() => mainBunyi(_urlMix);
  static void ovenSiap() => mainBunyi(_urlOvenDing);
  static void dapatCoins() => mainBunyi(_urlCoin);
  static void menangLevel() => mainBunyi(_urlVictory);
  static void resepiBaharu() => mainBunyi(_urlUnlock);
  static void cuciSingki() => mainBunyi(_urlWater, haptic: false);
  static void bintangPop() => mainBunyi(_urlStar, haptic: false);
  static void beliItem() => mainBunyi(_urlBuy);
  static void pakaiItem() => mainBunyi(_urlEquip, haptic: false);

  static void klikButang() {
    HapticFeedback.selectionClick();
    if (bunyiAktif) SystemSound.play(SystemSoundType.click);
  }
}

// =========================================================================
// 2. MODEL DATA & 50 LEVEL RESEPI
// =========================================================================

enum UnitBahan { gram, ml, biji }
enum KategoriBahan { pantri, peti, topping }

class Bahan {
  final String nama;
  final double sukatan;
  final UnitBahan unit;
  final KategoriBahan kategori;
  final IconData ikon;
  final Color warna;

  const Bahan({
    required this.nama,
    required this.sukatan,
    required this.unit,
    required this.kategori,
    required this.ikon,
    required this.warna,
  });
}

class ResepiDef {
  final String nama;
  final Color warnaAdunan;
  final Color warnaKek;
  final List<Bahan> bahanAsas;

  const ResepiDef({
    required this.nama,
    required this.warnaAdunan,
    required this.warnaKek,
    required this.bahanAsas,
  });
}

final List<ResepiDef> masterResepi = [
  const ResepiDef(
    nama: 'Kek Span Vanila',
    warnaAdunan: Color(0xFFFFF9C4),
    warnaKek: Color(0xFFF4C47D),
    bahanAsas: [
      Bahan(nama: 'Tepung Gandum', sukatan: 250, unit: UnitBahan.gram, kategori: KategoriBahan.pantri, ikon: Icons.grain, warna: Color(0xFFE8D8C8)),
      Bahan(nama: 'Gula Pasir', sukatan: 150, unit: UnitBahan.gram, kategori: KategoriBahan.pantri, ikon: Icons.all_inclusive, warna: Color(0xFFFFF9E6)),
      Bahan(nama: 'Telur Segar', sukatan: 3, unit: UnitBahan.biji, kategori: KategoriBahan.peti, ikon: Icons.egg, warna: Color(0xFFFFD54F)),
      Bahan(nama: 'Susu Segar', sukatan: 200, unit: UnitBahan.ml, kategori: KategoriBahan.peti, ikon: Icons.water_drop, warna: Color(0xFF81D4FA)),
    ],
  ),
  const ResepiDef(
    nama: 'Kek Coklat Moist',
    warnaAdunan: Color(0xFF5D4037),
    warnaKek: Color(0xFF3E2723),
    bahanAsas: [
      Bahan(nama: 'Tepung Gandum', sukatan: 280, unit: UnitBahan.gram, kategori: KategoriBahan.pantri, ikon: Icons.grain, warna: Color(0xFFE8D8C8)),
      Bahan(nama: 'Serbuk Koko', sukatan: 60, unit: UnitBahan.gram, kategori: KategoriBahan.pantri, ikon: Icons.circle, warna: Color(0xFF4E342E)),
      Bahan(nama: 'Gula Perang', sukatan: 180, unit: UnitBahan.gram, kategori: KategoriBahan.pantri, ikon: Icons.all_inclusive, warna: Color(0xFFFFF9E6)),
      Bahan(nama: 'Telur Segar', sukatan: 4, unit: UnitBahan.biji, kategori: KategoriBahan.peti, ikon: Icons.egg, warna: Color(0xFFFFD54F)),
      Bahan(nama: 'Susu Coklat', sukatan: 220, unit: UnitBahan.ml, kategori: KategoriBahan.peti, ikon: Icons.water_drop, warna: Color(0xFF8D6E63)),
    ],
  ),
  const ResepiDef(
    nama: 'Kek Strawberry Bliss',
    warnaAdunan: Color(0xFFFFCDD2),
    warnaKek: Color(0xFFE91E63),
    bahanAsas: [
      Bahan(nama: 'Tepung Kek', sukatan: 260, unit: UnitBahan.gram, kategori: KategoriBahan.pantri, ikon: Icons.grain, warna: Color(0xFFE8D8C8)),
      Bahan(nama: 'Gula Aising', sukatan: 140, unit: UnitBahan.gram, kategori: KategoriBahan.pantri, ikon: Icons.all_inclusive, warna: Color(0xFFFFF9E6)),
      Bahan(nama: 'Puri Strawberry', sukatan: 180, unit: UnitBahan.ml, kategori: KategoriBahan.peti, ikon: Icons.water_drop, warna: Color(0xFFFF4081)),
      Bahan(nama: 'Telur Segar', sukatan: 3, unit: UnitBahan.biji, kategori: KategoriBahan.peti, ikon: Icons.egg, warna: Color(0xFFFFD54F)),
      Bahan(nama: 'Buah Strawberry', sukatan: 50, unit: UnitBahan.gram, kategori: KategoriBahan.topping, ikon: Icons.local_florist, warna: Colors.red),
    ],
  ),
  const ResepiDef(
    nama: 'Kek Pandan Kastard',
    warnaAdunan: Color(0xFFA5D6A7),
    warnaKek: Color(0xFF66BB6A),
    bahanAsas: [
      Bahan(nama: 'Tepung Gandum', sukatan: 280, unit: UnitBahan.gram, kategori: KategoriBahan.pantri, ikon: Icons.grain, warna: Color(0xFFE8D8C8)),
      Bahan(nama: 'Gula Melaka', sukatan: 160, unit: UnitBahan.gram, kategori: KategoriBahan.pantri, ikon: Icons.all_inclusive, warna: Color(0xFF8D6E63)),
      Bahan(nama: 'Santan Pekat', sukatan: 250, unit: UnitBahan.ml, kategori: KategoriBahan.peti, ikon: Icons.water_drop, warna: Color(0xFFE0F7FA)),
      Bahan(nama: 'Jus Pandan', sukatan: 40, unit: UnitBahan.ml, kategori: KategoriBahan.peti, ikon: Icons.eco, warna: Color(0xFF2E7D32)),
      Bahan(nama: 'Kelapa Parut', sukatan: 40, unit: UnitBahan.gram, kategori: KategoriBahan.topping, ikon: Icons.grain, warna: Colors.white),
    ],
  ),
  const ResepiDef(
    nama: 'Kek Red Velvet Royal',
    warnaAdunan: Color(0xFFC2185B),
    warnaKek: Color(0xFF880E4F),
    bahanAsas: [
      Bahan(nama: 'Tepung Superfine', sukatan: 300, unit: UnitBahan.gram, kategori: KategoriBahan.pantri, ikon: Icons.grain, warna: Color(0xFFE8D8C8)),
      Bahan(nama: 'Gula Kaster', sukatan: 200, unit: UnitBahan.gram, kategori: KategoriBahan.pantri, ikon: Icons.all_inclusive, warna: Color(0xFFFFF9E6)),
      Bahan(nama: 'Buttermilk', sukatan: 240, unit: UnitBahan.ml, kategori: KategoriBahan.peti, ikon: Icons.water_drop, warna: Color(0xFFE1F5FE)),
      Bahan(nama: 'Telur Segar', sukatan: 3, unit: UnitBahan.biji, kategori: KategoriBahan.peti, ikon: Icons.egg, warna: Color(0xFFFFD54F)),
      Bahan(nama: 'Krim Keju Frosting', sukatan: 100, unit: UnitBahan.gram, kategori: KategoriBahan.topping, ikon: Icons.cake, warna: Colors.white),
    ],
  ),
  const ResepiDef(
    nama: 'Kek Pelangi (Rainbow Cake)',
    warnaAdunan: Color(0xFFFFD54F),
    warnaKek: Color(0xFFAB47BC),
    bahanAsas: [
      Bahan(nama: 'Tepung Emas', sukatan: 350, unit: UnitBahan.gram, kategori: KategoriBahan.pantri, ikon: Icons.grain, warna: Color(0xFFE8D8C8)),
      Bahan(nama: 'Gula Halus', sukatan: 240, unit: UnitBahan.gram, kategori: KategoriBahan.pantri, ikon: Icons.all_inclusive, warna: Color(0xFFFFF9E6)),
      Bahan(nama: 'Susu Segar', sukatan: 300, unit: UnitBahan.ml, kategori: KategoriBahan.peti, ikon: Icons.water_drop, warna: Color(0xFF81D4FA)),
      Bahan(nama: 'Telur Gred A', sukatan: 5, unit: UnitBahan.biji, kategori: KategoriBahan.peti, ikon: Icons.egg, warna: Color(0xFFFFD54F)),
      Bahan(nama: 'Pewarna Pelangi', sukatan: 30, unit: UnitBahan.ml, kategori: KategoriBahan.peti, ikon: Icons.palette, warna: Colors.deepPurple),
      Bahan(nama: 'Taburan Coklat Pelangi', sukatan: 80, unit: UnitBahan.gram, kategori: KategoriBahan.topping, ikon: Icons.grain, warna: Colors.pinkAccent),
    ],
  ),
];

class LevelMission {
  final int levelId;
  final String namaKek;
  final int jumlahKek;
  final int hadMasa;
  final int masaBakar;
  final int ganjaranCoins;
  final ResepiDef resepi;
  final bool adaStesenTopping;

  const LevelMission({
    required this.levelId,
    required this.namaKek,
    required this.jumlahKek,
    required this.hadMasa,
    required this.masaBakar,
    required this.ganjaranCoins,
    required this.resepi,
    required this.adaStesenTopping,
  });
}

int tierUntukLevel(int levelId) => ((levelId - 1) ~/ 9).clamp(0, masterResepi.length - 1);

List<LevelMission> bina50Level() {
  final List<LevelMission> list = [];
  for (int i = 1; i <= 50; i++) {
    final rIndex = tierUntukLevel(i);
    final resepi = masterResepi[rIndex];
    final int kuantiti = (i <= 10) ? 1 : (i <= 25) ? 2 : (i <= 40) ? 3 : 4;
    final bool topping = i >= 12;
    final int masa = 90 + (kuantiti * 35) + (i % 5 * 5);
    final int coins = 90 + (i * 25) + (kuantiti * 40);

    list.add(LevelMission(
      levelId: i,
      namaKek: '${resepi.nama} ${kuantiti > 1 ? "($kuantiti Biji)" : ""}',
      jumlahKek: kuantiti,
      hadMasa: masa,
      masaBakar: 6 + (i % 3),
      ganjaranCoins: coins,
      resepi: resepi,
      adaStesenTopping: topping,
    ));
  }
  return list;
}

final List<LevelMission> semua50Level = bina50Level();

String formatSukatan(double nilai, UnitBahan unit) {
  if (unit == UnitBahan.ml) {
    final liter = nilai / 1000.0;
    return '${nilai.toStringAsFixed(0)} ml (${liter.toStringAsFixed(2)} L)';
  } else if (unit == UnitBahan.gram) {
    return '${nilai.toStringAsFixed(0)} g';
  } else {
    return '${nilai.toStringAsFixed(0)} biji';
  }
}

// =========================================================================
// 3. DATA KEDAI (CUSTOMIZATION IKUT WARNA)
// =========================================================================

enum ShopKategori { pakaian, latar, jubin, meja, aksesori }

class WarnaItem {
  final String id;
  final String nama;
  final Color warna;
  final int harga;
  const WarnaItem({required this.id, required this.nama, required this.warna, required this.harga});
}

final Map<ShopKategori, List<WarnaItem>> paletKedai = {
  ShopKategori.pakaian: const [
    WarnaItem(id: 'pakaian_pink', nama: 'Pink Klasik', warna: Color(0xFFE91E63), harga: 0),
    WarnaItem(id: 'pakaian_gold', nama: 'Emas VIP', warna: Color(0xFFFFA000), harga: 150),
    WarnaItem(id: 'pakaian_hitam', nama: 'Master Hitam', warna: Color(0xFF263238), harga: 250),
    WarnaItem(id: 'pakaian_biru', nama: 'Biru Segar', warna: Color(0xFF1E88E5), harga: 180),
    WarnaItem(id: 'pakaian_hijau', nama: 'Hijau Mint', warna: Color(0xFF43A047), harga: 180),
    WarnaItem(id: 'pakaian_ungu', nama: 'Ungu Ceria', warna: Color(0xFF8E24AA), harga: 220),
    WarnaItem(id: 'pakaian_merah', nama: 'Merah Berani', warna: Color(0xFFE53935), harga: 200),
    WarnaItem(id: 'pakaian_pelangi', nama: 'Pelangi Legenda', warna: Color(0xFFAB47BC), harga: 500),
  ],
  ShopKategori.latar: const [
    WarnaItem(id: 'latar_krim', nama: 'Krim Lembut', warna: Color(0xFFFFF3E0), harga: 0),
    WarnaItem(id: 'latar_emas', nama: 'Marble Emas', warna: Color(0xFFFFF8E1), harga: 150),
    WarnaItem(id: 'latar_pink', nama: 'Pink Comel', warna: Color(0xFFFCE4EC), harga: 200),
    WarnaItem(id: 'latar_biru', nama: 'Biru Sejuk', warna: Color(0xFFE3F2FD), harga: 180),
    WarnaItem(id: 'latar_hijau', nama: 'Taman Hijau', warna: Color(0xFFE8F5E9), harga: 180),
    WarnaItem(id: 'latar_malam', nama: 'Dapur Malam', warna: Color(0xFF263238), harga: 350),
    WarnaItem(id: 'latar_ungu', nama: 'Ungu Impian', warna: Color(0xFFF3E5F5), harga: 220),
  ],
  ShopKategori.jubin: const [
    WarnaItem(id: 'jubin_coklat', nama: 'Kayu Klasik', warna: Color(0xFF8D6E63), harga: 0),
    WarnaItem(id: 'jubin_emas', nama: 'Marble Emas', warna: Color(0xFFD4A017), harga: 200),
    WarnaItem(id: 'jubin_pink', nama: 'Pink Comel', warna: Color(0xFFF48FB1), harga: 300),
    WarnaItem(id: 'jubin_putih', nama: 'Putih Bersih', warna: Color(0xFFCFD8DC), harga: 150),
    WarnaItem(id: 'jubin_navy', nama: 'Navy Elegan', warna: Color(0xFF37474F), harga: 280),
    WarnaItem(id: 'jubin_hijau', nama: 'Hijau Segar', warna: Color(0xFF81C784), harga: 220),
  ],
  ShopKategori.meja: const [
    WarnaItem(id: 'meja_ungu', nama: 'Ungu Moden', warna: Color(0xFF7B1FA2), harga: 0),
    WarnaItem(id: 'meja_emas', nama: 'Emas Diraja', warna: Color(0xFFFFA000), harga: 350),
    WarnaItem(id: 'meja_marble', nama: 'Marble Kaca', warna: Color(0xFF546E7A), harga: 500),
    WarnaItem(id: 'meja_pink', nama: 'Pink Manis', warna: Color(0xFFEC407A), harga: 260),
    WarnaItem(id: 'meja_hijau', nama: 'Hijau Segar', warna: Color(0xFF388E3C), harga: 260),
    WarnaItem(id: 'meja_hitam', nama: 'Hitam Elegan', warna: Color(0xFF212121), harga: 400),
  ],
  ShopKategori.aksesori: const [
    WarnaItem(id: 'aksesori_none', nama: 'Tiada', warna: Color(0xFFBDBDBD), harga: 0),
    WarnaItem(id: 'aksesori_pink', nama: 'Bandana Pink', warna: Color(0xFFFF4081), harga: 100),
    WarnaItem(id: 'aksesori_emas', nama: 'Bandana Emas', warna: Color(0xFFFFC107), harga: 180),
    WarnaItem(id: 'aksesori_biru', nama: 'Bandana Biru', warna: Color(0xFF29B6F6), harga: 140),
    WarnaItem(id: 'aksesori_pelangi', nama: 'Bandana Pelangi', warna: Color(0xFFAB47BC), harga: 300),
  ],
};

String kategoriNama(ShopKategori k) {
  switch (k) {
    case ShopKategori.pakaian: return 'Pakaian';
    case ShopKategori.latar: return 'Latar Belakang';
    case ShopKategori.jubin: return 'Jubin Lantai';
    case ShopKategori.meja: return 'Meja';
    case ShopKategori.aksesori: return 'Aksesori';
  }
}

IconData kategoriIkon(ShopKategori k) {
  switch (k) {
    case ShopKategori.pakaian: return Icons.checkroom;
    case ShopKategori.latar: return Icons.wallpaper;
    case ShopKategori.jubin: return Icons.grid_view;
    case ShopKategori.meja: return Icons.table_restaurant;
    case ShopKategori.aksesori: return Icons.face_retouching_natural;
  }
}

// =========================================================================
// 4. STORAGE LOCALHOST (SHARED PREFERENCES)
// =========================================================================

class StorageManager {
  static const String kCoins = 'cake_coins_v5';
  static const String kUnlockedLvl = 'cake_unlocked_lvl_v5';
  static const String kStars = 'cake_stars_v5_';
  static const String kCombo = 'cake_combo_v5';
  static const String kCakesMade = 'cake_cakes_made_v5';
  static const String kLastPlayDate = 'cake_last_play_v5';
  static const String kDailyStreak = 'cake_daily_streak_v5';

  static Future<SharedPreferences> get _p async => SharedPreferences.getInstance();

  static Future<int> getCoins() async => (await _p).getInt(kCoins) ?? 200;

  static Future<void> addCoins(int amt) async {
    final p = await _p;
    await p.setInt(kCoins, (p.getInt(kCoins) ?? 200) + amt);
  }

  static Future<bool> spendCoins(int amt) async {
    final p = await _p;
    final c = p.getInt(kCoins) ?? 200;
    if (c >= amt) {
      await p.setInt(kCoins, c - amt);
      return true;
    }
    return false;
  }

  static Future<int> getUnlockedLevel() async => (await _p).getInt(kUnlockedLvl) ?? 1;

  static Future<void> unlockLevel(int lvl) async {
    final p = await _p;
    if (lvl > (p.getInt(kUnlockedLvl) ?? 1)) await p.setInt(kUnlockedLvl, lvl);
  }

  static Future<int> getStars(int lvl) async => (await _p).getInt('$kStars$lvl') ?? 0;

  static Future<void> saveStars(int lvl, int s) async {
    final p = await _p;
    if (s > (p.getInt('$kStars$lvl') ?? 0)) await p.setInt('$kStars$lvl', s);
  }

  static Future<int> getTotalStars() async {
    final p = await _p;
    int t = 0;
    for (int i = 1; i <= 50; i++) {
      t += p.getInt('$kStars$i') ?? 0;
    }
    return t;
  }

  static Future<int> getTotalCakes() async => (await _p).getInt(kCakesMade) ?? 0;

  static Future<void> addCakes(int count) async {
    final p = await _p;
    await p.setInt(kCakesMade, (p.getInt(kCakesMade) ?? 0) + count);
  }

  static Future<int> getCombo() async => (await _p).getInt(kCombo) ?? 0;

  static Future<void> setCombo(int c) async {
    final p = await _p;
    await p.setInt(kCombo, c);
  }

  static String _hariIni() {
    final n = DateTime.now();
    return '${n.year}-${n.month}-${n.day}';
  }

  static String _semalam() {
    final n = DateTime.now().subtract(const Duration(days: 1));
    return '${n.year}-${n.month}-${n.day}';
  }

  static Future<int> kemaskiniStreakHarian() async {
    final p = await _p;
    final hariIni = _hariIni();
    final last = p.getString(kLastPlayDate);
    int streak = p.getInt(kDailyStreak) ?? 0;
    if (last == hariIni) {
      // sudah dikira hari ini, kekal
    } else if (last == _semalam()) {
      streak += 1;
    } else {
      streak = 1;
    }
    await p.setString(kLastPlayDate, hariIni);
    await p.setInt(kDailyStreak, streak);
    return streak;
  }

  static Future<int> getStreakHarian() async => (await _p).getInt(kDailyStreak) ?? 0;

  // --- Kedai: pemilikan & pakaian semasa (generik ikut kategori) ---
  static Future<List<String>> getOwned(ShopKategori k) async {
    final p = await _p;
    final key = 'owned_${k.name}_v5';
    final list = p.getStringList(key);
    if (list == null) {
      final def = paletKedai[k]!.first.id;
      await p.setStringList(key, [def]);
      return [def];
    }
    return list;
  }

  static Future<void> addOwned(ShopKategori k, String id) async {
    final p = await _p;
    final key = 'owned_${k.name}_v5';
    final list = p.getStringList(key) ?? [paletKedai[k]!.first.id];
    if (!list.contains(id)) {
      list.add(id);
      await p.setStringList(key, list);
    }
  }

  static Future<String> getEquip(ShopKategori k) async {
    final p = await _p;
    return p.getString('equip_${k.name}_v5') ?? paletKedai[k]!.first.id;
  }

  static Future<void> setEquip(ShopKategori k, String id) async {
    final p = await _p;
    await p.setString('equip_${k.name}_v5', id);
  }

  static Future<void> resetAll() async => (await _p).clear();
}

// =========================================================================
// 5. MAIN APP TEMA
// =========================================================================

class CakeSimulatorApp extends StatelessWidget {
  const CakeSimulatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cake Simulator 3D',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFFE91E63),
        scaffoldBackgroundColor: const Color(0xFFFFF1F6),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFE91E63),
          foregroundColor: Colors.white,
          centerTitle: true,
        ),
      ),
      home: const MainMenuScreen(),
    );
  }
}

// =========================================================================
// 6. MENU UTAMA
// =========================================================================

class MainMenuScreen extends StatefulWidget {
  const MainMenuScreen({super.key});

  @override
  State<MainMenuScreen> createState() => _MainMenuScreenState();
}

class _MainMenuScreenState extends State<MainMenuScreen> with SingleTickerProviderStateMixin {
  int _coins = 150;
  int _unlocked = 1;
  int _cakes = 0;
  int _combo = 0;
  int _streak = 0;
  int _bintangJumlah = 0;
  bool _loading = true;
  late AnimationController _anim;

  @override
  void initState() {
    super.initState();
    _anim = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _muat();
  }

  @override
  void dispose() {
    _anim.dispose();
    super.dispose();
  }

  Future<void> _muat() async {
    final c = await StorageManager.getCoins();
    final u = await StorageManager.getUnlockedLevel();
    final tc = await StorageManager.getTotalCakes();
    final cm = await StorageManager.getCombo();
    final st = await StorageManager.getStreakHarian();
    final bt = await StorageManager.getTotalStars();
    if (mounted) {
      setState(() {
        _coins = c;
        _unlocked = u;
        _cakes = tc;
        _combo = cm;
        _streak = st;
        _bintangJumlah = bt;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    return Scaffold(
      body: Stack(
        children: [
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.amber.shade100,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: Colors.amber.shade400),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.monetization_on, color: Colors.amber, size: 20),
                              const SizedBox(width: 4),
                              Text('$_coins Coins', style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF5D4037))),
                            ],
                          ),
                        ),
                        Row(
                          children: [
                            if (_streak > 1)
                              Container(
                                margin: const EdgeInsets.only(right: 6),
                                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
                                decoration: BoxDecoration(color: Colors.blue.shade50, borderRadius: BorderRadius.circular(16)),
                                child: Row(children: [
                                  const Icon(Icons.calendar_today, color: Colors.blue, size: 14),
                                  Text(' $_streak', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.blue, fontSize: 12)),
                                ]),
                              ),
                            if (_combo > 0)
                              Container(
                                margin: const EdgeInsets.only(right: 6),
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                decoration: BoxDecoration(color: Colors.orange.shade100, borderRadius: BorderRadius.circular(16)),
                                child: Row(
                                  children: [
                                    const Icon(Icons.local_fire_department, color: Colors.deepOrange, size: 18),
                                    Text(' x$_combo', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.deepOrange)),
                                  ],
                                ),
                              ),
                            IconButton(
                              style: IconButton.styleFrom(backgroundColor: Colors.white),
                              icon: Icon(SoundManager.bunyiAktif ? Icons.volume_up : Icons.volume_off, color: const Color(0xFFE91E63)),
                              onPressed: () {
                                setState(() => SoundManager.bunyiAktif = !SoundManager.bunyiAktif);
                                SoundManager.klikButang();
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),

                    ScaleTransition(
                      scale: Tween(begin: 0.95, end: 1.05).animate(CurvedAnimation(parent: _anim, curve: Curves.easeInOut)),
                      child: Container(
                        width: 115,
                        height: 115,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const RadialGradient(colors: [Color(0xFFFF8DA1), Color(0xFFE91E63), Color(0xFF880E4F)]),
                          boxShadow: [
                            BoxShadow(color: Colors.pink.withValues(alpha: 0.35), blurRadius: 18, offset: const Offset(0, 6)),
                          ],
                        ),
                        child: const Icon(Icons.cake, size: 68, color: Colors.white),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      decoration: BoxDecoration(color: const Color(0xFF560027), borderRadius: BorderRadius.circular(12)),
                      child: const Text(
                        'CAKE SIMULATOR 3D',
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 1.5),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.star_rounded, color: Colors.amber, size: 16),
                        Text(' $_bintangJumlah Bintang  •  ', style: const TextStyle(color: Colors.black54, fontSize: 12, fontWeight: FontWeight.w600)),
                        const Text('50 Level Waguri', style: TextStyle(color: Colors.black54, fontSize: 12, fontWeight: FontWeight.w500)),
                      ],
                    ),
                    const SizedBox(height: 24),

                    SizedBox(
                      width: 290,
                      height: 52,
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFE91E63), foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
                        icon: const Icon(Icons.play_arrow_rounded, size: 28),
                        label: Text('MAIN GAME (LV $_unlocked/50)', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                        onPressed: () async {
                          SoundManager.klikButang();
                          await Navigator.push(context, MaterialPageRoute(builder: (_) => const LevelSelectScreen()));
                          _muat();
                        },
                      ),
                    ),
                    const SizedBox(height: 10),

                    SizedBox(
                      width: 290,
                      height: 48,
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0288D1), foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
                        icon: const Icon(Icons.storefront_rounded),
                        label: const Text('KEDAI & INVENTORI', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                        onPressed: () async {
                          SoundManager.klikButang();
                          await Navigator.push(context, MaterialPageRoute(builder: (_) => const ShopCustomizationScreen()));
                          _muat();
                        },
                      ),
                    ),
                    const SizedBox(height: 10),

                    SizedBox(
                      width: 290,
                      height: 48,
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF7B1FA2), foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
                        icon: const Icon(Icons.emoji_events_rounded),
                        label: Text('PENCAPAIAN ($_cakes KEK)', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                        onPressed: () {
                          SoundManager.klikButang();
                          Navigator.push(context, MaterialPageRoute(builder: (_) => AchievementsScreen(totalCakes: _cakes, totalStars: _bintangJumlah, streak: _streak)));
                        },
                      ),
                    ),
                    const SizedBox(height: 10),

                    SizedBox(
                      width: 290,
                      height: 48,
                      child: OutlinedButton.icon(
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Color(0xFFE91E63), width: 2),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                        ),
                        icon: const Icon(Icons.calculate_rounded, color: Color(0xFFE91E63)),
                        label: const Text('MODE KIRA SUKATAN RESEPI', style: TextStyle(color: Color(0xFFE91E63), fontWeight: FontWeight.bold, fontSize: 12.5)),
                        onPressed: () {
                          SoundManager.klikButang();
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const KalkulatorScreen()));
                        },
                      ),
                    ),
                    const SizedBox(height: 20),

                    TextButton.icon(
                      icon: const Icon(Icons.refresh, color: Colors.grey, size: 18),
                      label: const Text('Reset Simpanan Localhost', style: TextStyle(color: Colors.grey, fontSize: 12)),
                      onPressed: () async {
                        SoundManager.klikButang();
                        final ok = await showDialog<bool>(
                          context: context,
                          builder: (_) => AlertDialog(
                            title: const Text('Reset Semua Data?'),
                            content: const Text('Progress level, baju, deko dan coins akan dipadam dari peranti.'),
                            actions: [
                              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
                              TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Ya, Reset')),
                            ],
                          ),
                        );
                        if (ok == true) {
                          await StorageManager.resetAll();
                          _muat();
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            top: 12,
            left: 12,
            child: SafeArea(
              child: GestureDetector(
                onTap: () => Navigator.of(context, rootNavigator: true).pop(),
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.15), blurRadius: 6, offset: const Offset(0, 2))],
                  ),
                  child: const Icon(Icons.arrow_back, color: Color(0xFF5D4037), size: 20),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// =========================================================================
// 7. PILIH LEVEL (1 - 50)
// =========================================================================

class LevelSelectScreen extends StatefulWidget {
  const LevelSelectScreen({super.key});

  @override
  State<LevelSelectScreen> createState() => _LevelSelectScreenState();
}

class _LevelSelectScreenState extends State<LevelSelectScreen> {
  int _unlocked = 1;
  final Map<int, int> _stars = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _muat();
  }

  Future<void> _muat() async {
    final un = await StorageManager.getUnlockedLevel();
    for (final lvl in semua50Level) {
      _stars[lvl.levelId] = await StorageManager.getStars(lvl.levelId);
    }
    if (mounted) {
      setState(() {
        _unlocked = un;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pilih Level (1 - 50)')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
        padding: const EdgeInsets.all(12),
        child: GridView.builder(
          itemCount: semua50Level.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 0.9,
          ),
          itemBuilder: (_, i) {
            final lvl = semua50Level[i];
            final bool lock = lvl.levelId > _unlocked;
            final int s = _stars[lvl.levelId] ?? 0;
            final Color warnaResepi = lvl.resepi.warnaKek;

            return InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () async {
                SoundManager.klikButang();
                if (lock) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Selesaikan level sebelumnya dahulu!')));
                  return;
                }
                await Navigator.push(context, MaterialPageRoute(builder: (_) => Game3DSimulatorScreen(mission: lvl)));
                _muat();
              },
              child: Container(
                decoration: BoxDecoration(
                  color: lock ? Colors.grey.shade200 : Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: lock ? Colors.transparent : warnaResepi.withValues(alpha: 0.6), width: 1.4),
                  boxShadow: [
                    BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 4, offset: const Offset(0, 2)),
                  ],
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 8, height: 8,
                      margin: const EdgeInsets.only(bottom: 3),
                      decoration: BoxDecoration(shape: BoxShape.circle, color: lock ? Colors.grey.shade400 : warnaResepi),
                    ),
                    Icon(lock ? Icons.lock : Icons.cake_rounded, size: 26, color: lock ? Colors.grey : const Color(0xFFE91E63)),
                    const SizedBox(height: 4),
                    Text('Lv ${lvl.levelId}', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: lock ? Colors.grey : const Color(0xFF560027))),
                    Text('${lvl.jumlahKek} Kek', style: TextStyle(fontSize: 10, color: lock ? Colors.grey : Colors.blueGrey, fontWeight: FontWeight.bold)),
                    if (!lock)
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(3, (idx) => Icon(idx < s ? Icons.star : Icons.star_border, color: Colors.amber, size: 14)),
                      ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

// =========================================================================
// 8. GAMEPLAY DAPUR 3D BERSUARA
// =========================================================================

enum StesenDapur { pantri, peti, topping, singki, mejaBancuh, mejaHias, oven, kaunter }

class _Dust {
  double x, y;
  double age = 0;
  _Dust(this.x, this.y);
}

class Game3DSimulatorScreen extends StatefulWidget {
  final LevelMission mission;
  const Game3DSimulatorScreen({super.key, required this.mission});

  @override
  State<Game3DSimulatorScreen> createState() => _Game3DSimulatorScreenState();
}

class _Game3DSimulatorScreenState extends State<Game3DSimulatorScreen> with SingleTickerProviderStateMixin {
  double _pemainX = 0.0;
  double _pemainY = 60.0;
  double _dxInput = 0.0;
  double _dyInput = 0.0;
  double _velX = 0.0;
  double _velY = 0.0;
  double _walkAnim = 0.0;
  double _pandangArah = 1.0;
  int _dustTimer = 0;
  final List<_Dust> _dusts = [];

  late Ticker _gameLoop;

  Color _pakaianC = const Color(0xFFE91E63);
  Color _latarC = const Color(0xFFFFF3E0);
  Color _jubinC = const Color(0xFF8D6E63);
  Color _mejaC = const Color(0xFF7B1FA2);
  Color _aksesoriC = const Color(0xFFBDBDBD);

  final Set<String> _inventori = {};
  int _kekSiapKira = 0;
  late Map<String, double> _sukatan;
  bool _adunanSebati = false;
  bool _sedangBakar = false;
  bool _sudahMasak = false;
  bool _sudahDihias = false;
  int _masaBakarSemasa = 0;
  Timer? _bakarTimer;
  int _singkiTapCount = 0;
  int _coinsSemasa = 0;
  bool _showConfetti = false;

  late int _masaTinggal;
  Timer? _countdown;

  bool get _adaSingki => widget.mission.levelId >= 15;
  bool get _adaMejaHias => widget.mission.levelId >= 25;

  @override
  void initState() {
    super.initState();
    _masaTinggal = widget.mission.hadMasa;
    _sukatan = {for (final b in widget.mission.resepi.bahanAsas) b.nama: 0.0};
    _muatDeko();

    _gameLoop = createTicker((elapsed) {
      final targetVX = _dxInput * 4.4;
      final targetVY = _dyInput * 4.4;
      _velX += (targetVX - _velX) * 0.2;
      _velY += (targetVY - _velY) * 0.2;
      final bergerak = _velX.abs() > 0.08 || _velY.abs() > 0.08;
      if (bergerak) {
        _pemainX = (_pemainX + _velX).clamp(-170.0, 170.0);
        _pemainY = (_pemainY + _velY).clamp(-150.0, 150.0);
        _walkAnim += 0.26;
        if (_velX > 0.4) _pandangArah = 1.0;
        if (_velX < -0.4) _pandangArah = -1.0;
        _dustTimer++;
        if (_dustTimer > 7) {
          _dustTimer = 0;
          _dusts.add(_Dust(_pemainX, _pemainY + 22));
        }
      } else {
        _velX = 0;
        _velY = 0;
      }
      for (final d in _dusts) {
        d.age += 0.045;
      }
      _dusts.removeWhere((d) => d.age >= 1.0);
      setState(() {});
    });
    _gameLoop.start();

    _mulaTimer();
    WidgetsBinding.instance.addPostFrameCallback((_) => _tunjukResepiPopup());
  }

  Future<void> _muatDeko() async {
    final pk = await StorageManager.getEquip(ShopKategori.pakaian);
    final lt = await StorageManager.getEquip(ShopKategori.latar);
    final jb = await StorageManager.getEquip(ShopKategori.jubin);
    final mj = await StorageManager.getEquip(ShopKategori.meja);
    final ak = await StorageManager.getEquip(ShopKategori.aksesori);
    final c = await StorageManager.getCoins();
    Color cari(ShopKategori k, String id) => paletKedai[k]!.firstWhere((e) => e.id == id, orElse: () => paletKedai[k]!.first).warna;
    if (mounted) {
      setState(() {
        _pakaianC = cari(ShopKategori.pakaian, pk);
        _latarC = cari(ShopKategori.latar, lt);
        _jubinC = cari(ShopKategori.jubin, jb);
        _mejaC = cari(ShopKategori.meja, mj);
        _aksesoriC = cari(ShopKategori.aksesori, ak);
        _coinsSemasa = c;
      });
    }
  }

  @override
  void dispose() {
    _gameLoop.dispose();
    _countdown?.cancel();
    _bakarTimer?.cancel();
    super.dispose();
  }

  void _mulaTimer() {
    _countdown = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (_masaTinggal > 0) {
        setState(() => _masaTinggal--);
      } else {
        t.cancel();
        _tamatMasa();
      }
    });
  }

  void _tunjukResepiPopup() {
    SoundManager.klikButang();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: const BoxDecoration(color: Color(0xFF6D4C41), shape: BoxShape.circle),
              child: const Icon(Icons.face_3, color: Colors.white, size: 24),
            ),
            const SizedBox(width: 10),
            Expanded(child: Text('Pesanan Lv ${widget.mission.levelId}')),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Waguri pesan ${widget.mission.jumlahKek} biji "${widget.mission.resepi.nama}". Kutip bahan di stesen dahulu:',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              ...widget.mission.resepi.bahanAsas.map((b) {
                final lokasi = b.kategori == KategoriBahan.pantri ? 'Pantri' : b.kategori == KategoriBahan.peti ? 'Peti Sejuk' : 'Topping';
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Row(
                    children: [
                      Icon(b.ikon, color: const Color(0xFFE91E63), size: 18),
                      const SizedBox(width: 8),
                      Expanded(child: Text('${b.nama} ($lokasi)', style: const TextStyle(fontSize: 12))),
                      Text(formatSukatan(b.sukatan, b.unit), style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFE91E63), fontSize: 12)),
                    ],
                  ),
                );
              }),
              if (_adaSingki || _adaMejaHias) ...[
                const Divider(height: 20),
                if (_adaSingki) const Text('💧 Singki: cuci pinggan untuk dapat tip coins percuma!', style: TextStyle(fontSize: 11, color: Colors.blueGrey)),
                if (_adaMejaHias) const Text('🎂 Meja Hias: hias kek sebelum hidang untuk bonus coins!', style: TextStyle(fontSize: 11, color: Colors.blueGrey)),
              ],
            ],
          ),
        ),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFE91E63), foregroundColor: Colors.white),
            onPressed: () {
              SoundManager.klikButang();
              Navigator.pop(ctx);
            },
            child: const Text('MULA MEMASAK!'),
          ),
        ],
      ),
    );
  }

  Map<StesenDapur, Offset> _petaStesen() {
    final map = <StesenDapur, Offset>{
      StesenDapur.pantri: const Offset(-150, -105),
      StesenDapur.peti: const Offset(150, -105),
      StesenDapur.mejaBancuh: const Offset(-45, 5),
      StesenDapur.oven: const Offset(-115, 125),
      StesenDapur.kaunter: const Offset(130, 115),
    };
    if (widget.mission.adaStesenTopping) map[StesenDapur.topping] = const Offset(0, -122);
    if (_adaSingki) map[StesenDapur.singki] = const Offset(-150, 45);
    if (_adaMejaHias) map[StesenDapur.mejaHias] = const Offset(65, 5);
    return map;
  }

  String _namaStesen(StesenDapur s) {
    switch (s) {
      case StesenDapur.pantri: return 'Pantri';
      case StesenDapur.peti: return 'Peti Sejuk';
      case StesenDapur.topping: return 'Topping';
      case StesenDapur.singki: return 'Singki';
      case StesenDapur.mejaBancuh: return 'Meja Bancuh';
      case StesenDapur.mejaHias: return 'Meja Hias';
      case StesenDapur.oven: return 'Ketuhar 3D';
      case StesenDapur.kaunter: return 'Kaunter Pelanggan';
    }
  }

  StesenDapur? _stesenTerdekat() {
    final map = _petaStesen();
    for (final e in map.entries) {
      if ((Offset(_pemainX, _pemainY) - e.value).distance < 58) return e.key;
    }
    return null;
  }

  void _interaksi(StesenDapur s) {
    SoundManager.klikButang();
    switch (s) {
      case StesenDapur.pantri:
        _dialogKutip(KategoriBahan.pantri, 'Rak Pantri (Bahan Kering)', Icons.inventory_2, const Color(0xFF8D6E63));
        break;
      case StesenDapur.peti:
        _dialogKutip(KategoriBahan.peti, 'Peti Sejuk (Bahan Dingin)', Icons.kitchen, const Color(0xFF0288D1));
        break;
      case StesenDapur.topping:
        _dialogKutip(KategoriBahan.topping, 'Stesen Topping & Hiasan', Icons.cake, const Color(0xFFFF4081));
        break;
      case StesenDapur.mejaBancuh:
        _dialogMeja();
        break;
      case StesenDapur.mejaHias:
        _dialogHias();
        break;
      case StesenDapur.singki:
        _cuciSingki();
        break;
      case StesenDapur.oven:
        _dialogOven();
        break;
      case StesenDapur.kaunter:
        _dialogHidang();
        break;
    }
  }

  void _cuciSingki() async {
    if (_singkiTapCount >= 3) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pinggan dah bersih semua buat masa ni!'), duration: Duration(milliseconds: 900)));
      return;
    }
    SoundManager.cuciSingki();
    final tip = 3 + math.Random().nextInt(8);
    await StorageManager.addCoins(tip);
    final c = await StorageManager.getCoins();
    setState(() {
      _singkiTapCount++;
      _coinsSemasa = c;
    });
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Cuci pinggan... dapat tip +$tip coins! 💧'), duration: const Duration(milliseconds: 900)));
    }
  }

  void _dialogHias() {
    if (!_sudahMasak) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Kek belum siap dibakar lagi!')));
      return;
    }
    if (_sudahDihias) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Kek ini sudah dihias cantik!')));
      return;
    }
    SoundManager.gaulAdunan();
    setState(() => _sudahDihias = true);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Kek dihias cantik! Bonus +25 coins di akhir level 🎂')));
  }

  void _dialogKutip(KategoriBahan kat, String tajuk, IconData ikon, Color warna) {
    final list = widget.mission.resepi.bahanAsas.where((b) => b.kategori == kat).toList();
    if (list.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tiada bahan untuk diambil di stesen ini.')));
      return;
    }

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => StatefulBuilder(builder: (context, setModal) {
        return Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Icon(ikon, color: warna),
                  const SizedBox(width: 8),
                  Text(tajuk, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                ],
              ),
              const Divider(),
              ...list.map((b) {
                final ada = _inventori.contains(b.nama);
                return ListTile(
                  leading: CircleAvatar(backgroundColor: b.warna.withValues(alpha: 0.4), child: Icon(b.ikon, color: Colors.black87)),
                  title: Text(b.nama, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('Diperlukan: ${formatSukatan(b.sukatan, b.unit)}'),
                  trailing: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: ada ? Colors.green : warna, foregroundColor: Colors.white),
                    icon: Icon(ada ? Icons.check : Icons.add_shopping_cart, size: 18),
                    label: Text(ada ? 'Diambil' : 'Ambil'),
                    onPressed: () {
                      SoundManager.kutipBahan();
                      setState(() => _inventori.add(b.nama));
                      setModal(() {});
                    },
                  ),
                );
              }),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: warna, foregroundColor: Colors.white),
                  onPressed: () {
                    SoundManager.klikButang();
                    Navigator.pop(ctx);
                  },
                  child: const Text('TUTUP STESEN'),
                ),
              ),
            ],
          ),
        );
      }),
    );
  }

  void _dialogMeja() {
    final belum = widget.mission.resepi.bahanAsas.where((b) => !_inventori.contains(b.nama)).toList();
    if (belum.isNotEmpty) {
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Text('Bahan Belum Cukup!'),
          content: Text('Sila ambil bahan ini dahulu:\n• ${belum.map((b) => b.nama).join("\n• ")}'),
          actions: [ElevatedButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
        ),
      );
      return;
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => StatefulBuilder(builder: (context, setModal) {
        return Container(
          padding: const EdgeInsets.all(18),
          height: MediaQuery.of(context).size.height * 0.78,
          child: Column(
            children: [
              Row(
                children: [
                  const Icon(Icons.scale_rounded, color: Color(0xFFE91E63)),
                  const SizedBox(width: 8),
                  Expanded(child: Text('Timbang Sukatan (Kek ${_kekSiapKira + 1}/${widget.mission.jumlahKek})', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
                  IconButton(onPressed: () => Navigator.pop(ctx), icon: const Icon(Icons.close)),
                ],
              ),
              const Divider(),
              Expanded(
                child: ListView(
                  children: widget.mission.resepi.bahanAsas.map((b) {
                    final val = _sukatan[b.nama] ?? 0.0;
                    final max = b.unit == UnitBahan.biji ? 12.0 : b.sukatan * 2.2;
                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      child: Padding(
                        padding: const EdgeInsets.all(10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(b.ikon, color: const Color(0xFFE91E63), size: 18),
                                const SizedBox(width: 8),
                                Expanded(child: Text(b.nama, style: const TextStyle(fontWeight: FontWeight.bold))),
                                Text(formatSukatan(val, b.unit), style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFE91E63))),
                              ],
                            ),
                            Slider(
                              value: val.clamp(0.0, max),
                              min: 0,
                              max: max,
                              divisions: b.unit == UnitBahan.biji ? 12 : 50,
                              activeColor: const Color(0xFFE91E63),
                              onChanged: (v) {
                                setModal(() => _sukatan[b.nama] = v.roundToDouble());
                                setState(() {});
                              },
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(backgroundColor: _adunanSebati ? Colors.green : const Color(0xFFE91E63), foregroundColor: Colors.white),
                  icon: Icon(_adunanSebati ? Icons.check_circle : Icons.blender_rounded),
                  label: Text(_adunanSebati ? 'ADUNAN TELAH SEBATI' : 'GAUL ADUNAN DALAM MANGKUK'),
                  onPressed: () {
                    SoundManager.gaulAdunan();
                    setState(() => _adunanSebati = true);
                    setModal(() {});
                  },
                ),
              ),
            ],
          ),
        );
      }),
    );
  }

  void _dialogOven() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(children: [Icon(Icons.local_fire_department, color: Colors.deepOrange), SizedBox(width: 8), Text('Ketuhar 3D')]),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (!_adunanSebati)
              const Text('⚠️ Anda belum gaul adunan di meja bancuhan!')
            else if (_sedangBakar) ...[
              const CircularProgressIndicator(color: Colors.deepOrange),
              const SizedBox(height: 12),
              Text('Membakar: $_masaBakarSemasa s...', style: const TextStyle(fontWeight: FontWeight.bold)),
            ] else if (_sudahMasak)
              const Text('✅ Kek siap masak! Berikan kepada Waguri di kaunter.')
            else
              const Text('Masukkan adunan ke dalam ketuhar.'),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('TUTUP')),
          if (_adunanSebati && !_sedangBakar && !_sudahMasak)
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.deepOrange, foregroundColor: Colors.white),
              onPressed: () {
                SoundManager.klikButang();
                Navigator.pop(ctx);
                _mulaBakar();
              },
              child: const Text('BAKAR SEKARANG'),
            ),
        ],
      ),
    );
  }

  void _mulaBakar() {
    setState(() {
      _sedangBakar = true;
      _masaBakarSemasa = widget.mission.masaBakar;
    });

    _bakarTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() => _masaBakarSemasa--);
      if (_masaBakarSemasa <= 0) {
        t.cancel();
        SoundManager.ovenSiap();
        setState(() {
          _sedangBakar = false;
          _sudahMasak = true;
        });
      }
    });
  }

  void _dialogHidang() async {
    if (!_sudahMasak) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Kek belum siap dibakar!')));
      return;
    }

    _kekSiapKira++;
    if (_kekSiapKira < widget.mission.jumlahKek) {
      SoundManager.kutipBahan();
      setState(() {
        _adunanSebati = false;
        _sudahMasak = false;
        _sudahDihias = false;
        _inventori.clear();
        _sukatan = {for (final b in widget.mission.resepi.bahanAsas) b.nama: 0.0};
      });
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Text('Kek Ke-$_kekSiapKira Selesai!'),
          content: Text('Bagus! Sekarang sediakan kek ke-${_kekSiapKira + 1} daripada ${widget.mission.jumlahKek} kek yang Waguri minta.'),
          actions: [ElevatedButton(onPressed: () => Navigator.pop(ctx), child: const Text('TERUSKAN'))],
        ),
      );
      return;
    }

    double err = 0.0;
    for (final b in widget.mission.resepi.bahanAsas) {
      final v = _sukatan[b.nama] ?? 0.0;
      err += (v - b.sukatan).abs() / b.sukatan;
    }
    final purata = (err / widget.mission.resepi.bahanAsas.length).clamp(0.0, 1.0);
    final kemasanScore = 1 - purata;
    final kelajuanScore = (_masaTinggal / widget.mission.hadMasa).clamp(0.0, 1.0);
    final gabungan = kemasanScore * 0.7 + kelajuanScore * 0.3;
    int bintang = gabungan >= 0.82 ? 3 : gabungan >= 0.55 ? 2 : 1;

    final comboLama = await StorageManager.getCombo();
    final comboBaru = (bintang >= 2) ? comboLama + 1 : 0;
    await StorageManager.setCombo(comboBaru);

    int coinsDapat = widget.mission.ganjaranCoins;
    if (_sudahDihias) coinsDapat += 25;
    double gandaan = 1.0;
    if (comboBaru >= 5) {
      gandaan = 2.0;
    } else if (comboBaru >= 3) {
      gandaan = 1.5;
    }
    coinsDapat = (coinsDapat * gandaan).round();

    await StorageManager.addCoins(coinsDapat);
    await StorageManager.saveStars(widget.mission.levelId, bintang);
    await StorageManager.addCakes(widget.mission.jumlahKek);
    final streakBaru = await StorageManager.kemaskiniStreakHarian();

    final tierLama = tierUntukLevel(widget.mission.levelId);
    bool resepiBaharuTerbuka = false;
    ResepiDef? resepiSeterusnya;
    if (widget.mission.levelId < 50) {
      await StorageManager.unlockLevel(widget.mission.levelId + 1);
      final tierBaru = tierUntukLevel(widget.mission.levelId + 1);
      if (tierBaru > tierLama && tierBaru < masterResepi.length) {
        resepiBaharuTerbuka = true;
        resepiSeterusnya = masterResepi[tierBaru];
      }
    }

    if (!mounted) return;
    setState(() => _showConfetti = true);
    SoundManager.menangLevel();
    SoundManager.dapatCoins();
    if (resepiBaharuTerbuka) SoundManager.resepiBaharu();

    await Future.delayed(const Duration(milliseconds: 650));
    if (!mounted) return;
    setState(() => _showConfetti = false);

    final resepiFinal = resepiSeterusnya;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Pesanan Waguri Siap!', textAlign: TextAlign.center),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(3, (i) => TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: i < bintang ? 1.0 : 0.0),
                  duration: Duration(milliseconds: 300 + i * 150),
                  curve: Curves.elasticOut,
                  builder: (_, v, child) => Transform.scale(scale: 0.4 + v * 0.6, child: child),
                  child: Icon(i < bintang ? Icons.star_rounded : Icons.star_border_rounded, size: 44, color: Colors.amber),
                )),
              ),
              const SizedBox(height: 10),
              Text('Semua ${widget.mission.jumlahKek} biji kek siap dihidangkan!'),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(color: Colors.amber.shade100, borderRadius: BorderRadius.circular(12)),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.monetization_on, color: Colors.amber),
                    const SizedBox(width: 6),
                    Text('+$coinsDapat Coins!', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF5D4037))),
                  ],
                ),
              ),
              if (gandaan > 1.0)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text('🔥 Combo x$comboBaru — Ganjaran x$gandaan!', style: const TextStyle(color: Colors.deepOrange, fontWeight: FontWeight.bold)),
                ),
              if (streakBaru > 1)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text('📅 Streak Harian: $streakBaru hari berturut!', style: const TextStyle(color: Colors.blue, fontWeight: FontWeight.bold, fontSize: 12)),
                ),
              if (resepiBaharuTerbuka && resepiFinal != null)
                Container(
                  margin: const EdgeInsets.only(top: 10),
                  padding: const EdgeInsets.all(10),
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: resepiFinal.warnaKek.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: resepiFinal.warnaKek),
                  ),
                  child: Column(
                    children: [
                      Text('🎉 RESEPI BAHARU DIBUKA!', style: TextStyle(fontWeight: FontWeight.bold, color: resepiFinal.warnaKek)),
                      const SizedBox(height: 4),
                      Text(resepiFinal.nama, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    ],
                  ),
                ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              SoundManager.klikButang();
              Navigator.pop(ctx);
              Navigator.pop(context);
            },
            child: const Text('MENU UTAMA'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFE91E63), foregroundColor: Colors.white),
            onPressed: () {
              SoundManager.klikButang();
              Navigator.pop(ctx);
              if (widget.mission.levelId < 50) {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (_) => Game3DSimulatorScreen(mission: semua50Level[widget.mission.levelId])),
                );
              } else {
                Navigator.pop(context);
              }
            },
            child: const Text('LEVEL SETERUSNYA'),
          ),
        ],
      ),
    );
  }

  void _tamatMasa() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Masa Tamat!'),
        content: const Text('Masa pesanan habis. Cuba lagi dengan lebih pantas!'),
        actions: [
          ElevatedButton(
            onPressed: () {
              SoundManager.klikButang();
              Navigator.pop(ctx);
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => Game3DSimulatorScreen(mission: widget.mission)));
            },
            child: const Text('CUBA LAGI'),
          ),
        ],
      ),
    );
  }

  String _labelButang(StesenDapur s) {
    switch (s) {
      case StesenDapur.pantri: return 'BUKA PANTRI';
      case StesenDapur.peti: return 'BUKA PETI SEJUK';
      case StesenDapur.topping: return 'AMBIL TOPPING';
      case StesenDapur.singki: return 'CUCI SINGKI';
      case StesenDapur.mejaBancuh: return 'TIMBANG & GAUL';
      case StesenDapur.mejaHias: return _sudahDihias ? 'SUDAH DIHIAS' : 'HIAS KEK';
      case StesenDapur.oven: return _sedangBakar ? 'BAKAR ($_masaBakarSemasa s)' : 'KETUHAR 3D';
      case StesenDapur.kaunter: return 'HIDANG KE WAGURI';
    }
  }

  @override
  Widget build(BuildContext context) {
    final stesen = _stesenTerdekat();
    final peta = _petaStesen();

    return Scaffold(
      appBar: AppBar(
        title: Text('Lv ${widget.mission.levelId}: ${widget.mission.namaKek}'),
        actions: [
          IconButton(icon: const Icon(Icons.receipt_long), tooltip: 'Resepi', onPressed: _tunjukResepiPopup),
        ],
      ),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            color: Colors.pink.shade50,
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: const BoxDecoration(color: Color(0xFF6D4C41), shape: BoxShape.circle),
                  child: const Icon(Icons.face_3, color: Colors.white, size: 18),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Waguri: ${widget.mission.namaKek}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                      Text('Kek ${_kekSiapKira + 1}/${widget.mission.jumlahKek} • Bahan: ${_inventori.length}/${widget.mission.resepi.bahanAsas.length}', style: const TextStyle(fontSize: 11, color: Colors.black54)),
                    ],
                  ),
                ),
                Container(
                  margin: const EdgeInsets.only(right: 6),
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                  decoration: BoxDecoration(color: Colors.amber.shade100, borderRadius: BorderRadius.circular(12)),
                  child: Row(children: [
                    const Icon(Icons.monetization_on, color: Colors.amber, size: 14),
                    Text(' $_coinsSemasa', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Color(0xFF5D4037))),
                  ]),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(color: _masaTinggal <= 20 ? Colors.red : Colors.green.shade700, borderRadius: BorderRadius.circular(12)),
                  child: Row(
                    children: [
                      const Icon(Icons.timer, color: Colors.white, size: 16),
                      const SizedBox(width: 4),
                      Text('$_masaTinggal s', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                    ],
                  ),
                ),
              ],
            ),
          ),

          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            child: Row(
              children: peta.entries.map((e) => _chip(_namaStesen(e.key), e.value.dx, e.value.dy)).toList(),
            ),
          ),

          Expanded(
            child: Stack(
              children: [
                CustomPaint(
                  size: Size.infinite,
                  painter: Dapur3DPainter(
                    pemainX: _pemainX,
                    pemainY: _pemainY,
                    walkAnim: _walkAnim,
                    pandangArah: _pandangArah,
                    adunanSebati: _adunanSebati,
                    sedangBakar: _sedangBakar,
                    sudahMasak: _sudahMasak,
                    sudahDihias: _sudahDihias,
                    warnaKek: widget.mission.resepi.warnaKek,
                    kekPameran: _kekSiapKira,
                    jumlahKek: widget.mission.jumlahKek,
                    pakaian: _pakaianC,
                    latar: _latarC,
                    jubin: _jubinC,
                    meja: _mejaC,
                    aksesori: _aksesoriC,
                    petaStesen: peta,
                    nearestStesen: stesen,
                    dusts: _dusts,
                  ),
                ),

                if (_showConfetti)
                  Positioned.fill(child: ConfettiBurst(onDone: () {})),

                if (stesen != null)
                  Positioned(
                    bottom: 24,
                    right: 20,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFE91E63),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        elevation: 8,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      icon: const Icon(Icons.touch_app),
                      label: Text(_labelButang(stesen), style: const TextStyle(fontWeight: FontWeight.bold)),
                      onPressed: () => _interaksi(stesen),
                    ),
                  ),

                Positioned(
                  bottom: 20,
                  left: 20,
                  child: FloatingJoystick(
                    onChanged: (dx, dy) {
                      _dxInput = dx;
                      _dyInput = dy;
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _chip(String nama, double x, double y) {
    return Padding(
      padding: const EdgeInsets.only(right: 6),
      child: ActionChip(
        label: Text(nama, style: const TextStyle(fontSize: 11)),
        onPressed: () {
          SoundManager.klikButang();
          setState(() {
            _pemainX = x;
            _pemainY = y;
          });
        },
      ),
    );
  }
}

// =========================================================================
// 9. JOYSTICK WIDGET
// =========================================================================

class FloatingJoystick extends StatefulWidget {
  final Function(double dx, double dy) onChanged;
  const FloatingJoystick({super.key, required this.onChanged});

  @override
  State<FloatingJoystick> createState() => _FloatingJoystickState();
}

class _FloatingJoystickState extends State<FloatingJoystick> {
  Offset _stickPos = Offset.zero;
  static const double _radius = 48.0;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onPanUpdate: (details) {
        final n = _stickPos + details.delta;
        if (n.distance <= _radius) {
          _stickPos = n;
        } else {
          _stickPos = Offset.fromDirection(n.direction, _radius);
        }
        setState(() {});
        widget.onChanged(_stickPos.dx / _radius, _stickPos.dy / _radius);
      },
      onPanEnd: (_) {
        setState(() => _stickPos = Offset.zero);
        widget.onChanged(0.0, 0.0);
      },
      child: Container(
        width: 110,
        height: 110,
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: 0.18),
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white.withValues(alpha: 0.4), width: 2),
        ),
        child: Center(
          child: Transform.translate(
            offset: _stickPos,
            child: Container(
              width: 44,
              height: 44,
              decoration: const BoxDecoration(
                gradient: RadialGradient(colors: [Color(0xFFFF8DA1), Color(0xFFE91E63)]),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.navigation, color: Colors.white, size: 22),
            ),
          ),
        ),
      ),
    );
  }
}

// =========================================================================
// 10. CONFETTI BURST (KETIKA MENANG LEVEL)
// =========================================================================

class _Confetti {
  final double x, delay, rot;
  final Color color;
  _Confetti({required this.x, required this.delay, required this.color, required this.rot});
}

class ConfettiBurst extends StatefulWidget {
  final VoidCallback onDone;
  const ConfettiBurst({super.key, required this.onDone});

  @override
  State<ConfettiBurst> createState() => _ConfettiBurstState();
}

class _ConfettiBurstState extends State<ConfettiBurst> with SingleTickerProviderStateMixin {
  late AnimationController _c;
  final List<_Confetti> _parts = [];

  @override
  void initState() {
    super.initState();
    final rng = math.Random();
    const warnaList = [Colors.pink, Colors.amber, Colors.purple, Colors.lightBlue, Colors.green];
    for (int i = 0; i < 45; i++) {
      _parts.add(_Confetti(x: rng.nextDouble(), delay: rng.nextDouble() * 0.3, color: warnaList[rng.nextInt(warnaList.length)], rot: rng.nextDouble() * 6.28));
    }
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))
      ..forward().whenComplete(widget.onDone);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, __) => CustomPaint(size: Size.infinite, painter: _ConfettiPainter(_parts, _c.value)),
      ),
    );
  }
}

class _ConfettiPainter extends CustomPainter {
  final List<_Confetti> parts;
  final double t;
  _ConfettiPainter(this.parts, this.t);

  @override
  void paint(Canvas canvas, Size size) {
    for (final p in parts) {
      final lt = ((t - p.delay) / (1 - p.delay)).clamp(0.0, 1.0);
      if (lt <= 0) continue;
      final y = size.height * lt;
      final x = p.x * size.width + math.sin(lt * 8 + p.rot) * 14;
      final paint = Paint()..color = p.color.withValues(alpha: (1 - lt).clamp(0.0, 1.0));
      canvas.save();
      canvas.translate(x, y);
      canvas.rotate(p.rot + lt * 8);
      canvas.drawRect(Rect.fromCenter(center: Offset.zero, width: 8, height: 12), paint);
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _ConfettiPainter oldDelegate) => true;
}

// =========================================================================
// 11. LUKISAN 3D CANVAS ISOMETRIK DAPUR
// =========================================================================

class Dapur3DPainter extends CustomPainter {
  final double pemainX;
  final double pemainY;
  final double walkAnim;
  final double pandangArah;
  final bool adunanSebati;
  final bool sedangBakar;
  final bool sudahMasak;
  final bool sudahDihias;
  final Color warnaKek;
  final int kekPameran;
  final int jumlahKek;
  final Color pakaian;
  final Color latar;
  final Color jubin;
  final Color meja;
  final Color aksesori;
  final Map<StesenDapur, Offset> petaStesen;
  final StesenDapur? nearestStesen;
  final List<_Dust> dusts;

  Dapur3DPainter({
    required this.pemainX,
    required this.pemainY,
    required this.walkAnim,
    required this.pandangArah,
    required this.adunanSebati,
    required this.sedangBakar,
    required this.sudahMasak,
    required this.sudahDihias,
    required this.warnaKek,
    required this.kekPameran,
    required this.jumlahKek,
    required this.pakaian,
    required this.latar,
    required this.jubin,
    required this.meja,
    required this.aksesori,
    required this.petaStesen,
    required this.nearestStesen,
    required this.dusts,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;

    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), Paint()..color = latar);

    final linePaint = Paint()..color = jubin.withValues(alpha: 0.28)..strokeWidth = 1.8;
    for (double x = -180; x <= 180; x += 32) {
      canvas.drawLine(Offset(cx + x, cy - 150), Offset(cx + x, cy + 150), linePaint);
    }
    for (double y = -150; y <= 150; y += 32) {
      canvas.drawLine(Offset(cx - 180, cy + y), Offset(cx + 180, cy + y), linePaint);
    }
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), Paint()..color = jubin.withValues(alpha: 0.05));

    // debu langkah kaki
    for (final d in dusts) {
      final o = Offset(cx + d.x, cy + d.y);
      canvas.drawCircle(o, 5 + d.age * 9, Paint()..color = Colors.brown.withValues(alpha: (1 - d.age) * 0.22));
    }

    for (final e in petaStesen.entries) {
      final o = Offset(cx + e.value.dx, cy + e.value.dy);
      final aktif = nearestStesen == e.key;
      _lukisStesen(canvas, o, e.key, aktif);
    }

    _lukisWaguri(canvas, cx + (petaStesen[StesenDapur.kaunter]?.dx ?? 130), cy + (petaStesen[StesenDapur.kaunter]?.dy ?? 115) + 40);

    _lukisYou(canvas, cx + pemainX, cy + pemainY);
  }

  void _lukisStesen(Canvas canvas, Offset o, StesenDapur jenis, bool aktif) {
    Color warna;
    String label;
    switch (jenis) {
      case StesenDapur.pantri:
        warna = const Color(0xFF8D6E63);
        label = 'PANTRI';
        break;
      case StesenDapur.peti:
        warna = const Color(0xFF0288D1);
        label = 'PETI SEJUK';
        break;
      case StesenDapur.topping:
        warna = const Color(0xFFFF4081);
        label = 'TOPPING';
        break;
      case StesenDapur.singki:
        warna = const Color(0xFF00ACC1);
        label = 'SINGKI';
        break;
      case StesenDapur.mejaBancuh:
        warna = meja;
        label = 'MEJA BANCUH';
        break;
      case StesenDapur.mejaHias:
        warna = sudahDihias ? Colors.green.shade600 : const Color(0xFF26A69A);
        label = 'MEJA HIAS';
        break;
      case StesenDapur.oven:
        warna = sedangBakar ? Colors.deepOrange : const Color(0xFF37474F);
        label = 'KETUHAR';
        break;
      case StesenDapur.kaunter:
        warna = const Color(0xFFC2185B);
        label = 'KAUNTER';
        break;
    }

    if (aktif) {
      final pulse = (math.sin(DateTime.now().millisecondsSinceEpoch / 220) + 1) / 2;
      canvas.drawCircle(o, 44 + pulse * 8, Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..color = Colors.white.withValues(alpha: 0.75));
    }

    _box(canvas, o.dx, o.dy, 58, 48, warna, label);

    if (jenis == StesenDapur.mejaBancuh) {
      canvas.drawCircle(Offset(o.dx, o.dy - 20), 15, Paint()..color = adunanSebati ? warnaKek : Colors.grey.shade400);
    }
    if (jenis == StesenDapur.singki && aktif) {
      canvas.drawCircle(Offset(o.dx, o.dy - 18), 10, Paint()..color = Colors.lightBlue.withValues(alpha: 0.6));
    }
    if (jenis == StesenDapur.oven && sedangBakar) {
      canvas.drawCircle(Offset(o.dx, o.dy - 15), 18, Paint()..color = Colors.amber.withValues(alpha: 0.6));
    }
    if (jenis == StesenDapur.kaunter) {
      // ruang pameran mini kek
      final n = kekPameran.clamp(0, 5);
      for (int i = 0; i < n; i++) {
        final px = o.dx - 18 + i * 9.0;
        canvas.drawCircle(Offset(px, o.dy - 32), 5, Paint()..color = Colors.white);
        canvas.drawCircle(Offset(px, o.dy - 32), 3.4, Paint()..color = warnaKek);
      }
      if (sudahMasak) {
        canvas.drawCircle(Offset(o.dx, o.dy - 20), 14, Paint()..color = Colors.white);
        canvas.drawCircle(Offset(o.dx, o.dy - 20), 10, Paint()..color = warnaKek);
      }
    }
  }

  void _box(Canvas canvas, double x, double y, double w, double h, Color c, String label) {
    canvas.drawOval(Rect.fromCenter(center: Offset(x, y + h * 0.55), width: w * 0.9, height: 12), Paint()..color = Colors.black.withValues(alpha: 0.12));
    final r = Rect.fromCenter(center: Offset(x, y), width: w, height: h);
    canvas.drawRRect(RRect.fromRectAndRadius(r, const Radius.circular(8)), Paint()..color = c);
    final pAtas = Path()
      ..moveTo(r.left, r.top)
      ..lineTo(r.left + 10, r.top - 10)
      ..lineTo(r.right + 10, r.top - 10)
      ..lineTo(r.right, r.top)
      ..close();
    canvas.drawPath(pAtas, Paint()..color = Color.lerp(c, Colors.white, 0.35)!);

    final tp = TextPainter(
      text: TextSpan(text: label, style: const TextStyle(color: Colors.white, fontSize: 8.5, fontWeight: FontWeight.bold)),
      textAlign: TextAlign.center,
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, Offset(x - tp.width / 2, y - tp.height / 2));
  }

  void _lukisWaguri(Canvas canvas, double x, double y) {
    _badge(canvas, x, y - 50, 'WAGURI', const Color(0xFF6D4C41));
    canvas.drawOval(Rect.fromCenter(center: Offset(x, y + 22), width: 34, height: 12), Paint()..color = Colors.black.withValues(alpha: 0.2));
    canvas.drawOval(Rect.fromCenter(center: Offset(x - 14, y + 6), width: 14, height: 26), Paint()..color = const Color(0xFF212121));
    canvas.drawOval(Rect.fromCenter(center: Offset(x + 14, y + 6), width: 14, height: 26), Paint()..color = const Color(0xFF212121));
    canvas.drawRect(Rect.fromCenter(center: Offset(x, y + 8), width: 28, height: 22), Paint()..color = const Color(0xFF90CAF9));
    canvas.drawCircle(Offset(x, y - 10), 13.5, Paint()..color = const Color(0xFFFFCCBC));
    canvas.drawCircle(Offset(x - 8, y - 7), 3, Paint()..color = const Color(0xFFFF8A80).withValues(alpha: 0.7));
    canvas.drawCircle(Offset(x + 8, y - 7), 3, Paint()..color = const Color(0xFFFF8A80).withValues(alpha: 0.7));
    canvas.drawCircle(Offset(x - 5, y - 11), 2.5, Paint()..color = const Color(0xFF1E88E5));
    canvas.drawCircle(Offset(x + 5, y - 11), 2.5, Paint()..color = const Color(0xFF1E88E5));
    canvas.drawOval(Rect.fromCenter(center: Offset(x, y - 24), width: 34, height: 16), Paint()..color = const Color(0xFF6D4C41));
  }

  void _lukisYou(Canvas canvas, double px, double py) {
    final bobY = math.sin(walkAnim) * 3.5;
    _badge(canvas, px, py - 52 + bobY, 'YOU', const Color(0xFF4CAF50));

    canvas.drawOval(Rect.fromCenter(center: Offset(px, py + 10), width: 32, height: 14), Paint()..color = Colors.black.withValues(alpha: 0.25));

    final step = math.sin(walkAnim) * 5;
    canvas.drawCircle(Offset(px - 6, py + 6 + step), 4, Paint()..color = const Color(0xFF263238));
    canvas.drawCircle(Offset(px + 6, py + 6 - step), 4, Paint()..color = const Color(0xFF263238));

    canvas.drawCircle(Offset(px, py - 8 + bobY), 16, Paint()..color = pakaian);
    canvas.drawRect(Rect.fromCenter(center: Offset(px, py - 6 + bobY), width: 12, height: 16), Paint()..color = Colors.white);

    canvas.drawCircle(Offset(px, py - 26 + bobY), 12, Paint()..color = const Color(0xFFFFCC80));
    canvas.drawCircle(Offset(px + (pandangArah * 4), py - 26 + bobY), 2.2, Paint()..color = Colors.black87);

    canvas.drawCircle(Offset(px, py - 38 + bobY), 11, Paint()..color = Colors.white);
    canvas.drawRect(Rect.fromCenter(center: Offset(px, py - 32 + bobY), width: 18, height: 6), Paint()..color = Colors.white);

    if (aksesori != const Color(0xFFBDBDBD)) {
      canvas.drawRect(Rect.fromCenter(center: Offset(px, py - 34 + bobY), width: 20, height: 5), Paint()..color = aksesori);
    }
  }

  void _badge(Canvas canvas, double x, double y, String txt, Color c) {
    final tp = TextPainter(
      text: TextSpan(text: txt, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
      textDirection: TextDirection.ltr,
    )..layout();

    final r = Rect.fromCenter(center: Offset(x, y), width: tp.width + 12, height: tp.height + 6);
    canvas.drawRRect(RRect.fromRectAndRadius(r, const Radius.circular(8)), Paint()..color = c);
    tp.paint(canvas, Offset(x - tp.width / 2, y - tp.height / 2));
  }

  @override
  bool shouldRepaint(covariant Dapur3DPainter oldDelegate) => true;
}

// =========================================================================
// 12. PREVIEW MODEL UNTUK KEDAI
// =========================================================================

class KedaiPreviewPainter extends CustomPainter {
  final Color latar, jubin, meja, pakaian, aksesori;
  KedaiPreviewPainter({required this.latar, required this.jubin, required this.meja, required this.pakaian, required this.aksesori});

  @override
  void paint(Canvas canvas, Size size) {
    final r = RRect.fromRectAndRadius(Rect.fromLTWH(0, 0, size.width, size.height), const Radius.circular(20));
    canvas.drawRRect(r, Paint()..color = latar);

    canvas.drawRect(Rect.fromLTWH(0, size.height * 0.58, size.width, size.height * 0.42), Paint()..color = jubin.withValues(alpha: 0.3));
    final linePaint = Paint()..color = jubin.withValues(alpha: 0.55)..strokeWidth = 1.5;
    for (double x = 0; x < size.width; x += 20) {
      canvas.drawLine(Offset(x, size.height * 0.58), Offset(x - 10, size.height), linePaint);
    }

    final mejaRect = Rect.fromCenter(center: Offset(size.width * 0.78, size.height * 0.72), width: size.width * 0.26, height: size.height * 0.18);
    canvas.drawRRect(RRect.fromRectAndRadius(mejaRect, const Radius.circular(8)), Paint()..color = meja);
    canvas.drawRRect(RRect.fromRectAndRadius(mejaRect.translate(0, -6), const Radius.circular(8)), Paint()..color = Color.lerp(meja, Colors.white, 0.3)!);

    final cx = size.width * 0.36, cy = size.height * 0.52;
    canvas.drawOval(Rect.fromCenter(center: Offset(cx, cy + 48), width: 46, height: 14), Paint()..color = Colors.black.withValues(alpha: 0.15));
    canvas.drawCircle(Offset(cx, cy + 18), 22, Paint()..color = pakaian);
    canvas.drawRect(Rect.fromCenter(center: Offset(cx, cy + 18), width: 16, height: 24), Paint()..color = Colors.white);
    canvas.drawCircle(Offset(cx, cy - 12), 16, Paint()..color = const Color(0xFFFFCC80));
    canvas.drawCircle(Offset(cx - 5, cy - 12), 2.6, Paint()..color = Colors.black87);
    canvas.drawCircle(Offset(cx + 5, cy - 12), 2.6, Paint()..color = Colors.black87);
    canvas.drawCircle(Offset(cx, cy - 30), 15, Paint()..color = Colors.white);
    canvas.drawRect(Rect.fromCenter(center: Offset(cx, cy - 24), width: 24, height: 7), Paint()..color = Colors.white);
    if (aksesori != const Color(0xFFBDBDBD)) {
      canvas.drawRect(Rect.fromCenter(center: Offset(cx, cy - 20), width: 26, height: 6), Paint()..color = aksesori);
    }
  }

  @override
  bool shouldRepaint(covariant KedaiPreviewPainter oldDelegate) => true;
}

// =========================================================================
// 13. KEDAI & INVENTORI
// =========================================================================

class ShopCustomizationScreen extends StatefulWidget {
  const ShopCustomizationScreen({super.key});

  @override
  State<ShopCustomizationScreen> createState() => _ShopCustomizationScreenState();
}

class _ShopCustomizationScreenState extends State<ShopCustomizationScreen> {
  int _coins = 0;
  ShopKategori _tab = ShopKategori.pakaian;
  Map<ShopKategori, String> _equip = {};
  Map<ShopKategori, List<String>> _owned = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _muat();
  }

  Future<void> _muat() async {
    final c = await StorageManager.getCoins();
    final eq = <ShopKategori, String>{};
    final ow = <ShopKategori, List<String>>{};
    for (final k in ShopKategori.values) {
      eq[k] = await StorageManager.getEquip(k);
      ow[k] = await StorageManager.getOwned(k);
    }
    if (mounted) {
      setState(() {
        _coins = c;
        _equip = eq;
        _owned = ow;
        _loading = false;
      });
    }
  }

  Color _warnaFor(ShopKategori k) {
    final id = _equip[k];
    final list = paletKedai[k]!;
    return list.firstWhere((e) => e.id == id, orElse: () => list.first).warna;
  }

  Future<void> _pilihItem(WarnaItem item) async {
    SoundManager.klikButang();
    final owned = _owned[_tab] ?? [];
    if (owned.contains(item.id)) {
      if (_equip[_tab] == item.id) return;
      await StorageManager.setEquip(_tab, item.id);
      SoundManager.pakaiItem();
      setState(() => _equip[_tab] = item.id);
    } else {
      if (_coins < item.harga) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Coins tidak mencukupi!')));
        return;
      }
      final ok = await StorageManager.spendCoins(item.harga);
      if (ok) {
        SoundManager.beliItem();
        await StorageManager.addOwned(_tab, item.id);
        await StorageManager.setEquip(_tab, item.id);
        final c = await StorageManager.getCoins();
        setState(() {
          _coins = c;
          _owned[_tab] = [...(_owned[_tab] ?? []), item.id];
          _equip[_tab] = item.id;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final items = paletKedai[_tab]!;
    final owned = _owned[_tab] ?? [];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Kedai & Inventori'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 14),
            child: Center(
              child: Row(children: [
                const Icon(Icons.monetization_on, color: Colors.amber),
                const SizedBox(width: 4),
                Text('$_coins', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              ]),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            margin: const EdgeInsets.all(14),
            height: 170,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), boxShadow: [
              BoxShadow(color: Colors.black.withValues(alpha: 0.08), blurRadius: 10, offset: const Offset(0, 4)),
            ]),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: CustomPaint(
                size: Size.infinite,
                painter: KedaiPreviewPainter(
                  latar: _warnaFor(ShopKategori.latar),
                  jubin: _warnaFor(ShopKategori.jubin),
                  meja: _warnaFor(ShopKategori.meja),
                  pakaian: _warnaFor(ShopKategori.pakaian),
                  aksesori: _warnaFor(ShopKategori.aksesori),
                ),
              ),
            ),
          ),
          SizedBox(
            height: 46,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              children: ShopKategori.values.map((k) {
                final aktif = _tab == k;
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: ChoiceChip(
                    label: Text(kategoriNama(k), style: TextStyle(fontSize: 12, color: aktif ? Colors.white : Colors.black87, fontWeight: FontWeight.bold)),
                    avatar: Icon(kategoriIkon(k), size: 16, color: aktif ? Colors.white : const Color(0xFFE91E63)),
                    selected: aktif,
                    selectedColor: const Color(0xFFE91E63),
                    backgroundColor: Colors.pink.shade50,
                    onSelected: (_) {
                      SoundManager.klikButang();
                      setState(() => _tab = k);
                    },
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(14),
              itemCount: items.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.8),
              itemBuilder: (_, i) {
                final it = items[i];
                final ada = owned.contains(it.id);
                final dipakai = _equip[_tab] == it.id;
                return GestureDetector(
                  onTap: () => _pilihItem(it),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: dipakai ? const Color(0xFFE91E63) : Colors.grey.shade200, width: dipakai ? 3 : 1),
                      boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 4, offset: const Offset(0, 2))],
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Stack(alignment: Alignment.center, children: [
                          Container(
                            width: 42,
                            height: 42,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: it.warna,
                              border: Border.all(color: Colors.white, width: 2),
                              boxShadow: [BoxShadow(color: it.warna.withValues(alpha: 0.5), blurRadius: 6)],
                            ),
                          ),
                          if (dipakai)
                            const Positioned(bottom: -2, right: -2, child: CircleAvatar(radius: 9, backgroundColor: Colors.green, child: Icon(Icons.check, size: 12, color: Colors.white))),
                          if (!ada)
                            Positioned(bottom: -2, right: -2, child: CircleAvatar(radius: 9, backgroundColor: Colors.grey.shade600, child: const Icon(Icons.lock, size: 10, color: Colors.white))),
                        ]),
                        const SizedBox(height: 6),
                        Text(it.nama, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis),
                        Text(
                          ada ? (dipakai ? 'Dipakai' : 'Dimiliki') : '${it.harga} coins',
                          style: TextStyle(fontSize: 9, color: ada ? Colors.green.shade700 : Colors.orange.shade800, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// =========================================================================
// 14. PENCAPAIAN (ACHIEVEMENTS)
// =========================================================================

class AchievementsScreen extends StatelessWidget {
  final int totalCakes;
  final int totalStars;
  final int streak;
  const AchievementsScreen({super.key, required this.totalCakes, required this.totalStars, required this.streak});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> badges = [
      {'nama': 'Pembuat Kek Pertama', 'desc': 'Siapkan sekurang-kurangnya 1 biji kek', 'un': totalCakes >= 1, 'ikon': Icons.cake},
      {'nama': 'Baker Berbakat', 'desc': 'Siapkan 10 biji kek untuk pelanggan', 'un': totalCakes >= 10, 'ikon': Icons.local_fire_department},
      {'nama': 'Master Baker', 'desc': 'Siapkan 25 biji kek dengan jayanya', 'un': totalCakes >= 25, 'ikon': Icons.military_tech},
      {'nama': 'Legenda Baker Waguri', 'desc': 'Capai 50 biji kek siap', 'un': totalCakes >= 50, 'ikon': Icons.workspace_premium},
      {'nama': 'Perfect Baker', 'desc': 'Kumpul 30 bintang merentasi semua level', 'un': totalStars >= 30, 'ikon': Icons.star_rounded},
      {'nama': 'Bintang Legenda', 'desc': 'Kumpul 100 bintang keseluruhan', 'un': totalStars >= 100, 'ikon': Icons.auto_awesome},
      {'nama': 'Setia Setiap Hari', 'desc': 'Main 3 hari berturut-turut', 'un': streak >= 3, 'ikon': Icons.calendar_month},
      {'nama': 'Streak Master', 'desc': 'Main 7 hari berturut-turut', 'un': streak >= 7, 'ikon': Icons.local_fire_department_outlined},
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Lencana Pencapaian')),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: badges.length,
        itemBuilder: (_, i) {
          final b = badges[i];
          final bool un = b['un'];
          return Card(
            margin: const EdgeInsets.symmetric(vertical: 5),
            color: un ? Colors.white : Colors.grey.shade200,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: un ? Colors.amber.shade100 : Colors.grey.shade300,
                child: Icon(b['ikon'], color: un ? Colors.amber.shade900 : Colors.grey),
              ),
              title: Text(b['nama'], style: TextStyle(fontWeight: FontWeight.bold, color: un ? Colors.black87 : Colors.grey)),
              subtitle: Text(b['desc']),
              trailing: Icon(un ? Icons.check_circle : Icons.lock, color: un ? Colors.green : Colors.grey),
            ),
          );
        },
      ),
    );
  }
}

// =========================================================================
// 15. MODE KIRA SUKATAN RESEPI (HANYA RESEPI TERBUKA)
// =========================================================================

class KalkulatorScreen extends StatefulWidget {
  const KalkulatorScreen({super.key});

  @override
  State<KalkulatorScreen> createState() => _KalkulatorScreenState();
}

class _KalkulatorScreenState extends State<KalkulatorScreen> {
  ResepiDef? _resepi;
  int _jumlah = 1;
  List<ResepiDef> _senarai = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _muat();
  }

  Future<void> _muat() async {
    final unlocked = await StorageManager.getUnlockedLevel();
    final maxTier = tierUntukLevel(unlocked);
    final senarai = masterResepi.sublist(0, maxTier + 1);
    if (mounted) {
      setState(() {
        _senarai = senarai;
        _resepi = senarai.first;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading || _resepi == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    return Scaffold(
      appBar: AppBar(title: const Text('Mode Kira Sukatan Resepi')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.pink.shade50, borderRadius: BorderRadius.circular(12)),
              child: const Text('Kira nisbah sukatan bahan secara automatik bagi 1 kek sehingga berpuluh biji kek! Resepi yang belum dibuka tidak dipaparkan di sini.'),
            ),
            const SizedBox(height: 16),
            DropdownButton<ResepiDef>(
              isExpanded: true,
              value: _resepi,
              items: _senarai.map((r) => DropdownMenuItem(value: r, child: Text(r.nama))).toList(),
              onChanged: (r) {
                if (r != null) {
                  SoundManager.klikButang();
                  setState(() => _resepi = r);
                }
              },
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton.filled(
                  icon: const Icon(Icons.remove),
                  onPressed: () {
                    if (_jumlah > 1) {
                      SoundManager.klikButang();
                      setState(() => _jumlah--);
                    }
                  },
                ),
                const SizedBox(width: 20),
                Text('$_jumlah Biji Kek', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF560027))),
                const SizedBox(width: 20),
                IconButton.filled(
                  icon: const Icon(Icons.add),
                  onPressed: () {
                    SoundManager.klikButang();
                    setState(() => _jumlah++);
                  },
                ),
              ],
            ),
            const SizedBox(height: 14),
            ..._resepi!.bahanAsas.map((b) {
              final total = b.sukatan * _jumlah;
              return Card(
                child: ListTile(
                  leading: Icon(b.ikon, color: const Color(0xFFE91E63)),
                  title: Text(b.nama, style: const TextStyle(fontWeight: FontWeight.bold)),
                  trailing: Text(formatSukatan(total, b.unit), style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFE91E63))),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}