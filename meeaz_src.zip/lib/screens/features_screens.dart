import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:camera/camera.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';
import 'dart:typed_data';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/image_service.dart';
import '../services/chat_service.dart';

// --- Feature 1: Mini-games ---
class MiniGamesScreen extends StatefulWidget {
  const MiniGamesScreen({super.key});

  @override
  State<MiniGamesScreen> createState() => _MiniGamesScreenState();
}

class _MiniGamesScreenState extends State<MiniGamesScreen> {
  int _score = 0;
  int _currentQuestionIndex = 0;
  bool _showResult = false;

  final List<Map<String, dynamic>> _questions = [
    {
      'question': 'Apakah warna kegemaran Kaoruko Waguri?',
      'options': ['Biru', 'Merah Jambu (Pink)', 'Hijau', 'Kuning'],
      'answer': 1,
    },
    {
      'question': 'Di manakah Kaoruko Waguri selalu menghabiskan masa petangnya?',
      'options': ['Perpustakaan', 'Taman Bunga', 'Kafe Kek', 'Rumah'],
      'answer': 2,
    },
    {
      'question': 'Apakah sifat utama Kaoruko Waguri?',
      'options': ['Garang', 'Pemalu dan Lembut', 'Sombong', 'Bising'],
      'answer': 1,
    },
  ];

  void _answerQuestion(int index) {
    if (index == _questions[_currentQuestionIndex]['answer']) {
      setState(() => _score++);
    }

    if (_currentQuestionIndex < _questions.length - 1) {
      setState(() => _currentQuestionIndex++);
    } else {
      setState(() => _showResult = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mini-Games with Kaoruko'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(24),
        child: _showResult ? _buildResult() : _buildQuiz(),
      ),
    );
  }

  Widget _buildQuiz() {
    final question = _questions[_currentQuestionIndex];
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const CircleAvatar(
          radius: 50,
          backgroundImage: AssetImage('assets/pfp.jpg'),
        ),
        const SizedBox(height: 24),
        Text(
          'Soalan ${_currentQuestionIndex + 1}/${_questions.length}',
          style: const TextStyle(color: Colors.grey, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        Text(
          question['question'],
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 40),
        ...List.generate(question['options'].length, (index) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () => _answerQuestion(index),
                child: Text(question['options'][index]),
              ),
            ),
          );
        }),
      ],
    );
  }

  Widget _buildResult() {
    String message = "";
    if (_score == _questions.length) {
      message = "Hebat! Awak memang kenal Kaoruko dengan sangat baik! 🌸";
    } else if (_score > 0) {
      message = "Boleh tahan! Kaoruko gembira awak cuba mengenali dia. 😊";
    } else {
      message = "Tak apa, jom borak lagi dengan Kaoruko supaya lebih kenal! 🤍";
    }

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.stars_rounded, size: 80, color: Colors.amber),
        const SizedBox(height: 24),
        const Text(
          'Keputusan Quiz',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        Text(
          'Skor Anda: $_score / ${_questions.length}',
          style: const TextStyle(fontSize: 18),
        ),
        const SizedBox(height: 24),
        Text(
          message,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 16),
        ),
        const SizedBox(height: 40),
        ElevatedButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Kembali ke Home'),
        ),
      ],
    );
  }
}

// --- Feature 2: Photo Mode with AI ---
class PhotoModeScreen extends StatefulWidget {
  const PhotoModeScreen({super.key});

  @override
  State<PhotoModeScreen> createState() => _PhotoModeScreenState();
}

class _PhotoModeScreenState extends State<PhotoModeScreen> {
  final ImageService _imageService = ImageService();
  final ImagePicker _picker = ImagePicker();
  bool _isGenerating = false;
  String? _generatedImageBase64;

  Future<void> _startProcess() async {
    final bool? shouldIncludeKaoruko = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Penjanaan Imej AI'),
        content: const Text('Adakah Kaoruko perlu muncul secara visual dalam output ini?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Tidak')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Ya')),
        ],
      ),
    );

    if (shouldIncludeKaoruko == null) return;

    if (shouldIncludeKaoruko) {
      final bool? isSelfieTogether = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Selfie Bersama?'),
          content: const Text('Adakah anda mahu menjana gambar bersama Kaoruko? (Sila muat naik gambar anda jika ya)'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Kaoruko Sahaja')),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Bersama Saya')),
          ],
        ),
      );

      if (isSelfieTogether == true) {
        final XFile? picked = await _picker.pickImage(source: ImageSource.gallery);
        if (picked == null) return;
      }
    }

    final TextEditingController controller = TextEditingController();
    final String? userRequest = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Apa yang anda bayangkan?'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(hintText: "Contoh: Sedang makan aiskrim di taman"),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, controller.text), child: const Text('Jana')),
        ],
      ),
    );

    if (userRequest == null || userRequest.isEmpty) return;

    setState(() => _isGenerating = true);

    try {
      final result = await _imageService.generateImage(
        userRequest,
        includeKaoruko: shouldIncludeKaoruko,
        timeContext: _getTimeContext(),
      );

      if (mounted) {
        setState(() {
          _generatedImageBase64 = result;
          _isGenerating = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isGenerating = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Gagal: $e")));
      }
    }
  }

  String _getTimeContext() {
    final now = DateTime.now();
    final hour = now.hour;
    if (hour >= 5 && hour < 9) return "Pagi";
    if (hour >= 9 && hour < 17) return "Tengah hari";
    if (hour >= 17 && hour < 21) return "Petang";
    return "Malam";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI Photo Mode')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              if (_isGenerating)
                const CircularProgressIndicator()
              else if (_generatedImageBase64 != null)
                Column(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: Image.memory(base64Decode(_generatedImageBase64!)),
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton.icon(
                      onPressed: () {},
                      icon: const Icon(Icons.save_rounded),
                      label: const Text('Simpan'),
                    ),
                  ],
                )
              else
                Column(
                  children: [
                    const Icon(Icons.camera_enhance_rounded, size: 80, color: Color(0xFFD7B1D7)),
                    const SizedBox(height: 30),
                    ElevatedButton(
                      onPressed: _startProcess,
                      child: const Text('Mula Menjana'),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// --- Feature 3: Live Wallpaper / Widget ---
class LiveWallpaperScreen extends StatelessWidget {
  const LiveWallpaperScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Live Wallpaper & Widget')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.wallpaper_rounded, size: 80, color: Color(0xFFA0C49D)),
            const SizedBox(height: 20),
            const Text('Aktifkan Kaoruko di Home Screen anda!', textAlign: TextAlign.center),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {},
              child: const Text('Pasang Widget'),
            ),
          ],
        ),
      ),
    );
  }
}

// --- Feature 4: Voice Call Simulation ---
class VoiceCallScreen extends StatefulWidget {
  const VoiceCallScreen({super.key});

  @override
  State<VoiceCallScreen> createState() => _VoiceCallScreenState();
}

class _VoiceCallScreenState extends State<VoiceCallScreen> {
  final ChatService _chatService = ChatService();
  final FlutterTts _tts = FlutterTts();
  final stt.SpeechToText _speech = stt.SpeechToText();
  
  bool _isCalling = false;
  bool _isConnected = false;
  bool _isListening = false;
  bool _showCamera = false;
  bool _isProcessing = false;
  
  CameraController? _cameraController;
  Timer? _timer;
  int _seconds = 0;
  String _statusText = "Menunggu panggilan...";
  String _userSpokenText = "";

  @override
  void initState() {
    super.initState();
    _initTts();
    _initSpeech();
  }

  Future<void> _initTts() async {
    await _tts.setLanguage("ms-MY"); 
    await _tts.setPitch(1.4); 
    await _tts.setSpeechRate(0.48);
    await _tts.setVolume(1.0);
    
    _tts.setStartHandler(() {
      if (mounted) setState(() => _isListening = false);
    });

    try {
      if (Platform.isAndroid || Platform.isIOS) {
        List<dynamic> voices = await _tts.getVoices;
        for (var voice in voices) {
          if (voice["locale"].toString().contains("ms-MY") && 
              voice["name"].toString().toLowerCase().contains("female")) {
            await _tts.setVoice({"name": voice["name"], "locale": voice["locale"]});
            break;
          }
        }
      }
    } catch (e) {
      debugPrint("Voice setting error: $e");
    }
  }

  Future<void> _initSpeech() async {
    try {
      bool available = await _speech.initialize(
        onStatus: (status) {
          debugPrint("STT Status: $status");
          if (status == 'notListening' && _isConnected && mounted && !_isProcessing) {
            if (_userSpokenText.trim().isNotEmpty || _showCamera) {
              _processUserInteraction();
            } else {
              _startListeningLoop();
            }
          }
        },
        onError: (e) => debugPrint("STT error: $e"),
      );
      if (!available) {
        debugPrint("Speech recognition not available");
      }
    } catch (e) {
      debugPrint("STT Init error: $e");
    }
  }

  Future<void> _initCamera() async {
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) return;
      
      // Pilih Front Camera secara default
      final frontCamera = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.front, 
        orElse: () => cameras.first
      );

      _cameraController = CameraController(
        frontCamera,
        ResolutionPreset.max, // Preset paling tinggi untuk full screen
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.jpeg,
      );
      
      await _cameraController!.initialize();
      if (mounted) setState(() {});
    } catch (e) {
      debugPrint("Camera Error: $e");
    }
  }

  void _startCall() async {
    final status = await Permission.microphone.request();
    if (status.isGranted) {
      setState(() {
        _isCalling = true;
        _statusText = "Panggilan Masuk...";
      });
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Kebenaran mikrofon diperlukan untuk panggilan.')),
        );
      }
    }
  }

  void _acceptCall() async {
    setState(() {
      _isConnected = true;
      _statusText = "Bersambung...";
    });
    
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted) setState(() => _seconds++);
    });

    // Mod skrin penuh (Immersive) semasa panggilan
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    final greeting = "Eh... hello? Awak ke tu? Ada apa-apa nak saya bantu?";
    setState(() => _statusText = greeting);
    await _tts.speak(greeting);
    _tts.setCompletionHandler(() {
      if (mounted && _isConnected) {
        _startListeningLoop();
      }
    });
  }

  void _startListeningLoop() async {
    if (!_isConnected || !mounted || _isProcessing) return;
    
    _userSpokenText = ""; 
    
    if (_speech.isAvailable) {
      setState(() {
        _isListening = true;
        _statusText = "Mendengar...";
      });
      
      await _speech.listen(
        onResult: (val) {
          setState(() {
            _userSpokenText = val.recognizedWords;
          });
          if (val.finalResult) {
            _processUserInteraction();
          }
        },
        listenFor: const Duration(seconds: 15),
        pauseFor: const Duration(seconds: 5),
        onDevice: false,
      );
    } else {
      await _initSpeech();
      Future.delayed(const Duration(seconds: 1), _startListeningLoop);
    }
  }

  Future<void> _processUserInteraction() async {
    if (!_isConnected || _isProcessing || !mounted) return;
    
    setState(() {
      _isListening = false;
      _isProcessing = true;
      _statusText = "Kaoruko sedang berfikir...";
    });

    Uint8List? imageBytes;
    if (_showCamera && _cameraController != null && _cameraController!.value.isInitialized) {
      try {
        final XFile file = await _cameraController!.takePicture();
        imageBytes = await file.readAsBytes();
      } catch (e) {
        debugPrint("Capture Error: $e");
      }
    }

    try {
      final response = await _chatService.getVoiceCallResponse(
        _userSpokenText,
        imageBytes: imageBytes,
        mimeType: 'image/jpeg',
      );

      if (mounted && _isConnected) {
        setState(() {
          _statusText = response;
          _userSpokenText = "";
          _isProcessing = false;
        });

        await _tts.speak(response);
        
        _tts.setCompletionHandler(() {
          if (mounted && _isConnected) {
            _startListeningLoop();
          }
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _statusText = "Eh talian tak baguslah...";
          _isProcessing = false;
        });
      }
      Future.delayed(const Duration(seconds: 3), _startListeningLoop);
    }
  }

  void _toggleCamera() async {
    if (_showCamera) {
      await _cameraController?.dispose();
      _cameraController = null;
      setState(() => _showCamera = false);
    } else {
      await _initCamera();
      setState(() => _showCamera = true);
    }
  }

  void _endCall() {
    _timer?.cancel();
    _speech.stop();
    _tts.stop();
    _cameraController?.dispose();
    
    // Kembalikan UI ke mod biasa
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

    setState(() {
      _isCalling = false;
      _isConnected = false;
      _showCamera = false;
      _isProcessing = false;
      _seconds = 0;
    });
  }

  String _formatDuration(int totalSeconds) {
    final minutes = (totalSeconds ~/ 60).toString().padLeft(2, '0');
    final seconds = (totalSeconds % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  @override
  void dispose() {
    _timer?.cancel();
    _cameraController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const roseAccent = Color(0xFFC97C6D);
    
    if (_isCalling) {
      return Scaffold(
        backgroundColor: const Color(0xFF1C1C1E),
        body: Stack(
          children: [
            if (_showCamera && _cameraController != null && _cameraController!.value.isInitialized)
              Positioned.fill(
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _cameraController!.value.previewSize!.height,
                    height: _cameraController!.value.previewSize!.width,
                    child: CameraPreview(_cameraController!),
                  ),
                ),
              )
            else
              Positioned.fill(
                child: Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Color(0xFF2C2C2E), Color(0xFF1C1C1E)],
                    ),
                  ),
                ),
              ),
            
            SafeArea(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 40),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 24),
                          child: Text(
                            _statusText,
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.white70, fontSize: 16, letterSpacing: 0.5),
                          ),
                        ),
                        const SizedBox(height: 30),
                        if (!_showCamera)
                          TweenAnimationBuilder<double>(
                            tween: Tween<double>(begin: 1.0, end: _isProcessing ? 1.05 : 1.0),
                            duration: const Duration(milliseconds: 500),
                            builder: (context, scale, child) {
                              return Transform.scale(
                                scale: scale,
                                child: Container(
                                  width: 240,
                                  height: 240,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(color: roseAccent.withValues(alpha: 0.3), width: 8),
                                    boxShadow: [
                                      BoxShadow(
                                        color: roseAccent.withValues(alpha: 0.2),
                                        blurRadius: 50,
                                        spreadRadius: 10,
                                      ),
                                    ],
                                  ),
                                  child: ClipOval(
                                    child: Image.asset('assets/pfp.jpg', fit: BoxFit.cover),
                                  ),
                                ),
                              );
                            },
                          ),
                        const SizedBox(height: 24),
                        const Text(
                          'Kaoruko Waguri',
                          style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold),
                        ),
                        if (_isConnected) ...[
                          const SizedBox(height: 12),
                          Text(
                            _formatDuration(_seconds),
                            style: const TextStyle(color: Colors.white60, fontSize: 18),
                          ),
                        ],
                      ],
                    ),
                  ),
                  
                  Padding(
                    padding: const EdgeInsets.only(bottom: 60),
                    child: Column(
                      children: [
                        if (!_isConnected)
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              _CallButton(
                                icon: Icons.call_end_rounded,
                                color: Colors.redAccent,
                                label: 'Tolak',
                                onTap: _endCall,
                              ),
                              _CallButton(
                                icon: Icons.call_rounded,
                                color: Colors.greenAccent.shade700,
                                label: 'Terima',
                                onTap: _acceptCall,
                              ),
                            ],
                          )
                        else
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                _SmallActionButton(
                                  icon: _showCamera ? Icons.videocam_off_rounded : Icons.videocam_rounded,
                                  onTap: _toggleCamera,
                                  isActive: _showCamera,
                                ),
                                _CallButton(
                                  icon: Icons.call_end_rounded,
                                  color: Colors.redAccent,
                                  label: 'Tamatkan',
                                  onTap: _endCall,
                                ),
                                _SmallActionButton(
                                  icon: _isListening ? Icons.mic_rounded : Icons.mic_off_rounded,
                                  onTap: () {
                                    if (!_isListening) {
                                      _startListeningLoop();
                                    } else {
                                      _speech.stop();
                                      setState(() => _isListening = false);
                                    }
                                  },
                                  isActive: _isListening,
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Voice Call Simulation')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.call_rounded, size: 80, color: roseAccent),
            const SizedBox(height: 20),
            const Text('Simulasi panggilan intim dari Kaoruko'),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: _startCall,
              child: const Text('Mulakan Simulasi Panggilan'),
            ),
          ],
        ),
      ),
    );
  }
}

class _CallButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;
  final VoidCallback onTap;

  const _CallButton({
    required this.icon,
    required this.color,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        GestureDetector(
          onTap: onTap,
          child: Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
            child: Icon(icon, color: Colors.white, size: 30),
          ),
        ),
        const SizedBox(height: 8),
        Text(label, style: const TextStyle(color: Colors.white70)),
      ],
    );
  }
}

class _SmallActionButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool isActive;

  const _SmallActionButton({
    required this.icon,
    required this.onTap,
    this.isActive = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 55,
        height: 55,
        decoration: BoxDecoration(
          color: isActive ? Colors.white : Colors.white10,
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: isActive ? Colors.black : Colors.white, size: 26),
      ),
    );
  }
}
