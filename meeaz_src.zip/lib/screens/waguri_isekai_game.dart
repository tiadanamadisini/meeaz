// waguri_isekai_game.dart
//
// "Kediaman Isekai Waguri" — game 3D open world (grafik PC) dalam Game Hub.
// Game penuh ialah satu fail HTML (three.js dibenamkan) di
// assets/games/waguri/index.html, dimainkan dalam WebView — jalan tanpa internet.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';

class WaguriIsekaiGame extends StatefulWidget {
  const WaguriIsekaiGame({super.key});

  @override
  State<WaguriIsekaiGame> createState() => _WaguriIsekaiGameState();
}

class _WaguriIsekaiGameState extends State<WaguriIsekaiGame> {
  late final WebViewController _controller;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    // Skrin penuh + auto landscape semasa bermain.
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF0F172A))
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (_) {
            if (mounted) setState(() => _loading = false);
          },
          // Game tak perlukan pautan luar; kekalkan dalam app.
          onNavigationRequest: (req) {
            final u = req.url;
            if (u.startsWith('file:') || u.startsWith('about:') || u.startsWith('data:') || u.startsWith('blob:')) {
              return NavigationDecision.navigate;
            }
            return NavigationDecision.prevent;
          },
        ),
      )
      ..loadFlutterAsset('assets/games/waguri/index.html');
  }

  @override
  void dispose() {
    // Simpan progres game sebelum keluar, kemudian pulihkan bar sistem.
    _controller.runJavaScript("try{dispatchEvent(new Event('pagehide'))}catch(e){}");
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    // Balik ke potret bila keluar ke Game Hub (macam app biasa).
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: Stack(
        children: [
          Positioned.fill(child: WebViewWidget(controller: _controller)),
          if (_loading)
            const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(color: Color(0xFFFBBF24)),
                  SizedBox(height: 14),
                  Text('Memuatkan Kediaman Isekai Waguri…',
                      style: TextStyle(color: Color(0xFFFEF3C7), fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          // Butang kembali ke Game Hub (bawah tengah, kecil supaya tak ganggu kawalan game)
          SafeArea(
            child: Align(
              alignment: Alignment.topCenter,
              child: Padding(
                padding: const EdgeInsets.only(top: 56),
                child: Material(
                  color: Colors.black.withValues(alpha: 0.35),
                  borderRadius: BorderRadius.circular(16),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () => Navigator.of(context).maybePop(),
                    child: const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.arrow_back_rounded, color: Colors.white, size: 16),
                          SizedBox(width: 4),
                          Text('Game Hub', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
