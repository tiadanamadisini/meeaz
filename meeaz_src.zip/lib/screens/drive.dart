// =============================================================================
// PERMAINAN FLUTTER 3D: KUIH DELIVERY - KAORUKO RUN (香る花は凛と咲く)
// SATU FAIL SAHAJA (main.dart) - 100% OFFLINE, TIADA ASSET LUARAN
// =============================================================================

import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class KuihDeliveryApp extends StatefulWidget {
  const KuihDeliveryApp({super.key});

  @override
  State<KuihDeliveryApp> createState() => _KuihDeliveryAppState();
}

class _KuihDeliveryAppState extends State<KuihDeliveryApp> {
  int totalCoins = 80;
  Set<int> unlockedLevels = {1};
  Set<String> unlockedCars = {"waguri_pink"};
  LocationLevel selectedLevel = GameDatabase.levels[0];
  CarColorOption selectedCar = GameDatabase.carPaints[0];
  String currentScreen = "menu";

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _loadProgress();
  }

  @override
  void dispose() {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void tambahCoins(int jumlah) {
    setState(() {
      totalCoins += jumlah;
    });
    _saveProgress();
  }

  Future<void> _loadProgress() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      totalCoins = prefs.getInt('kuih_delivery_coins') ?? totalCoins;
      unlockedLevels = (prefs.getStringList('kuih_delivery_levels') ?? ['1'])
          .map(int.tryParse)
          .whereType<int>()
          .toSet();
      unlockedLevels.add(1);
      unlockedCars =
          (prefs.getStringList('kuih_delivery_cars') ?? ['waguri_pink'])
              .toSet();
      unlockedCars.add('waguri_pink');
      final selectedLevelId = prefs.getInt('kuih_delivery_selected_level') ?? 1;
      selectedLevel = GameDatabase.levels.firstWhere(
        (level) =>
            level.id == selectedLevelId && unlockedLevels.contains(level.id),
        orElse: () => GameDatabase.levels.first,
      );
      final selectedCarId =
          prefs.getString('kuih_delivery_selected_car') ?? 'waguri_pink';
      selectedCar = GameDatabase.carPaints.firstWhere(
        (car) => car.id == selectedCarId && unlockedCars.contains(car.id),
        orElse: () => GameDatabase.carPaints.first,
      );
    });
  }

  Future<void> _saveProgress() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('kuih_delivery_coins', totalCoins);
    await prefs.setStringList('kuih_delivery_levels',
        unlockedLevels.map((id) => id.toString()).toList());
    await prefs.setStringList('kuih_delivery_cars', unlockedCars.toList());
    await prefs.setInt('kuih_delivery_selected_level', selectedLevel.id);
    await prefs.setString('kuih_delivery_selected_car', selectedCar.id);
  }

  void bukaKunciLevel(LocationLevel lvl) {
    if (totalCoins >= lvl.hargaBukaKunci && !unlockedLevels.contains(lvl.id)) {
      HapticFeedback.mediumImpact();
      SystemSound.play(SystemSoundType.click);
      setState(() {
        totalCoins -= lvl.hargaBukaKunci;
        unlockedLevels.add(lvl.id);
        selectedLevel = lvl;
      });
      _saveProgress();
    }
  }

  void bukaKunciKereta(CarColorOption car) {
    if (totalCoins >= car.harga && !unlockedCars.contains(car.id)) {
      HapticFeedback.mediumImpact();
      SystemSound.play(SystemSoundType.click);
      setState(() {
        totalCoins -= car.harga;
        unlockedCars.add(car.id);
        selectedCar = car;
      });
      _saveProgress();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: ThemeData(
        brightness: Brightness.dark,
        primaryColor: const Color(0xFFFF5E8A),
        scaffoldBackgroundColor: const Color(0xFF0F172A),
        fontFamily: 'sans-serif',
      ),
      child: Builder(builder: (context) {
        switch (currentScreen) {
          case "menu":
            return MenuScreen(
              totalCoins: totalCoins,
              onMula: () => setState(() => currentScreen = "game"),
              onPilihLokasi: () => setState(() => currentScreen = "locations"),
              onPilihKereta: () => setState(() => currentScreen = "cars"),
              onCaraMain: () => setState(() => currentScreen = "tutorial"),
            );
          case "locations":
            return LocationSelectScreen(
              selectedLevel: selectedLevel,
              unlockedLevels: unlockedLevels,
              totalCoins: totalCoins,
              onSelect: (lvl) {
                setState(() {
                  selectedLevel = lvl;
                  currentScreen = "game";
                });
                _saveProgress();
              },
              onUnlock: bukaKunciLevel,
              onBack: () => setState(() => currentScreen = "menu"),
            );
          case "cars":
            return CarSelectScreen(
              selectedCar: selectedCar,
              unlockedCars: unlockedCars,
              totalCoins: totalCoins,
              onSelect: (car) {
                setState(() => selectedCar = car);
                _saveProgress();
              },
              onUnlock: bukaKunciKereta,
              onBack: () => setState(() => currentScreen = "menu"),
            );
          case "tutorial":
            return TutorialScreen(
              onBack: () => setState(() => currentScreen = "menu"),
            );
          case "game":
          default:
            return GameScreen(
              level: selectedLevel,
              carColor: selectedCar,
              onVictory: (stars, coinsEarned, score) {
                tambahCoins(coinsEarned);
                if (selectedLevel.id + 1 <= GameDatabase.levels.length) {
                  setState(() => unlockedLevels.add(selectedLevel.id + 1));
                }
                _saveProgress();
              },
              onNextLevel: () {
                final idx = GameDatabase.levels
                    .indexWhere((l) => l.id == selectedLevel.id);
                if (idx + 1 < GameDatabase.levels.length) {
                  setState(() {
                    selectedLevel = GameDatabase.levels[idx + 1];
                  });
                  _saveProgress();
                }
              },
              onKembaliMenu: () => setState(() => currentScreen = "menu"),
            );
        }
      }),
    );
  }
}

// =============================================================================
// DATABASE PERMAINAN
// =============================================================================

class LocationLevel {
  final int id;
  final String nama;
  final String deskripsi;
  final int hargaBukaKunci;
  final Color warnaTema;
  final List<Color> gradientJalan;
  final int kesukaran; // 1-5

  const LocationLevel({
    required this.id,
    required this.nama,
    required this.deskripsi,
    required this.hargaBukaKunci,
    required this.warnaTema,
    required this.gradientJalan,
    required this.kesukaran,
  });
}

class CarColorOption {
  final String id;
  final String nama;
  final Color warna;
  final int harga;

  const CarColorOption({
    required this.id,
    required this.nama,
    required this.warna,
    required this.harga,
  });
}

class GameDatabase {
  static const List<LocationLevel> levels = [
    LocationLevel(
      id: 1,
      nama: "Kikyo Academy Road",
      deskripsi: "Jalan santai menuju sekolah Kaoruko.",
      hargaBukaKunci: 0,
      warnaTema: Color(0xFFFF9EBC),
      gradientJalan: [Color(0xFF334155), Color(0xFF1E293B)],
      kesukaran: 1,
    ),
    LocationLevel(
      id: 2,
      nama: "Chidori High Suburbs",
      deskripsi: "Kawasan perumahan Waguri yang tenang.",
      hargaBukaKunci: 50,
      warnaTema: Color(0xFF90CDF4),
      gradientJalan: [Color(0xFF1E293B), Color(0xFF0F172A)],
      kesukaran: 2,
    ),
    LocationLevel(
      id: 3,
      nama: "Night City Express",
      deskripsi: "Penghantaran kuih ekspres di tengah malam.",
      hargaBukaKunci: 150,
      warnaTema: Color(0xFFB794F4),
      gradientJalan: [Color(0xFF0F172A), Color(0xFF020617)],
      kesukaran: 3,
    ),
    LocationLevel(
      id: 4,
      nama: "Sakura Mountain Pass",
      deskripsi: "Jalan berliku di lereng bukit bunga sakura.",
      hargaBukaKunci: 300,
      warnaTema: Color(0xFFF687B3),
      gradientJalan: [Color(0xFF4A5568), Color(0xFF2D3748)],
      kesukaran: 4,
    ),
    LocationLevel(
      id: 5,
      nama: "Final Rush: Matsuri Festival",
      deskripsi: "Kesesakan luar biasa ketika hari perayaan!",
      hargaBukaKunci: 600,
      warnaTema: Color(0xFFFFD700),
      gradientJalan: [Color(0xFF1A202C), Color(0xFF000000)],
      kesukaran: 5,
    ),
  ];

  static const List<CarColorOption> carPaints = [
    CarColorOption(
        id: "waguri_pink",
        nama: "Waguri Pink",
        warna: Color(0xFFFF5E8A),
        harga: 0),
    CarColorOption(
        id: "kaoruko_purple",
        nama: "Kaoruko Purple",
        warna: Color(0xFFA855F7),
        harga: 100),
    CarColorOption(
        id: "chidori_blue",
        nama: "Chidori Blue",
        warna: Color(0xFF3B82F6),
        harga: 200),
    CarColorOption(
        id: "midnight_black",
        nama: "Midnight Edition",
        warna: Color(0xFF1E293B),
        harga: 350),
    CarColorOption(
        id: "golden_delivery",
        nama: "Golden Anniversary",
        warna: Color(0xFFF59E0B),
        harga: 750),
  ];
}

// =============================================================================
// SKRIN MENU UTAMA
// =============================================================================

class MenuScreen extends StatelessWidget {
  final int totalCoins;
  final VoidCallback onMula;
  final VoidCallback onPilihLokasi;
  final VoidCallback onPilihKereta;
  final VoidCallback onCaraMain;

  const MenuScreen({
    super.key,
    required this.totalCoins,
    required this.onMula,
    required this.onPilihLokasi,
    required this.onPilihKereta,
    required this.onCaraMain,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF334155)],
          ),
        ),
        child: Stack(
          children: [
            // Background Elements (Sakura Petals Placeholder)
            ...List.generate(15, (i) {
              final random = math.Random(i);
              return Positioned(
                top: random.nextDouble() * 400,
                left: random.nextDouble() * 800,
                child: Opacity(
                  opacity: 0.2,
                  child: Icon(Icons.local_florist,
                      color: const Color(0xFFFFB7C5),
                      size: random.nextDouble() * 30 + 10),
                ),
              );
            }),

            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    "KUIH DELIVERY",
                    style: TextStyle(
                      fontSize: 60,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 8,
                      shadows: [
                        Shadow(
                            color: Color(0xFFFF5E8A),
                            blurRadius: 20,
                            offset: Offset(0, 4))
                      ],
                    ),
                  ),
                  const Text(
                    "KAORUKO RUN • 香る花は凛と咲く",
                    style: TextStyle(
                        fontSize: 18,
                        color: Color(0xFFFFB7C5),
                        letterSpacing: 4,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 50),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _menuButton(context, "MULA BERAKSI",
                          Icons.play_arrow_rounded, onMula,
                          isPrimary: true),
                      const SizedBox(width: 20),
                      _menuButton(
                          context, "LOKASI", Icons.map_rounded, onPilihLokasi),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _menuButton(context, "KERETA",
                          Icons.directions_car_rounded, onPilihKereta),
                      const SizedBox(width: 20),
                      _menuButton(context, "TUTORIAL",
                          Icons.help_outline_rounded, onCaraMain),
                    ],
                  ),
                ],
              ),
            ),

            Positioned(
              top: 30,
              right: 40,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.black26,
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: const Color(0xFFFFD700), width: 2),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.monetization_on, color: Color(0xFFFFD700)),
                    const SizedBox(width: 10),
                    Text(
                      "$totalCoins",
                      style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.white),
                    ),
                  ],
                ),
              ),
            ),

            Positioned(
              bottom: 20,
              left: 20,
              child: IconButton(
                icon: const Icon(Icons.close, color: Colors.white54),
                onPressed: () => Navigator.pop(context),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _menuButton(
      BuildContext context, String label, IconData icon, VoidCallback onTap,
      {bool isPrimary = false}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 220,
        padding: const EdgeInsets.symmetric(vertical: 15),
        decoration: BoxDecoration(
          color: isPrimary
              ? const Color(0xFFFF5E8A)
              : Colors.white.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(15),
          boxShadow: isPrimary
              ? [
                  BoxShadow(
                      color: const Color(0xFFFF5E8A).withValues(alpha: 0.5),
                      blurRadius: 15)
                ]
              : null,
          border: Border.all(
              color: isPrimary ? Colors.transparent : Colors.white24),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white),
            const SizedBox(width: 10),
            Text(label,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16)),
          ],
        ),
      ),
    );
  }
}

// =============================================================================
// SKRIN PILIH LOKASI
// =============================================================================

class LocationSelectScreen extends StatelessWidget {
  final LocationLevel selectedLevel;
  final Set<int> unlockedLevels;
  final int totalCoins;
  final Function(LocationLevel) onSelect;
  final Function(LocationLevel) onUnlock;
  final VoidCallback onBack;

  const LocationSelectScreen({
    super.key,
    required this.selectedLevel,
    required this.unlockedLevels,
    required this.totalCoins,
    required this.onSelect,
    required this.onUnlock,
    required this.onBack,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("PILIH LOKASI PENGHANTARAN"),
        leading:
            IconButton(icon: const Icon(Icons.arrow_back), onPressed: onBack),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
        scrollDirection: Axis.horizontal,
        itemCount: GameDatabase.levels.length,
        itemBuilder: (context, index) {
          final level = GameDatabase.levels[index];
          final isUnlocked = unlockedLevels.contains(level.id);
          final isSelected = selectedLevel.id == level.id;

          return GestureDetector(
            onTap: () => isUnlocked ? onSelect(level) : null,
            child: Container(
              width: 300,
              margin: const EdgeInsets.only(right: 30),
              decoration: BoxDecoration(
                color: isSelected
                    ? level.warnaTema.withValues(alpha: 0.2)
                    : Colors.white.withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(25),
                border: Border.all(
                  color: isSelected ? level.warnaTema : Colors.white12,
                  width: isSelected ? 4 : 1,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 180,
                    decoration: BoxDecoration(
                      color: level.warnaTema.withValues(alpha: 0.3),
                      borderRadius:
                          const BorderRadius.vertical(top: Radius.circular(20)),
                    ),
                    child: Center(
                      child: Icon(Icons.landscape,
                          size: 80, color: level.warnaTema),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("LEVEL ${level.id}",
                            style: TextStyle(
                                color: level.warnaTema,
                                fontWeight: FontWeight.bold)),
                        const SizedBox(height: 5),
                        Text(level.nama,
                            style: const TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: Colors.white)),
                        const SizedBox(height: 10),
                        Text(level.deskripsi,
                            style: const TextStyle(color: Colors.white70)),
                        const Spacer(),
                        if (isUnlocked)
                          const Text("TERBUKA",
                              style: TextStyle(
                                  color: Colors.greenAccent,
                                  fontWeight: FontWeight.bold))
                        else
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFFF5E8A)),
                            onPressed: totalCoins >= level.hargaBukaKunci
                                ? () => onUnlock(level)
                                : null,
                            child: Text("BUKA: ${level.hargaBukaKunci} COINS"),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// =============================================================================
// SKRIN PILIH KERETA
// =============================================================================

class CarSelectScreen extends StatelessWidget {
  final CarColorOption selectedCar;
  final Set<String> unlockedCars;
  final int totalCoins;
  final Function(CarColorOption) onSelect;
  final Function(CarColorOption) onUnlock;
  final VoidCallback onBack;

  const CarSelectScreen({
    super.key,
    required this.selectedCar,
    required this.unlockedCars,
    required this.totalCoins,
    required this.onSelect,
    required this.onUnlock,
    required this.onBack,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("GARAGE: PILIH KERETA"),
        leading:
            IconButton(icon: const Icon(Icons.arrow_back), onPressed: onBack),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Center(
        child: Column(
          children: [
            const SizedBox(height: 20),
            // Car Preview Area
            Container(
              height: 200,
              width: 400,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(30),
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // Simple Car Body Shape
                  Container(
                    width: 250,
                    height: 80,
                    decoration: BoxDecoration(
                      color: selectedCar.warna,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                            color: selectedCar.warna.withValues(alpha: 0.5),
                            blurRadius: 30)
                      ],
                    ),
                  ),
                  // Wheels
                  Positioned(
                      left: 100,
                      bottom: 50,
                      child: Container(
                          width: 40,
                          height: 40,
                          decoration: const BoxDecoration(
                              color: Colors.black, shape: BoxShape.circle))),
                  Positioned(
                      right: 100,
                      bottom: 50,
                      child: Container(
                          width: 40,
                          height: 40,
                          decoration: const BoxDecoration(
                              color: Colors.black, shape: BoxShape.circle))),
                ],
              ),
            ),
            const SizedBox(height: 40),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 100),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 5,
                  mainAxisSpacing: 20,
                  crossAxisSpacing: 20,
                  childAspectRatio: 0.8,
                ),
                itemCount: GameDatabase.carPaints.length,
                itemBuilder: (context, index) {
                  final car = GameDatabase.carPaints[index];
                  final isUnlocked = unlockedCars.contains(car.id);
                  final isSelected = selectedCar.id == car.id;

                  return GestureDetector(
                    onTap: () => isUnlocked ? onSelect(car) : null,
                    child: Container(
                      decoration: BoxDecoration(
                        color: isSelected ? Colors.white12 : Colors.black26,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                            color: isSelected
                                ? const Color(0xFFFF5E8A)
                                : Colors.white10,
                            width: 2),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                              width: 50,
                              height: 50,
                              decoration: BoxDecoration(
                                  color: car.warna, shape: BoxShape.circle)),
                          const SizedBox(height: 10),
                          Text(car.nama,
                              style:
                                  const TextStyle(fontWeight: FontWeight.bold)),
                          const SizedBox(height: 5),
                          if (isUnlocked)
                            const Icon(Icons.check_circle,
                                color: Colors.greenAccent)
                          else
                            Text("${car.harga} Coins",
                                style:
                                    const TextStyle(color: Color(0xFFFFD700))),
                          if (!isUnlocked)
                            TextButton(
                              onPressed: totalCoins >= car.harga
                                  ? () => onUnlock(car)
                                  : null,
                              child: const Text("BELI",
                                  style: TextStyle(color: Color(0xFFFF5E8A))),
                            ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// =============================================================================
// SKRIN TUTORIAL
// =============================================================================

class TutorialScreen extends StatelessWidget {
  final VoidCallback onBack;

  const TutorialScreen({super.key, required this.onBack});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: Center(
        child: Container(
          width: 600,
          padding: const EdgeInsets.all(40),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.05),
            borderRadius: BorderRadius.circular(30),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text("CARA BERMAIN",
                  style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFFFF5E8A))),
              const SizedBox(height: 30),
              _tutorialRow(Icons.swipe_left_rounded,
                  "Gunakan JOYSTICK untuk menggerakkan kereta ke kiri dan kanan."),
              _tutorialRow(Icons.fast_forward_rounded,
                  "Elak KENDERAAN LAIN di jalan raya untuk kekalkan kelajuan."),
              _tutorialRow(Icons.monetization_on,
                  "Kumpul SYILING Emas untuk membeli kereta dan lokasi baharu."),
              _tutorialRow(Icons.star_rounded,
                  "Hantar KUIH sebelum MASA TAMAT untuk dapat 3 Bintang!"),
              const SizedBox(height: 40),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFF5E8A),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                ),
                onPressed: onBack,
                child: const Text("FAHAM!",
                    style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _tutorialRow(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
                color: const Color(0xFFFF5E8A).withValues(alpha: 0.2),
                shape: BoxShape.circle),
            child: Icon(icon, color: const Color(0xFFFF5E8A)),
          ),
          const SizedBox(width: 20),
          Expanded(
              child: Text(text,
                  style: const TextStyle(fontSize: 16, color: Colors.white70))),
        ],
      ),
    );
  }
}

// =============================================================================
// ENGINE PERMAINAN (GAME SCREEN)
// =============================================================================

class GameScreen extends StatefulWidget {
  final LocationLevel level;
  final CarColorOption carColor;
  final Function(int stars, int coins, int score) onVictory;
  final VoidCallback onNextLevel;
  final VoidCallback onKembaliMenu;

  const GameScreen({
    super.key,
    required this.level,
    required this.carColor,
    required this.onVictory,
    required this.onNextLevel,
    required this.onKembaliMenu,
  });

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with TickerProviderStateMixin {
  late AnimationController _gameTicker;
  Duration? _lastFrameElapsed;
  final math.Random _random = math.Random();
  Timer? _messageTimer;

  // Game States
  double playerX = 0; // -1.0 to 1.0
  double speed = 0;
  double distance = 0;
  int coinsCollected = 0;
  int packagesDelivered = 0;
  int lives = 3;
  int combo = 0;
  int _spawnCount = 0;
  double timeRemaining = 75.0;
  bool isGameOver = false;
  bool isPaused = false;
  bool isVictory = false;
  String message = "";

  // Road Objects
  List<GameObject> objects = [];
  double spawnTimer = 0;

  // Input
  double horizontalInput = 0;

  @override
  void initState() {
    super.initState();
    _gameTicker =
        AnimationController(vsync: this, duration: const Duration(seconds: 1))
          ..repeat();
    _gameTicker.addListener(_update);

    // Initial Spawn
    _spawnInitialObjects();
  }

  void _spawnInitialObjects() {
    const types = [
      ObjectType.parcel,
      ObjectType.coin,
      ObjectType.obstacle,
      ObjectType.parcel,
      ObjectType.coin,
      ObjectType.parcel,
    ];
    for (int i = 0; i < types.length; i++) {
      objects.add(GameObject(
        z: 180.0 + (i * 145),
        lane: (_random.nextInt(3) - 1).toDouble(),
        type: types[i],
      ));
    }
  }

  @override
  void dispose() {
    _messageTimer?.cancel();
    _gameTicker.dispose();
    super.dispose();
  }

  @override
  void didUpdateWidget(covariant GameScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.level.id != widget.level.id) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _restartRun();
      });
    }
  }

  void _update() {
    if (isGameOver || isPaused || isVictory) {
      _lastFrameElapsed = null;
      return;
    }

    final elapsedSinceStart = _gameTicker.lastElapsedDuration;
    if (elapsedSinceStart == null) return;
    final previous = _lastFrameElapsed;
    _lastFrameElapsed = elapsedSinceStart;
    if (previous == null) return;
    final frameScale = ((elapsedSinceStart - previous).inMicroseconds / 16667)
        .clamp(0.0, 3.0)
        .toDouble();
    final elapsed = frameScale / 60.0;

    setState(() {
      timeRemaining -= elapsed;
      if (timeRemaining <= 0) {
        timeRemaining = 0;
        _finishRun(packagesDelivered >= 3);
        return;
      }

      playerX = (playerX + horizontalInput * 0.055 * frameScale)
          .clamp(-1.0, 1.0)
          .toDouble();
      speed = math.min(speed + 0.075 * frameScale, 10.0);
      distance += speed * frameScale;

      spawnTimer += speed * frameScale;
      if (spawnTimer > 150) {
        spawnTimer -= 150;
        _spawnCount++;
        final type = _spawnCount % 3 == 0
            ? ObjectType.parcel
            : (_random.nextInt(10) > 6 ? ObjectType.coin : ObjectType.obstacle);
        objects.add(GameObject(
          z: 1000,
          lane: (_random.nextInt(3) - 1).toDouble(),
          type: type,
        ));
      }

      for (int i = objects.length - 1; i >= 0; i--) {
        objects[i].z -= speed * frameScale;

        if (objects[i].z < 34 && objects[i].z > -12) {
          if ((objects[i].lane - playerX).abs() < 0.38) {
            switch (objects[i].type) {
              case ObjectType.obstacle:
                _hitObstacle();
                objects.removeAt(i);
                if (lives <= 0) {
                  _finishRun(false);
                  return;
                }
              case ObjectType.coin:
                _collectCoin();
                objects.removeAt(i);
              case ObjectType.parcel:
                _collectParcel();
                objects.removeAt(i);
            }
            if (packagesDelivered >= 3) {
              _finishRun(true);
              return;
            }
          }
        }

        if (i < objects.length && objects[i].z < -50) {
          objects.removeAt(i);
        }
      }
    });
  }

  void _hitObstacle() {
    HapticFeedback.heavyImpact();
    lives--;
    combo = 0;
    speed = 1.8;
    message = "AWAS! ${lives == 0 ? 'PENGHANTARAN GAGAL' : 'NYAWA -1'}";
    _clearMessageAfter(const Duration(milliseconds: 900));
  }

  void _collectCoin() {
    HapticFeedback.lightImpact();
    coinsCollected += 3 + math.min(combo, 4);
    combo++;
    message = "+${3 + math.min(combo - 1, 4)} SYILING";
    _clearMessageAfter(const Duration(milliseconds: 650));
  }

  void _collectParcel() {
    HapticFeedback.mediumImpact();
    packagesDelivered++;
    coinsCollected += 12;
    combo++;
    message = "PAKET $packagesDelivered/3 DIHANTAR";
    _clearMessageAfter(const Duration(milliseconds: 850));
  }

  void _clearMessageAfter(Duration delay) {
    _messageTimer?.cancel();
    _messageTimer = Timer(delay, () {
      if (mounted && !isVictory && !isGameOver) setState(() => message = "");
    });
  }

  void _finishRun(bool success) {
    if (isVictory || isGameOver) return;
    isVictory = success;
    isGameOver = !success;
    final stars = success
        ? (lives == 3 && coinsCollected >= 45
            ? 3
            : lives >= 2
                ? 2
                : 1)
        : 0;
    if (success) widget.onVictory(stars, coinsCollected, distance.toInt());

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1E293B),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text(
          success ? "PENGHANTARAN BERJAYA!" : "PENGHANTARAN GAGAL",
          textAlign: TextAlign.center,
          style: TextStyle(
            color: success ? const Color(0xFFFF9EBC) : Colors.orangeAccent,
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (success)
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                    3,
                    (i) => Icon(
                        i < stars
                            ? Icons.star_rounded
                            : Icons.star_outline_rounded,
                        color: const Color(0xFFFFD700),
                        size: 42)),
              )
            else
              const Icon(Icons.delivery_dining_rounded,
                  color: Colors.orangeAccent, size: 48),
            const SizedBox(height: 20),
            Text("Paket dihantar: $packagesDelivered/3",
                style: const TextStyle(color: Colors.white)),
            Text("Jarak: ${distance.toInt()} m  ·  Syiling: $coinsCollected",
                style: const TextStyle(color: Colors.white70)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: widget.onKembaliMenu,
            child: const Text("MENU", style: TextStyle(color: Colors.white70)),
          ),
          if (success && widget.level.id < GameDatabase.levels.length)
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFF5E8A)),
              onPressed: () {
                Navigator.pop(context);
                widget.onNextLevel();
              },
              child: const Text("LEVEL SETERUSNYA"),
            )
          else
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFF5E8A)),
              onPressed: () {
                Navigator.pop(context);
                _restartRun();
              },
              child: const Text("CUBA LAGI"),
            ),
        ],
      ),
    );
  }

  void _restartRun() {
    setState(() {
      playerX = 0;
      speed = 0;
      distance = 0;
      coinsCollected = 0;
      packagesDelivered = 0;
      lives = 3;
      combo = 0;
      timeRemaining = 75;
      isGameOver = false;
      isVictory = false;
      isPaused = false;
      message = "";
      spawnTimer = 0;
      _spawnCount = 0;
      objects.clear();
      _lastFrameElapsed = null;
      _spawnInitialObjects();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // 3D Perspective Road
          CustomPaint(
            size: Size.infinite,
            painter: RoadPainter(
              playerX: playerX,
              distance: distance,
              objects: objects,
              level: widget.level,
              carColor: widget.carColor,
              isImpact: lives < 3 && message.startsWith('AWAS'),
            ),
          ),

          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: _hudPanel([
                          _hudItem(Icons.timer_outlined,
                              "${timeRemaining.ceil()}s", Colors.white),
                          _hudItem(Icons.inventory_2_outlined,
                              "$packagesDelivered/3", const Color(0xFFFFD166)),
                          _hudItem(Icons.monetization_on_outlined,
                              "$coinsCollected", const Color(0xFFFFD166)),
                          _hudItem(
                              Icons.speed_rounded,
                              "${(speed * 20).toInt()}",
                              const Color(0xFF9BE7FF)),
                        ]),
                      ),
                      const SizedBox(width: 10),
                      _hudPanel([
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: List.generate(
                            3,
                            (index) => Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 2),
                              child: Icon(
                                Icons.favorite_rounded,
                                size: 18,
                                color: index < lives
                                    ? const Color(0xFFFF718B)
                                    : Colors.white24,
                              ),
                            ),
                          ),
                        ),
                      ]),
                      const SizedBox(width: 8),
                      IconButton.filledTonal(
                        tooltip: 'Jeda permainan',
                        style: IconButton.styleFrom(
                          backgroundColor: Colors.black.withValues(alpha: 0.38),
                          foregroundColor: Colors.white,
                        ),
                        icon: Icon(isPaused
                            ? Icons.play_arrow_rounded
                            : Icons.pause_rounded),
                        onPressed: _togglePause,
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: _hudPanel([
                      const Icon(Icons.delivery_dining_rounded,
                          size: 17, color: Color(0xFFFFD166)),
                      const SizedBox(width: 7),
                      Text(
                        'HANTAR 3 PAKET  ·  ${widget.level.nama.toUpperCase()}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.w800),
                      ),
                    ]),
                  ),
                ],
              ),
            ),
          ),

          // Flash Messages
          if (message.isNotEmpty)
            Center(
              child: Text(
                message,
                style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    shadows: [Shadow(blurRadius: 12, color: Colors.black)]),
              ),
            ),

          // Controls
          Positioned(
            bottom: 40,
            left: 40,
            child: _joystick(),
          ),
        ],
      ),
    );
  }

  Widget _hudPanel(List<Widget> children) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.46),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withValues(alpha: 0.14)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: children),
    );
  }

  Widget _hudItem(IconData icon, String val, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 7),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 6),
          Text(val,
              style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 14)),
        ],
      ),
    );
  }

  Widget _joystick() {
    return GestureDetector(
      onPanUpdate: (details) {
        setState(() {
          horizontalInput = (details.localPosition.dx - 58) / 58;
          horizontalInput = horizontalInput.clamp(-1.0, 1.0);
        });
      },
      onPanEnd: (_) => setState(() => horizontalInput = 0),
      child: Container(
        width: 116,
        height: 116,
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: 0.25),
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white38, width: 2),
        ),
        child: Center(
          child: Transform.translate(
            offset: Offset(horizontalInput * 40, 0),
            child: Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: const Color(0xFFFF5E8A),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                      color: const Color(0xFFFF5E8A).withValues(alpha: 0.5),
                      blurRadius: 10)
                ],
              ),
              child: const Icon(Icons.swap_horiz_rounded, color: Colors.white),
            ),
          ),
        ),
      ),
    );
  }

  void _togglePause() {
    setState(() {
      isPaused = !isPaused;
      _lastFrameElapsed = null;
    });
    if (isPaused) {
      showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AlertDialog(
          backgroundColor: const Color(0xFF1E293B),
          title: const Text('PERMAINAN DIJEDA',
              style: TextStyle(color: Colors.white)),
          content: Text(
            'Paket $packagesDelivered/3  ·  Syiling $coinsCollected',
            style: const TextStyle(color: Colors.white70),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext);
                setState(() {
                  isPaused = false;
                  _lastFrameElapsed = null;
                });
              },
              child: const Text('SAMBUNG'),
            ),
            TextButton(
                onPressed: widget.onKembaliMenu, child: const Text('MENU')),
          ],
        ),
      );
    }
  }
}

// =============================================================================
// PAINTERS (VISUALS)
// =============================================================================

enum ObjectType { obstacle, coin, parcel }

class GameObject {
  double z;
  double lane;
  ObjectType type;

  GameObject({required this.z, required this.lane, required this.type});
}

class RoadPainter extends CustomPainter {
  final double playerX;
  final double distance;
  final List<GameObject> objects;
  final LocationLevel level;
  final CarColorOption carColor;
  final bool isImpact;

  RoadPainter({
    required this.playerX,
    required this.distance,
    required this.objects,
    required this.level,
    required this.carColor,
    required this.isImpact,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final w = size.width;
    final h = size.height;
    final horizon = h * 0.38;
    final center = w / 2;
    final bottomRoadHalf = w * 0.57;
    double roadHalfAt(double depth) => w * (0.075 + depth * 0.495);
    double yAt(double depth) => horizon + (h - horizon) * depth;

    canvas.save();
    canvas.clipRect(Offset.zero & size);
    canvas.drawRect(
      Offset.zero & Size(w, horizon + 1),
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            level.warnaTema.withValues(alpha: 0.92),
            const Color(0xFF34445E)
          ],
        ).createShader(Rect.fromLTWH(0, 0, w, horizon)),
    );

    final sunColor =
        level.id == 3 ? const Color(0xFFE8D8FF) : const Color(0xFFFFE3A3);
    canvas.drawCircle(Offset(w * 0.79, horizon * 0.4), math.min(w, h) * 0.035,
        Paint()..color = sunColor.withValues(alpha: 0.9));
    _drawHill(canvas, w, horizon, 0.81, const Color(0xFF3C5C68));
    _drawHill(canvas, w, horizon, 0.89, const Color(0xFF294956));

    // Compact skyline gives the vanishing point a clear sense of distance.
    for (var i = 0; i < 15; i++) {
      final buildingW = w * (0.018 + (i % 3) * 0.006);
      final buildingH = horizon * (0.12 + ((i * 17) % 9) * 0.018);
      final x = w * i / 14 - buildingW / 2;
      final baseY = horizon * 0.94;
      canvas.drawRect(
        Rect.fromLTWH(x, baseY - buildingH, buildingW, buildingH),
        Paint()..color = const Color(0xFF263C50).withValues(alpha: 0.65),
      );
      if (buildingW > 12) {
        for (var row = 0; row < 3; row++) {
          canvas.drawRect(
            Rect.fromLTWH(x + buildingW * 0.22, baseY - buildingH + row * 7 + 5,
                buildingW * 0.16, 3),
            Paint()..color = sunColor.withValues(alpha: 0.48),
          );
          canvas.drawRect(
            Rect.fromLTWH(x + buildingW * 0.62, baseY - buildingH + row * 7 + 5,
                buildingW * 0.16, 3),
            Paint()..color = sunColor.withValues(alpha: 0.34),
          );
        }
      }
    }

    canvas.drawRect(
      Rect.fromLTRB(0, horizon, w, h),
      Paint()
        ..shader = const LinearGradient(
          colors: [Color(0xFF547C65), Color(0xFF142A35)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ).createShader(Rect.fromLTWH(0, horizon, w, h - horizon)),
    );

    final road = Path()
      ..moveTo(center - roadHalfAt(0), horizon)
      ..lineTo(center + roadHalfAt(0), horizon)
      ..lineTo(center + bottomRoadHalf, h)
      ..lineTo(center - bottomRoadHalf, h)
      ..close();
    canvas.drawPath(
      road,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: level.gradientJalan,
        ).createShader(Rect.fromLTWH(
            center - bottomRoadHalf, horizon, bottomRoadHalf * 2, h - horizon)),
    );

    // Shoulder and edge lines frame the playable road.
    for (final side in [-1.0, 1.0]) {
      final path = Path()
        ..moveTo(center + side * roadHalfAt(0), horizon)
        ..lineTo(center + side * (roadHalfAt(0) + w * 0.012), horizon)
        ..lineTo(center + side * (bottomRoadHalf + w * 0.035), h)
        ..lineTo(center + side * bottomRoadHalf, h)
        ..close();
      canvas.drawPath(path,
          Paint()..color = const Color(0xFFFFD27A).withValues(alpha: 0.8));
      canvas.drawLine(
        Offset(center + side * roadHalfAt(0), horizon),
        Offset(center + side * bottomRoadHalf, h),
        Paint()
          ..color = Colors.white.withValues(alpha: 0.55)
          ..strokeWidth = 1.5,
      );
    }

    // Three lanes with perspective-scaled moving dash marks.
    final dashOffset = (distance / 285) % 0.22;
    for (final laneDivider in [-1 / 3, 1 / 3]) {
      for (var i = 0; i < 7; i++) {
        final depth = ((i * 0.19 + dashOffset) % 1).toDouble();
        final y = yAt(depth);
        final roadHalf = roadHalfAt(depth);
        final dashH = 2 + depth * h * 0.035;
        final dashW = 1 + depth * 3.2;
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromCenter(
                center: Offset(center + laneDivider * roadHalf * 2, y),
                width: dashW,
                height: dashH),
            const Radius.circular(2),
          ),
          Paint()..color = Colors.white.withValues(alpha: 0.42 + depth * 0.28),
        );
      }
    }

    _drawRoadside(canvas, w, horizon, center, roadHalfAt, yAt, bottomRoadHalf);

    final sortedObjects = [...objects]..sort((a, b) => b.z.compareTo(a.z));
    for (final object in sortedObjects) {
      final depth = (1 - object.z / 1000).clamp(0.0, 1.0).toDouble();
      if (depth <= 0) continue;
      final x = center + object.lane * roadHalfAt(depth) * 1.72;
      final y = yAt(depth);
      final objectScale = 0.18 + depth * 0.82;
      switch (object.type) {
        case ObjectType.coin:
          _drawCoin(canvas, Offset(x, y - 14 * objectScale), objectScale);
        case ObjectType.parcel:
          _drawParcel(canvas, Offset(x, y - 15 * objectScale), objectScale);
        case ObjectType.obstacle:
          _drawCone(canvas, Offset(x, y), objectScale);
      }
    }

    final carWidth = math.min(w * 0.2, 178.0);
    final carX = center + playerX * (bottomRoadHalf * 0.67);
    final carY = h * 0.84;
    _drawCar(canvas, Offset(carX, carY), carWidth, carColor.warna);
    if (isImpact) {
      canvas.drawRect(
        Rect.fromLTWH(5, 5, w - 10, h - 10),
        Paint()
          ..color = const Color(0xFFFF465E).withValues(alpha: 0.62)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 8,
      );
    }
    canvas.restore();
  }

  void _drawHill(
      Canvas canvas, double width, double horizon, double base, Color color) {
    final path = Path()
      ..moveTo(0, horizon * base)
      ..quadraticBezierTo(
          width * 0.2, horizon * (base - 0.17), width * 0.4, horizon * base)
      ..quadraticBezierTo(
          width * 0.72, horizon * (base - 0.2), width, horizon * (base - 0.02))
      ..lineTo(width, horizon)
      ..lineTo(0, horizon)
      ..close();
    canvas.drawPath(path, Paint()..color = color);
  }

  void _drawRoadside(
    Canvas canvas,
    double width,
    double horizon,
    double center,
    double Function(double) roadHalfAt,
    double Function(double) yAt,
    double bottomRoadHalf,
  ) {
    final offset = (distance / 800) % 1;
    for (var i = 0; i < 9; i++) {
      final depth = ((i / 9 + offset) % 1).toDouble();
      final y = yAt(depth);
      final scale = 0.25 + depth * 0.95;
      for (final side in [-1.0, 1.0]) {
        final x = center + side * (roadHalfAt(depth) + width * 0.06 * scale);
        final trunkH = 17 * scale;
        final trunkW = 3 * scale;
        canvas.drawRect(
          Rect.fromLTWH(x - trunkW / 2, y - trunkH, trunkW, trunkH),
          Paint()..color = const Color(0xFF624A41),
        );
        canvas.drawCircle(
          Offset(x, y - trunkH),
          9 * scale,
          Paint()
            ..color = level.id == 3
                ? const Color(0xFF9B85C9)
                : const Color(0xFFF49AB9),
        );
        canvas.drawCircle(
          Offset(x - 4 * scale, y - trunkH - 3 * scale),
          5 * scale,
          Paint()..color = const Color(0xFFFFD2DF).withValues(alpha: 0.8),
        );
      }
    }
    canvas.drawRect(
      Rect.fromLTWH(0, horizon, math.max(0, center - bottomRoadHalf), 3),
      Paint()..color = Colors.white.withValues(alpha: 0.06),
    );
  }

  void _drawCoin(Canvas canvas, Offset center, double scale) {
    final radius = 13 * scale;
    canvas.drawOval(
      Rect.fromCenter(
          center: center.translate(2 * scale, 4 * scale),
          width: radius * 2.4,
          height: radius * 0.75),
      Paint()..color = Colors.black.withValues(alpha: 0.28),
    );
    canvas.drawCircle(center, radius, Paint()..color = const Color(0xFFFFB72B));
    canvas.drawCircle(
      center,
      radius * 0.72,
      Paint()
        ..color = const Color(0xFFFFE59A)
        ..style = PaintingStyle.stroke
        ..strokeWidth = math.max(1, 2 * scale),
    );
    canvas.drawCircle(center.translate(-radius * 0.28, -radius * 0.3),
        radius * 0.15, Paint()..color = Colors.white70);
  }

  void _drawParcel(Canvas canvas, Offset center, double scale) {
    final width = 25 * scale;
    final height = 21 * scale;
    final depth = 8 * scale;
    final front = Path()
      ..moveTo(center.dx - width / 2, center.dy - height / 2)
      ..lineTo(center.dx + width / 2, center.dy - height / 2)
      ..lineTo(center.dx + width / 2, center.dy + height / 2)
      ..lineTo(center.dx - width / 2, center.dy + height / 2)
      ..close();
    canvas.drawOval(
        Rect.fromCenter(
            center: center.translate(0, height / 2 + 5 * scale),
            width: width * 1.5,
            height: 7 * scale),
        Paint()..color = Colors.black38);
    canvas.drawPath(front, Paint()..color = const Color(0xFFD89A5B));
    final top = Path()
      ..moveTo(center.dx - width / 2, center.dy - height / 2)
      ..lineTo(
          center.dx - width / 2 + depth, center.dy - height / 2 - depth * 0.65)
      ..lineTo(
          center.dx + width / 2 + depth, center.dy - height / 2 - depth * 0.65)
      ..lineTo(center.dx + width / 2, center.dy - height / 2)
      ..close();
    canvas.drawPath(top, Paint()..color = const Color(0xFFFFD08A));
    final side = Path()
      ..moveTo(center.dx + width / 2, center.dy - height / 2)
      ..lineTo(
          center.dx + width / 2 + depth, center.dy - height / 2 - depth * 0.65)
      ..lineTo(
          center.dx + width / 2 + depth, center.dy + height / 2 - depth * 0.25)
      ..lineTo(center.dx + width / 2, center.dy + height / 2)
      ..close();
    canvas.drawPath(side, Paint()..color = const Color(0xFFAF7041));
    canvas.drawRect(
        Rect.fromCenter(center: center, width: 4 * scale, height: height),
        Paint()..color = const Color(0xFFB93C67));
    canvas.drawRect(
        Rect.fromLTWH(
            center.dx - width / 2, center.dy - 2 * scale, width, 4 * scale),
        Paint()..color = const Color(0xFFB93C67));
  }

  void _drawCone(Canvas canvas, Offset center, double scale) {
    final width = 25 * scale;
    final height = 30 * scale;
    canvas.drawOval(
        Rect.fromCenter(
            center: center.translate(0, 3 * scale),
            width: width * 1.5,
            height: 7 * scale),
        Paint()..color = Colors.black38);
    final path = Path()
      ..moveTo(center.dx, center.dy - height)
      ..lineTo(center.dx + width / 2, center.dy + height / 2)
      ..lineTo(center.dx - width / 2, center.dy + height / 2)
      ..close();
    canvas.drawPath(path, Paint()..color = const Color(0xFFFF754F));
    canvas.drawLine(
      Offset(center.dx - width * 0.3, center.dy + height * 0.05),
      Offset(center.dx + width * 0.3, center.dy + height * 0.05),
      Paint()
        ..color = Colors.white
        ..strokeWidth = math.max(1, 4 * scale),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
          Rect.fromCenter(
              center: center.translate(0, height * 0.48),
              width: width * 1.4,
              height: 5 * scale),
          Radius.circular(2 * scale)),
      Paint()..color = const Color(0xFFFFC857),
    );
  }

  void _drawCar(Canvas canvas, Offset center, double width, Color color) {
    final height = width * 0.72;
    final bodyColor = color;
    canvas.drawOval(
      Rect.fromCenter(
          center: center.translate(0, height * 0.39),
          width: width * 1.16,
          height: height * 0.22),
      Paint()
        ..color = Colors.black.withValues(alpha: 0.52)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
    );
    for (final side in [-1.0, 1.0]) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
              center: center.translate(side * width * 0.47, height * 0.06),
              width: width * 0.15,
              height: height * 0.46),
          const Radius.circular(5),
        ),
        Paint()..color = const Color(0xFF10151D),
      );
    }
    final body = Path()
      ..moveTo(center.dx - width * 0.37, center.dy - height * 0.27)
      ..quadraticBezierTo(center.dx - width * 0.28, center.dy - height * 0.52,
          center.dx, center.dy - height * 0.49)
      ..quadraticBezierTo(center.dx + width * 0.28, center.dy - height * 0.52,
          center.dx + width * 0.37, center.dy - height * 0.27)
      ..lineTo(center.dx + width * 0.5, center.dy + height * 0.32)
      ..quadraticBezierTo(center.dx, center.dy + height * 0.47,
          center.dx - width * 0.5, center.dy + height * 0.32)
      ..close();
    canvas.drawShadow(body, Colors.black, 7, true);
    canvas.drawPath(body, Paint()..color = bodyColor);
    canvas.drawPath(
      body,
      Paint()
        ..color = Colors.white.withValues(alpha: 0.45)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4,
    );
    final rearGlass = Path()
      ..moveTo(center.dx - width * 0.25, center.dy - height * 0.24)
      ..lineTo(center.dx - width * 0.16, center.dy - height * 0.43)
      ..quadraticBezierTo(center.dx, center.dy - height * 0.48,
          center.dx + width * 0.16, center.dy - height * 0.43)
      ..lineTo(center.dx + width * 0.25, center.dy - height * 0.24)
      ..close();
    canvas.drawPath(rearGlass,
        Paint()..color = const Color(0xFFB9E7F7).withValues(alpha: 0.82));
    canvas.drawLine(
      Offset(center.dx - width * 0.29, center.dy - height * 0.18),
      Offset(center.dx + width * 0.29, center.dy - height * 0.18),
      Paint()
        ..color = bodyColor.withValues(alpha: 0.68)
        ..strokeWidth = height * 0.06,
    );
    for (final side in [-1.0, 1.0]) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
              center: center.translate(
                  side * width * 0.34, center.dy < 0 ? 0 : height * 0.19),
              width: width * 0.1,
              height: height * 0.12),
          const Radius.circular(3),
        ),
        Paint()..color = const Color(0xFFFF5368),
      );
    }
    canvas.drawRRect(
      RRect.fromRectAndRadius(
          Rect.fromCenter(
              center: center.translate(0, height * 0.3),
              width: width * 0.22,
              height: height * 0.1),
          const Radius.circular(3)),
      Paint()..color = const Color(0xFFEAF2F5),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
          Rect.fromCenter(
              center: center.translate(0, height * 0.3),
              width: width * 0.09,
              height: height * 0.055),
          const Radius.circular(2)),
      Paint()..color = const Color(0xFFB93C67),
    );
  }

  @override
  bool shouldRepaint(RoadPainter oldDelegate) =>
      oldDelegate.playerX != playerX ||
      oldDelegate.distance != distance ||
      oldDelegate.objects != objects ||
      oldDelegate.level != level ||
      oldDelegate.carColor != carColor ||
      oldDelegate.isImpact != isImpact;
}
