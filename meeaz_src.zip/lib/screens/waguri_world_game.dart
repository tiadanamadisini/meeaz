// waguri_world_game.dart
//
// Mini-game "Waguri World" — grid-based block world dalam Flutter.
// Boleh letak file ni terus dalam folder lib/ app sedia ada awak
// (contoh sama tempat file Snake game awak), lepas tu panggil
// `WaguriWorldGame()` sebagai satu Widget/screen macam biasa.
//
// Dependency yang perlu ditambah dalam pubspec.yaml:
//   dependencies:
//     shared_preferences: ^2.2.2
//
// Konsep:
// - Grid dunia (default 10x10). Setiap cell ada jenis: kosong, rumput,
//   sumber (pokok/batu), block yang pemain letak, atau rumah Waguri.
// - Pemain (avatar 🧑) bergerak guna butang arah (senang untuk semua platform).
// - Tap cell sumber (🌳/⛏️) yang bersebelahan dengan pemain untuk kumpul koin.
// - Tap rumah Waguri (🏠) untuk beri hadiah (guna koin) -> naikkan mood.
// - Mood Waguri berkurang sikit demi sikit ikut masa (Timer).
// - Progress (koin + mood) disimpan guna shared_preferences.

import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum CellType { empty, grass, resource, block, waguriHome }

class WaguriWorldGame extends StatefulWidget {
  const WaguriWorldGame({super.key});

  @override
  State<WaguriWorldGame> createState() => _WaguriWorldGameState();
}

class _WaguriWorldGameState extends State<WaguriWorldGame> {
  static const int gridSize = 10;
  static const int giftCost = 10; // koin diperlukan untuk beri hadiah

  late List<List<CellType>> grid;
  late int playerRow;
  late int playerCol;

  int coins = 0;
  double mood = 70; // 0 - 100

  Timer? moodTimer;
  String waguriDialog = "Hai! Selamat datang balik~";

  final Random _rand = Random();

  @override
  void initState() {
    super.initState();
    _generateWorld();
    _loadProgress();
    // Mood berkurang perlahan setiap 30 saat kalau tiada interaksi.
    moodTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      setState(() {
        mood = (mood - 2).clamp(0, 100);
        _updateDialogByMood();
      });
      _saveProgress();
    });
  }

  @override
  void dispose() {
    moodTimer?.cancel();
    super.dispose();
  }

  // ---------------- World generation ----------------

  void _generateWorld() {
    grid = List.generate(
      gridSize,
          (_) => List.generate(gridSize, (_) => CellType.grass),
    );

    // Letak beberapa sumber (pokok/batu) secara rawak.
    int resourceCount = (gridSize * gridSize * 0.15).round();
    for (int i = 0; i < resourceCount; i++) {
      int r = _rand.nextInt(gridSize);
      int c = _rand.nextInt(gridSize);
      grid[r][c] = CellType.resource;
    }

    // Rumah Waguri diletak di tengah dunia.
    int homeRow = gridSize ~/ 2;
    int homeCol = gridSize ~/ 2;
    grid[homeRow][homeCol] = CellType.waguriHome;

    // Pemain bermula di sudut kiri atas.
    playerRow = 0;
    playerCol = 0;
  }

  // ---------------- Persistence ----------------

  Future<void> _loadProgress() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      coins = prefs.getInt('waguri_coins') ?? coins;
      mood = prefs.getDouble('waguri_mood') ?? mood;
      _updateDialogByMood();
    });
  }

  Future<void> _saveProgress() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('waguri_coins', coins);
    await prefs.setDouble('waguri_mood', mood);
  }

  // ---------------- Player actions ----------------

  bool _isAdjacent(int r, int c) {
    final dr = (r - playerRow).abs();
    final dc = (c - playerCol).abs();
    return (dr + dc) == 1 || (dr == 0 && dc == 0);
  }

  void _movePlayer(int dr, int dc) {
    final newRow = (playerRow + dr).clamp(0, gridSize - 1);
    final newCol = (playerCol + dc).clamp(0, gridSize - 1);
    setState(() {
      playerRow = newRow;
      playerCol = newCol;
    });
  }

  void _onCellTap(int r, int c) {
    if (!_isAdjacent(r, c)) {
      _showSnack("Terlalu jauh — dekatkan diri dulu.");
      return;
    }

    final cell = grid[r][c];

    if (cell == CellType.resource) {
      setState(() {
        grid[r][c] = CellType.grass;
        coins += 5;
        waguriDialog = "Wah, awak jumpa sumber! +5 koin.";
      });
      _saveProgress();
    } else if (cell == CellType.waguriHome) {
      _giveGift();
    } else if (cell == CellType.grass) {
      // Tap grass kosong untuk letak block (contoh bina rumah/pagar).
      setState(() {
        grid[r][c] = CellType.block;
      });
    } else if (cell == CellType.block) {
      // Tap block sedia ada untuk buang balik.
      setState(() {
        grid[r][c] = CellType.grass;
      });
    }
  }

  void _giveGift() {
    if (coins < giftCost) {
      setState(() {
        waguriDialog = "Awak perlukan $giftCost koin untuk bagi hadiah.";
      });
      return;
    }
    setState(() {
      coins -= giftCost;
      mood = (mood + 15).clamp(0, 100);
      _updateDialogByMood(justGifted: true);
    });
    _saveProgress();
  }

  void _updateDialogByMood({bool justGifted = false}) {
    if (justGifted) {
      waguriDialog = "Terima kasih sayang! Saya gembira sangat 💕";
      return;
    }
    if (mood >= 80) {
      waguriDialog = "Saya sangat gembira hari ini!";
    } else if (mood >= 50) {
      waguriDialog = "Hai, apa khabar? Jom berbual.";
    } else if (mood >= 20) {
      waguriDialog = "Saya rindu awak... lama tak jenguk.";
    } else {
      waguriDialog = "Saya sedih sangat sekarang :(";
    }
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), duration: const Duration(seconds: 1)),
    );
  }

  // ---------------- UI ----------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFDF6EC),
      appBar: AppBar(
        title: const Text('Waguri World'),
        backgroundColor: const Color(0xFFA9C6E8),
      ),
      body: SafeArea(
        child: Column(
          children: [
            _buildStatusBar(),
            _buildDialogBubble(),
            Expanded(child: _buildGrid()),
            _buildControls(),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusBar() {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          const Icon(Icons.monetization_on, color: Colors.amber),
          const SizedBox(width: 4),
          Text('$coins', style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(width: 20),
          const Text('Mood: '),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: mood / 100,
                minHeight: 10,
                backgroundColor: Colors.grey.shade300,
                valueColor: AlwaysStoppedAnimation(
                  mood >= 50 ? Colors.pinkAccent : Colors.redAccent,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Text('${mood.round()}%'),
        ],
      ),
    );
  }

  Widget _buildDialogBubble() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFFEAF2FB),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFA9C6E8)),
      ),
      child: Row(
        children: [
          const Text('🧕', style: TextStyle(fontSize: 22)),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              waguriDialog,
              style: const TextStyle(fontStyle: FontStyle.italic),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGrid() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final cellSize = constraints.maxWidth / gridSize;
        return Center(
          child: SizedBox(
            width: cellSize * gridSize,
            height: cellSize * gridSize,
            child: GridView.builder(
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: gridSize,
              ),
              itemCount: gridSize * gridSize,
              itemBuilder: (context, index) {
                final r = index ~/ gridSize;
                final c = index % gridSize;
                final isPlayer = (r == playerRow && c == playerCol);
                return GestureDetector(
                  onTap: () => _onCellTap(r, c),
                  child: Container(
                    margin: const EdgeInsets.all(1),
                    decoration: BoxDecoration(
                      color: _cellColor(grid[r][c]),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Center(
                      child: Text(
                        isPlayer ? '🧑' : _cellEmoji(grid[r][c]),
                        style: const TextStyle(fontSize: 16),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }

  Color _cellColor(CellType type) {
    switch (type) {
      case CellType.grass:
        return const Color(0xFFCFE8CB);
      case CellType.resource:
        return const Color(0xFFE9DDB8);
      case CellType.block:
        return const Color(0xFFB98B5E);
      case CellType.waguriHome:
        return const Color(0xFFF7C9D6);
      case CellType.empty:
        return Colors.white;
    }
  }

  String _cellEmoji(CellType type) {
    switch (type) {
      case CellType.resource:
        return '🌳';
      case CellType.waguriHome:
        return '🏠';
      case CellType.block:
        return '🧱';
      default:
        return '';
    }
  }

  Widget _buildControls() {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_upward),
            onPressed: () => _movePlayer(-1, 0),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () => _movePlayer(0, -1),
              ),
              const SizedBox(width: 40),
              IconButton(
                icon: const Icon(Icons.arrow_forward),
                onPressed: () => _movePlayer(0, 1),
              ),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.arrow_downward),
            onPressed: () => _movePlayer(1, 0),
          ),
        ],
      ),
    );
  }
}