import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/message.dart';

class KaorukoProfileScreen extends StatefulWidget {
  final List<Message> messages;

  const KaorukoProfileScreen({super.key, required this.messages});

  @override
  State<KaorukoProfileScreen> createState() => _KaorukoProfileScreenState();
}

class _KaorukoProfileScreenState extends State<KaorukoProfileScreen> {
  static const Color rose = Color(0xFFC97C6D);
  String _bahasa = 'Bahasa Melayu';

  @override
  void initState() {
    super.initState();
    _muatBahasa();
  }

  Future<void> _muatBahasa() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() =>
          _bahasa = prefs.getString('bahasa_aplikasi') ?? 'Bahasa Melayu');
    }
  }

  @override
  Widget build(BuildContext context) {
    final textColor = Theme.of(context).colorScheme.onSurface;
    final english = _bahasa == 'English';
    final received = widget.messages
        .where((message) => message.sender == Sender.user)
        .toList();
    final sent = widget.messages
        .where((message) => message.sender == Sender.kaoruko)
        .toList();
    final media = widget.messages.where((message) => message.isImage).toList();

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(english ? 'Kaoruko Profile' : 'Profil Kaoruko'),
        backgroundColor: Colors.transparent,
        foregroundColor: textColor,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
        children: [
          const CircleAvatar(
            radius: 58,
            backgroundImage: AssetImage('assets/pfp.jpg'),
          ),
          const SizedBox(height: 14),
          Text(
            'Waguri Kaoruko',
            textAlign: TextAlign.center,
            style: TextStyle(
                color: textColor, fontSize: 24, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 6),
          Text(
            english ? 'Your close friend🌸' : 'Kawan sembang awakutter🌸',
            textAlign: TextAlign.center,
            style: TextStyle(
                color: textColor.withValues(alpha: 0.62), fontSize: 14),
          ),
          const SizedBox(height: 20),
          _buildBio(context, english),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(
                  child: _stat(context, english ? 'Received' : 'Diterima',
                      received.length)),
              const SizedBox(width: 10),
              Expanded(
                  child:
                      _stat(context, english ? 'Sent' : 'Diberi', sent.length)),
              const SizedBox(width: 10),
              Expanded(child: _stat(context, 'Media', media.length)),
            ],
          ),
          const SizedBox(height: 24),
          Text(
            english ? 'All media' : 'Semua media',
            style: TextStyle(
                color: textColor, fontSize: 18, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 10),
          if (media.isEmpty)
            Text(
              english ? 'No media in chat yet.' : 'Belum ada media dalam chat.',
              style: TextStyle(color: textColor.withValues(alpha: 0.58)),
            )
          else
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
              ),
              itemCount: media.length,
              itemBuilder: (context, index) =>
                  _mediaTile(context, media[index]),
            ),
        ],
      ),
    );
  }

  Widget _buildBio(BuildContext context, bool english) {
    final textColor = Theme.of(context).colorScheme.onSurface;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: rose.withValues(alpha: 0.18)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(english ? 'Bio' : 'Bio',
              style: TextStyle(color: rose, fontWeight: FontWeight.w700)),
          SizedBox(height: 8),
          Text(
            english
                ? 'A hardworking and caring scholarship student who loves reading, drama, cake, and patiently helping you study.'
                : 'Pelajar scholarship yang rajin, lembut dan prihatin. Suka membaca, drama, cake dan membantu awak belajar dengan sabar.',
            style: TextStyle(color: textColor, height: 1.4),
          ),
        ],
      ),
    );
  }

  Widget _stat(BuildContext context, String label, int value) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 13),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: [
          Text('$value',
              style: TextStyle(
                  color: Theme.of(context).colorScheme.onSurface,
                  fontSize: 20,
                  fontWeight: FontWeight.w700)),
          const SizedBox(height: 3),
          Text(label,
              style: TextStyle(
                  color: Theme.of(context)
                      .colorScheme
                      .onSurface
                      .withValues(alpha: 0.6),
                  fontSize: 11)),
        ],
      ),
    );
  }

  Widget _mediaTile(BuildContext context, Message message) {
    return GestureDetector(
      onTap: () => showDialog<void>(
        context: context,
        builder: (_) => Dialog(
          child: InteractiveViewer(
            child: Image.memory(base64Decode(message.imageBase64!)),
          ),
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child:
            Image.memory(base64Decode(message.imageBase64!), fit: BoxFit.cover),
      ),
    );
  }
}
