import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'cake.dart';
import 'drive.dart';
import 'rider.dart';
import 'waguri_world_game.dart';
import 'waguri_isekai_game.dart';

class GamesHubScreen extends StatelessWidget {
  const GamesHubScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Game Hub Kaoruko'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Jom main dengan Kaoruko! 🌸',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            const Text('Pilih permainan untuk uji minda awak.'),
            const SizedBox(height: 30),
            Expanded(
              child: ListView(
                children: [
                  _gameCard(
                    context,
                    title: 'Kediaman Isekai Waguri 🏡',
                    subtitle: 'Dunia 3D open world, grafik PC! Bertani, memancing & teroka.',
                    icon: Icons.cottage_rounded,
                    color: const Color(0xFF7C3AED),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WaguriIsekaiGame())),
                  ),
                  const SizedBox(height: 16),
                  _gameCard(
                    context,
                    title: 'Susun Kata (Scramble)',
                    subtitle: 'Susun huruf menjadi perkataan pastri!',
                    icon: Icons.abc_rounded,
                    color: const Color(0xFF8EACCD),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WordScrambleGame())),
                  ),
                  const SizedBox(height: 16),
                  _gameCard(
                    context,
                    title: 'Cabaran Matematik',
                    subtitle: 'Kira cepat sebelum masa tamat!',
                    icon: Icons.calculate_rounded,
                    color: const Color(0xFFD7B1D7),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MathChallengeGame())),
                  ),
                  const SizedBox(height: 16),
                  _gameCard(
                    context,
                    title: 'Padanan Memori',
                    subtitle: 'Cari pasangan gambar yang sama.',
                    icon: Icons.extension_rounded,
                    color: const Color(0xFFA0C49D),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MemoryMatchGame())),
                  ),
                  const SizedBox(height: 16),
                  _gameCard(
                    context,
                    title: 'Buat Kek!(Make Cake!)',
                    subtitle: 'Membuatkan kek kegemaran Kaoruko.',
                    icon: Icons.cake_rounded,
                    color: const Color(0xFFC97C6D),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CakeSimulatorApp())),
                  ),
                  const SizedBox(height: 16),
                  _gameCard(
                    context,
                    title: 'Menghantar pesanan(Driver delivery)',
                    subtitle: 'Menghantar Pesanan ke lokasi ditetapkan',
                    icon: Icons.insert_drive_file,
                    color: const Color(0xFFC97C6D),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const KuihDeliveryApp())),
                  ),
                  const SizedBox(height: 16),
                  _gameCard(
                    context,
                    title: 'The Great Cake Race (Rider)',
                    subtitle: 'Lumba motor hantar kek dengan Waguri!',
                    icon: Icons.motorcycle_rounded,
                    color: const Color(0xFF64B5F6),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DeliveryRiderApp())),
                  ),
                  const SizedBox(height: 16),
                  _gameCard(
                    context,
                    title: 'Waguri World Game',
                    subtitle: 'Teroka dunia Waguri dalam 3D!',
                    icon: Icons.public_rounded,
                    color: const Color(0xFFF06292),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WaguriWorldGame())),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _gameCard(BuildContext context, {required String title, required String subtitle, required IconData icon, required Color color, required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.15),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withValues(alpha: 0.3), width: 2),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: color, shape: BoxShape.circle),
              child: Icon(icon, color: Colors.white, size: 30),
            ),
            const SizedBox(width: 20),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  Text(subtitle, style: const TextStyle(fontSize: 13, color: Colors.black54)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded),
          ],
        ),
      ),
    );
  }
}

// ==================== GAME 1: WORD SCRAMBLE ====================
class WordScrambleGame extends StatefulWidget {
  const WordScrambleGame({super.key});

  @override
  State<WordScrambleGame> createState() => _WordScrambleGameState();
}

class _WordScrambleGameState extends State<WordScrambleGame> {
  final List<String> _words = ['CHOCOLATE', 'PASTRY', 'KIKYO', 'WAGURI', 'STRAWBERRY', 'PUDDING', 'ACADEMY', 'FRIENDSHIP'];
  late String _currentWord;
  late String _scrambledWord;
  final TextEditingController _controller = TextEditingController();
  int _score = 0;

  @override
  void initState() {
    super.initState();
    _nextRound();
  }

  void _nextRound() {
    _currentWord = _words[Random().nextInt(_words.length)];
    List<String> chars = _currentWord.split('')..shuffle();
    _scrambledWord = chars.join('');
    _controller.clear();
    setState(() {});
  }

  void _check() {
    if (_controller.text.toUpperCase() == _currentWord) {
      _score += 10;
      _nextRound();
      _showWaguriFeedback(
        'Wah, hebatnya awak! ✨ Memang tepat tekaan tu. Teruskan usaha eh?',
        isHappy: true,
      );
    } else {
      _showWaguriFeedback(
        'E-eh... sikit lagi tu. Jangan sedih tau, saya tahu awak dah cuba yang terbaik! 🌸',
        isHappy: false,
      );
    }
  }

  void _showWaguriFeedback(String msg, {required bool isHappy}) {
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.white,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        margin: const EdgeInsets.all(20),
        content: Row(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundImage: const AssetImage('assets/pfp.jpg'),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                msg,
                style: const TextStyle(color: Color(0xFF5D4037), fontSize: 13, fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Susun Kata')),
      body: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Skor: $_score', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 40),
            const Text('Susun huruf ini:', style: TextStyle(fontSize: 16)),
            const SizedBox(height: 10),
            Text(_scrambledWord, style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w900, letterSpacing: 8, color: Color(0xFFC97C6D))),
            const SizedBox(height: 40),
            TextField(
              controller: _controller,
              textAlign: TextAlign.center,
              decoration: const InputDecoration(hintText: 'Jawapan awak...', border: OutlineInputBorder()),
              onSubmitted: (_) => _check(),
            ),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: _check, child: const Text('Semak Jawapan')),
          ],
        ),
      ),
    );
  }
}

// ==================== GAME 2: MATH CHALLENGE ====================
class MathChallengeGame extends StatefulWidget {
  const MathChallengeGame({super.key});

  @override
  State<MathChallengeGame> createState() => _MathChallengeGameState();
}

class _MathChallengeGameState extends State<MathChallengeGame> {
  int _a = 0;
  int _b = 0;
  int _ans = 0;
  final TextEditingController _controller = TextEditingController();
  int _score = 0;
  int _timeLeft = 10;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _generate();
  }

  void _generate() {
    _a = Random().nextInt(20) + 1;
    _b = Random().nextInt(20) + 1;
    _ans = _a + _b;
    _timeLeft = 10;
    _startTimer();
    setState(() {});
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_timeLeft > 0) {
        setState(() => _timeLeft--);
      } else {
        _timer?.cancel();
        _gameOver();
      }
    });
  }

  void _check() {
    if (int.tryParse(_controller.text) == _ans) {
      _score++;
      _controller.clear();
      _generate();
    }
  }

  void _gameOver() {
    String msg;
    if (_score >= 20) {
      msg = "Wah, bijaknya awak mengira! 🌟 Saya kagum sangat dengan kelajuan awak tadi.";
    } else if (_score >= 10) {
      msg = "Bagusnya! Awak memang fokus tadi. Nak cuba lagi satu pusingan?";
    } else {
      msg = "Tak apa... mengira ni memang kena tenang. Rehat kejap, lepas ni kita cuba balik eh? Saya teman.";
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            const CircleAvatar(radius: 20, backgroundImage: AssetImage('assets/pfp.jpg')),
            const SizedBox(width: 12),
            const Text('Masa Tamat!', style: TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Skor akhir awak: $_score', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            Text(msg, textAlign: TextAlign.center, style: const TextStyle(fontStyle: FontStyle.italic)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.pop(context);
            },
            child: const Text('KEMBALI KE HUB'),
          )
        ],
      ),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Math Challenge')),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('Skor: $_score', style: const TextStyle(fontSize: 24)),
          const SizedBox(height: 20),
          Text('Masa: $_timeLeft', style: TextStyle(fontSize: 30, color: _timeLeft < 4 ? Colors.red : Colors.black)),
          const SizedBox(height: 50),
          Text('$_a + $_b = ?', style: const TextStyle(fontSize: 48, fontWeight: FontWeight.bold)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 100, vertical: 20),
            child: TextField(
              controller: _controller,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              autofocus: true,
              onChanged: (v) => _check(),
            ),
          ),
        ],
      ),
    );
  }
}

// ==================== GAME 3: MEMORY MATCH ====================
class MemoryMatchGame extends StatefulWidget {
  const MemoryMatchGame({super.key});

  @override
  State<MemoryMatchGame> createState() => _MemoryMatchGameState();
}

class _MemoryMatchGameState extends State<MemoryMatchGame> {
  final List<String> _icons = ['🎂', '🍰', '🍪', '🍩', '🥐', '🧁', '🍦', '🍮'];
  late List<String> _cards;
  late List<bool> _cardFlips;
  int _firstIndex = -1;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _cards = [..._icons, ..._icons]..shuffle();
    _cardFlips = List.filled(16, false);
  }

  void _onTap(int index) {
    if (_busy || _cardFlips[index]) return;

    setState(() => _cardFlips[index] = true);

    if (_firstIndex == -1) {
      _firstIndex = index;
    } else {
      if (_cards[_firstIndex] == _cards[index]) {
        _firstIndex = -1;
        if (!_cardFlips.contains(false)) {
          _showVictoryDialog();
        }
      } else {
        _busy = true;
        Timer(const Duration(seconds: 1), () {
          setState(() {
            _cardFlips[_firstIndex] = false;
            _cardFlips[index] = false;
            _firstIndex = -1;
            _busy = false;
          });
        });
      }
    }
  }

  void _showVictoryDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            const CircleAvatar(radius: 20, backgroundImage: AssetImage('assets/pfp.jpg')),
            const SizedBox(width: 12),
            const Text('Syabas!', style: TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('🎂🍰🍩🍪', style: TextStyle(fontSize: 32)),
            SizedBox(height: 16),
            Text(
              'Ingatan awak memang kuat! Semua manisan dah dijumpai. Nanti kita makan kek sama-sama eh? Hehe.',
              textAlign: TextAlign.center,
              style: TextStyle(fontStyle: FontStyle.italic),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.pop(context);
            },
            child: const Text('KEMBALI KE HUB'),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Padanan Memori')),
      body: GridView.builder(
        padding: const EdgeInsets.all(20),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, crossAxisSpacing: 10, mainAxisSpacing: 10),
        itemCount: 16,
        itemBuilder: (ctx, idx) => GestureDetector(
          onTap: () => _onTap(idx),
          child: Container(
            decoration: BoxDecoration(color: _cardFlips[idx] ? Colors.white : const Color(0xFFC97C6D), borderRadius: BorderRadius.circular(10)),
            child: Center(child: Text(_cardFlips[idx] ? _cards[idx] : '?', style: const TextStyle(fontSize: 30, color: Colors.white))),
          ),
        ),
      ),
    );
  }
}