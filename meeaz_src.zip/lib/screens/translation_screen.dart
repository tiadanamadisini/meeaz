import 'dart:async';
import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/chat_service.dart';

/// Skrin Live Translate — bila dibuka, terus auto-buka kamera dan mula
/// detect + translate teks dalam frame secara live (setiap ~2.6 saat),
/// hasil terjemahan ditindih terus atas teks asal (macam Google Lens).
///
/// 3 mod:
/// - camera  : live preview + overlay terjemahan yang auto kemas kini
/// - captured: gambar statik (dari shutter ATAU dari fail/galeri) +
///             overlay terjemahan (sekali sahaja, bukan live)
/// - text    : mod translate teks-ke-teks biasa
class TranslationScreen extends StatefulWidget {
  const TranslationScreen({super.key});

  @override
  State<TranslationScreen> createState() => _TranslationScreenState();
}

enum _TMode { camera, gallery, text }

class _DetectedBlock {
  final Rect box;
  final String original;
  String translation;

  _DetectedBlock({
    required this.box,
    required this.original,
  }) : translation = '';
}

class _HasilDeteksi {
  final List<_DetectedBlock> blocks;
  final Size size;
  _HasilDeteksi({required this.blocks, required this.size});
}

class _TranslationScreenState extends State<TranslationScreen>
    with WidgetsBindingObserver {
  final _chatService = ChatService();
  final _recognizer = TextRecognizer(script: TextRecognitionScript.latin);
  final _picker = ImagePicker();
  final _sourceController = TextEditingController();

  // ---------------- Kamera & live translate ----------------
  List<CameraDescription> _cameras = [];
  CameraController? _cameraController;
  bool _cameraReady = false;
  String? _cameraError;

  Timer? _liveTimer;
  bool _isProcessingLive = false;
  List<_DetectedBlock> _liveBlocks = [];
  Size? _liveImageSize;

  // ---------------- Gambar statik (shutter / fail) ----------------
  File? _capturedImage;
  List<_DetectedBlock> _capturedBlocks = [];
  Size? _capturedImageSize;
  bool _capturedLoading = false;
  String? _capturedError;

  // ---------------- Mod teks-ke-teks ----------------
  String _textResult = '';
  bool _textLoading = false;

  _TMode _mode = _TMode.text;
  String _source = 'Auto detect';
  String _target = 'Bahasa Melayu';

  static const _languages = [
    'Auto detect',
    'Bahasa Melayu',
    'English',
    'Indonesian',
    'Arabic',
    'Chinese (Simplified)',
    'Chinese (Traditional)',
    'Japanese',
    'Korean',
    'Thai',
    'Vietnamese',
    'Tamil',
    'Hindi',
    'Bengali',
    'Urdu',
    'French',
    'Spanish',
    'Portuguese',
    'Italian',
    'German',
    'Dutch',
    'Russian',
    'Turkish',
    'Greek',
    'Polish',
    'Swedish',
    'Norwegian',
    'Danish',
    'Finnish',
    'Czech',
    'Romanian',
    'Ukrainian',
    'Hebrew',
    'Persian',
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _liveTimer?.cancel();
    _cameraController?.dispose();
    _recognizer.close();
    _sourceController.dispose();
    super.dispose();
  }

  // Pause/resume kamera ikut lifecycle app supaya tak crash bila app
  // pergi background / kembali ke foreground.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final controller = _cameraController;

    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused) {
      _liveTimer?.cancel();
      if (controller != null && controller.value.isInitialized) {
        controller.dispose();
      }
      if (mounted) {
        setState(() {
          _cameraController = null;
          _cameraReady = false;
        });
      }
    } else if (state == AppLifecycleState.resumed && _mode == _TMode.camera) {
      _initCamera();
    }
  }

  // ==================== KAMERA ====================

  Future<void> _initCamera() async {
    if (_cameraReady && _cameraController != null && _cameraController!.value.isInitialized) return;

    setState(() {
      _cameraError = null;
      _isProcessingLive = false;
      _cameraReady = false; // Reset state while initializing
    });

    try {
      final prefs = await SharedPreferences.getInstance();
      final ignore = prefs.getBool('perm_camera_ignore') ?? false;

      var status = await Permission.camera.status;
      if (status.isDenied && !ignore) {
        if (mounted) {
          bool donotshow = false;
          final result = await showDialog<bool>(
            context: context,
            barrierDismissible: false,
            builder: (ctx) => StatefulBuilder(
              builder: (context, setDialogState) => AlertDialog(
                title: const Text('Kebenaran Kamera'),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('Aplikasi memerlukan akses kamera untuk mengimbas dan menterjemah teks secara langsung.'),
                    const SizedBox(height: 12),
                    CheckboxListTile(
                      title: const Text('Jangan paparkan lagi', style: TextStyle(fontSize: 14)),
                      value: donotshow,
                      onChanged: (val) => setDialogState(() => donotshow = val ?? false),
                      controlAffinity: ListTileControlAffinity.leading,
                      contentPadding: EdgeInsets.zero,
                    ),
                  ],
                ),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
                  TextButton(
                    onPressed: () async {
                      if (donotshow) await prefs.setBool('perm_camera_ignore', true);
                      Navigator.pop(ctx, true);
                    },
                    child: const Text('Benarkan'),
                  ),
                ],
              ),
            ),
          );
          if (result == true) {
            status = await Permission.camera.request();
          } else {
            return;
          }
        }
      }

      if (!status.isGranted) {
        if (mounted) {
          setState(() => _cameraError = 'Kebenaran kamera diperlukan untuk mod ini.');
        }
        return;
      }

      _cameras = await availableCameras();
      if (_cameras.isEmpty) {
        if (mounted) {
          setState(
              () => _cameraError = 'Tiada kamera dikesan pada peranti ni.');
        }
        return;
      }

      final backCamera = _cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => _cameras.first,
      );

      final controller = CameraController(
        backCamera,
        ResolutionPreset.medium,
        enableAudio: false,
        imageFormatGroup: Platform.isAndroid ? ImageFormatGroup.yuv420 : ImageFormatGroup.bgra8888,
      );

      await controller.initialize();
      if (!mounted) {
        await controller.dispose();
        return;
      }

      setState(() {
        _cameraController = controller;
        _cameraReady = true;
      });
      _startLiveTimer();
    } catch (e) {
      debugPrint('Camera init error: $e');
      if (mounted) {
        setState(
            () => _cameraError = 'Tak dapat buka kamera. Sila benarkan akses '
                'kamera dalam tetapan peranti.\n(${e.toString()})');
      }
    }
  }

  void _startLiveTimer() {
    _liveTimer?.cancel();
    _liveTimer = Timer.periodic(const Duration(milliseconds: 2600), (_) {
      _liveCapture();
    });
  }

  // Snapshot senyap setiap beberapa saat → detect teks → translate →
  // update overlay. Ini bukan live-per-frame (elak isu format YUV/BGRA
  // raw stream yang berbeza ikut peranti), tapi cukup untuk rasa
  // "live" — overlay auto kemas kini tanpa pengguna tekan apa-apa.
  Future<void> _liveCapture() async {
    if (_mode != _TMode.camera || _capturedImage != null) return;
    if (_isProcessingLive) return;
    if (_target == 'Auto detect') return;
    final controller = _cameraController;
    if (controller == null || !controller.value.isInitialized) return;
    if (controller.value.isTakingPicture) return;

    _isProcessingLive = true;
    File? file;
    try {
      // TASK 8: Check initialization before capture
      if (_cameraController == null || !_cameraController!.value.isInitialized) return;

      final xfile = await controller.takePicture();
      file = File(xfile.path);

      // TASK 8: Null check on file
      if (!await file.exists()) return;

      final hasil = await _detectAndTranslateFile(file);
      if (mounted && _mode == _TMode.camera) {
        setState(() {
          _liveBlocks = hasil.blocks;
          _liveImageSize = hasil.size;
        });
      }
    } catch (e) {
      debugPrint('Live capture error: $e');
    } finally {
      _isProcessingLive = false;
      if (file != null && await file.exists()) {
        unawaited(file.delete().catchError((_) => file!));
      }
    }
  }

  // Shutter — freeze frame semasa, papar sebagai gambar statik dengan
  // overlay.
  Future<void> _tekanShutter() async {
    if (_target == 'Auto detect') {
      _tunjukMesej('Sila pilih bahasa sasaran dahulu.');
      return;
    }
    final controller = _cameraController;
    if (controller == null || !controller.value.isInitialized) return;
    if (controller.value.isTakingPicture || _capturedLoading) return;

    setState(() => _capturedLoading = true);
    try {
      final xfile = await controller.takePicture();
      final file = File(xfile.path);
      final hasil = await _detectAndTranslateFile(file);
      if (!mounted) return;
      setState(() {
        _capturedImage = file;
        _capturedBlocks = hasil.blocks;
        _capturedImageSize = hasil.size;
        _capturedError = null;
      });
    } catch (e) {
      if (mounted) _tunjukMesej('Gagal ambil/translate gambar: $e');
    } finally {
      if (mounted) setState(() => _capturedLoading = false);
    }
  }

  // ==================== FAIL / GALERI ====================

  Future<void> _pilihDariGaleri() async {
    if (_target == 'Auto detect') {
      _tunjukMesej('Sila pilih bahasa sasaran dahulu.');
      return;
    }

    // TASK 7: Runtime request for storage/photos
    final PermissionStatus status;
    if (Platform.isAndroid) {
      // For Android, try storage first, then photos for Android 13+
      final s = await Permission.storage.status;
      if (s.isGranted) {
        status = s;
      } else {
        status = await Permission.photos.status;
      }
    } else {
      status = await Permission.photos.status;
    }

    if (status.isDenied) {
      if (mounted) {
        final result = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Akses Galeri'),
            content: const Text('Aplikasi memerlukan akses galeri untuk memilih dan menterjemah gambar.'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
              TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Benarkan')),
            ],
          ),
        );
        if (result == true) {
          if (Platform.isAndroid) {
            await Permission.storage.request();
            await Permission.photos.request();
          } else {
            await Permission.photos.request();
          }
        } else {
          return;
        }
      }
    }

    final xfile = await _picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 90,
      maxWidth: 2200,
    );
    if (xfile == null) return;

    final file = File(xfile.path);
    setState(() {
      _capturedImage = file;
      _capturedBlocks = [];
      _capturedImageSize = null;
      _capturedError = null;
      _capturedLoading = true;
    });

    try {
      final hasil = await _detectAndTranslateFile(file);
      if (!mounted) return;
      setState(() {
        _capturedBlocks = hasil.blocks;
        _capturedImageSize = hasil.size;
      });
    } catch (e) {
      if (mounted) {
        setState(() =>
            _capturedError = e.toString().replaceFirst('Exception: ', ''));
      }
    } finally {
      if (mounted) setState(() => _capturedLoading = false);
    }
  }

  // ==================== OCR + TRANSLATE (kongsi) ====================

  Future<_HasilDeteksi> _detectAndTranslateFile(File file) async {
    try {
      if (!await file.exists() || await file.length() == 0) {
        return _HasilDeteksi(blocks: [], size: const Size(1, 1));
      }

      final inputImage = InputImage.fromFilePath(file.path);
      final recognized = await _recognizer.processImage(inputImage);

      final List<_DetectedBlock> detectedBlocks = [];
      for (var block in recognized.blocks) {
        if (block.text.trim().isNotEmpty) {
          detectedBlocks.add(_DetectedBlock(
            box: block.boundingBox,
            original: block.text.trim(),
          ));
        }
      }

      if (detectedBlocks.isNotEmpty) {
        try {
          final translations = await _chatService.translateTextBlocks(
            texts: detectedBlocks.map((b) => b.original).toList(),
            sourceLanguage: _source == 'Auto detect' ? 'any' : _source,
            targetLanguage: _target,
          );
          for (var i = 0; i < detectedBlocks.length; i++) {
            detectedBlocks[i].translation = i < translations.length ? translations[i] : detectedBlocks[i].original;
          }
        } catch (e) {
          debugPrint('Translation error: $e');
          for (var b in detectedBlocks) { b.translation = b.original; }
        }
      }

      final size = await _readImageSize(file);
      return _HasilDeteksi(blocks: detectedBlocks, size: size);
    } catch (e) {
      debugPrint('OCR Error: $e');
      return _HasilDeteksi(blocks: [], size: const Size(1, 1));
    }
  }

  Future<Size> _readImageSize(File file) async {
    final bytes = await file.readAsBytes();
    final image = await decodeImageFromList(bytes);
    return Size(image.width.toDouble(), image.height.toDouble());
  }

  // ==================== TEKS-KE-TEKS ====================

  Future<void> _translateTeks() async {
    final text = _sourceController.text.trim();
    if (text.isEmpty) return;
    if (_target == 'Auto detect') {
      _tunjukMesej('Sila pilih bahasa sasaran dahulu.');
      return;
    }

    setState(() => _textLoading = true);
    try {
      final result = await _chatService.translateText(
        text: text,
        sourceLanguage: _source,
        targetLanguage: _target,
      );
      if (mounted) setState(() => _textResult = result);
    } catch (e) {
      if (mounted) {
        setState(
            () => _textResult = e.toString().replaceFirst('Exception: ', ''));
      }
    } finally {
      if (mounted) setState(() => _textLoading = false);
    }
  }

  // ==================== NAVIGASI MOD ====================

  void _kembaliKeKamera() {
    setState(() {
      _liveBlocks = [];
      _liveImageSize = null;
    });
    _initCamera();
  }

  void _changeMode(_TMode newMode) {
    if (_mode == newMode) return;

    // Cleanup previous mode
    if (_mode == _TMode.camera) {
      _liveTimer?.cancel();
      _cameraController?.dispose();
    }

    setState(() {
      _mode = newMode;
      _cameraController = null;
      _cameraReady = false;
      _capturedImage = null;
      _capturedBlocks = [];
      _capturedImageSize = null;
      _capturedError = null;
      _textResult = '';
    });

    if (newMode == _TMode.camera) {
      _initCamera();
    }
  }

  void _swapLanguages() {
    if (_source == 'Auto detect') return;
    setState(() {
      final lamaSource = _source;
      _source = _target;
      _target = lamaSource;
    });
  }

  void _tunjukMesej(String mesej) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
          SnackBar(content: Text(mesej), duration: const Duration(seconds: 2)));
  }

  // ==================== UI ====================

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      backgroundColor: _mode == _TMode.text ? colors.surface : Colors.black,
      body: SafeArea(
        top: false,
        bottom: false,
        child: Column(
          children: [
            SafeArea(child: _buildTopBar()),
            Expanded(child: _buildBody()),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  Widget _buildBottomNav() {
    final colors = Theme.of(context).colorScheme;
    final isDark = _mode != _TMode.text;

    return Container(
      decoration: BoxDecoration(
        color: isDark ? Colors.black : colors.surface,
        border: Border(
          top: BorderSide(
            color: isDark ? Colors.white12 : colors.outlineVariant.withValues(alpha: 0.5),
            width: 0.5,
          ),
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _navItem(_TMode.text, Icons.text_fields_rounded, 'Teks'),
              _navItem(_TMode.camera, Icons.camera_alt_rounded, 'Kamera'),
              _navItem(_TMode.gallery, Icons.photo_library_rounded, 'Galeri'),
            ],
          ),
        ),
      ),
    );
  }

  Widget _navItem(_TMode mode, IconData icon, String label) {
    final active = _mode == mode;
    final colors = Theme.of(context).colorScheme;
    final isDark = _mode != _TMode.text;

    final activeColor = const Color(0xFFC97C6D); // Rose accent
    final inactiveColor = isDark ? Colors.white54 : colors.onSurface.withValues(alpha: 0.5);

    return GestureDetector(
      onTap: () => _changeMode(mode),
      behavior: HitTestBehavior.opaque,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: active ? activeColor : inactiveColor, size: 26),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: active ? activeColor : inactiveColor,
              fontSize: 12,
              fontWeight: active ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    switch (_mode) {
      case _TMode.camera:
        return _buildCameraView();
      case _TMode.gallery:
        return _buildGalleryView();
      case _TMode.text:
        return _buildTextView();
    }
  }

  // ---------------- Top bar (back + pilihan bahasa) ----------------

  Widget _buildTopBar() {
    final gelap = _mode != _TMode.text;
    return Container(
      padding: const EdgeInsets.fromLTRB(6, 4, 12, 10),
      decoration: gelap
          ? BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withValues(alpha: 0.55),
                  Colors.transparent
                ],
              ),
            )
          : null,
      child: Row(
        children: [
          Expanded(child: _languageBar(gelap)),
        ],
      ),
    );
  }

  Widget _languageBar(bool gelap) {
    final fg = gelap ? Colors.white : Theme.of(context).colorScheme.onSurface;
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Flexible(child: _langChip(_source, gelap, true)),
        IconButton(
          icon: Icon(Icons.swap_horiz_rounded,
              color: _source == 'Auto detect' ? fg.withValues(alpha: 0.3) : fg),
          onPressed: _source == 'Auto detect' ? null : _swapLanguages,
        ),
        Flexible(child: _langChip(_target, gelap, false)),
      ],
    );
  }

  Widget _langChip(String value, bool gelap, bool isSource) {
    return GestureDetector(
      onTap: () => _pilihBahasa(isSource),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: gelap
              ? Colors.white.withValues(alpha: 0.16)
              : Colors.black.withValues(alpha: 0.06),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Flexible(
              child: Text(
                value,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: gelap
                      ? Colors.white
                      : Theme.of(context).colorScheme.onSurface,
                  fontSize: 12.5,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            Icon(Icons.expand_more_rounded,
                size: 16, color: gelap ? Colors.white70 : Colors.black45),
          ],
        ),
      ),
    );
  }

  void _pilihBahasa(bool isSource) {
    final senarai = isSource
        ? _languages
        : _languages.where((l) => l != 'Auto detect').toList();
    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: SizedBox(
            height: MediaQuery.of(context).size.height * 0.6,
            child: ListView.builder(
              itemCount: senarai.length,
              itemBuilder: (context, index) {
                final lang = senarai[index];
                final terpilih = isSource ? lang == _source : lang == _target;
                return ListTile(
                  title: Text(lang),
                  trailing: terpilih ? const Icon(Icons.check_rounded) : null,
                  onTap: () {
                    setState(() {
                      if (isSource) {
                        _source = lang;
                      } else {
                        _target = lang;
                      }
                    });
                    Navigator.pop(ctx);
                  },
                );
              },
            ),
          ),
        );
      },
    );
  }

  // ---------------- Mod kamera (live) ----------------

  Widget _buildCameraView() {
    if (_cameraError != null) {
      return Container(
        color: Colors.black,
        alignment: Alignment.center,
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.no_photography_rounded,
                color: Colors.white54, size: 48),
            const SizedBox(height: 12),
            Text(_cameraError!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 16),
            FilledButton(
                onPressed: _initCamera, child: const Text('Cuba lagi')),
          ],
        ),
      );
    }

    if (!_cameraReady || _cameraController == null) {
      return const ColoredBox(
        color: Colors.black,
        child: Center(child: CircularProgressIndicator(color: Colors.white70)),
      );
    }

    return Stack(
      children: [
        Positioned.fill(
          child: _capturedImage != null && _capturedImageSize != null
              ? Center(
                  child: AspectRatio(
                    aspectRatio: _capturedImageSize!.width / _capturedImageSize!.height,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.file(_capturedImage!, fit: BoxFit.fill),
                        _buildOverlay(_capturedBlocks, _capturedImageSize!),
                      ],
                    ),
                  ),
                )
              : AspectRatio(
                  aspectRatio: _cameraController!.value.aspectRatio,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      CameraPreview(_cameraController!),
                      if (_liveImageSize != null)
                        _buildOverlay(_liveBlocks, _liveImageSize!),
                    ],
                  ),
                ),
        ),
        if (_capturedImage != null)
          Positioned(
            top: 20,
            left: 16,
            child: IconButton(
              icon: const Icon(Icons.close_rounded, color: Colors.white, size: 30),
              onPressed: _kembaliKeKamera,
            ),
          ),
        if (_isProcessingLive || _capturedLoading)
          Positioned(
            top: 20,
            right: 16,
            child: _chipIndicator('Menganalisis...'),
          ),
        if (_target == 'Auto detect')
          Positioned(
            bottom: 100,
            left: 16,
            right: 16,
            child: _chipIndicator(
                'Pilih bahasa sasaran untuk mula live translate',
                center: true),
          ),
        Positioned(
          bottom: 30,
          left: 0,
          right: 0,
          child: Center(child: _shutterButton()),
        ),
      ],
    );
  }

  Widget _chipIndicator(String text, {bool center = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.6),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        textAlign: center ? TextAlign.center : TextAlign.start,
        style: const TextStyle(color: Colors.white, fontSize: 12.5),
      ),
    );
  }

  Widget _buildOverlay(List<_DetectedBlock> blocks, Size imageSize) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final double widgetW = constraints.maxWidth;
        final double widgetH = constraints.maxHeight;

        // Scale based on the preview's aspect ratio vs image resolution
        // We use BoxFit.fill in the parent, so we scale directly.
        double scaleX = widgetW / imageSize.width;
        double scaleY = widgetH / imageSize.height;

        return Stack(
          children: blocks.map((block) {
            final box = block.box;

            // Map coordinates and add slight padding to ensure original text is covered
            final left = box.left * scaleX;
            final top = box.top * scaleY;
            final width = box.width * scaleX;
            final height = box.height * scaleY;

            return Positioned(
              left: left,
              top: top,
              width: width,
              height: height,
              child: Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  // Solid background to mask original text
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(2),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.3),
                      blurRadius: 2,
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  child: FittedBox(
                    fit: BoxFit.contain,
                    child: Text(
                      block.translation.isNotEmpty
                          ? block.translation
                          : block.original,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.w900,
                        fontSize: height * 0.8,
                        height: 1.0,
                      ),
                    ),
                  ),
                ),
              ),
            );
          }).toList(),
        );
      },
    );
  }


  Widget _shutterButton() {
    return GestureDetector(
      onTap: () async {
        if (_capturedLoading) return;

        // TASK 7: Runtime request with rationale
        final status = await Permission.camera.status;
        if (!mounted) return;

        if (status.isDenied) {
          final result = await showDialog<bool>(
            context: context,
            builder: (ctx) => AlertDialog(
              title: const Text('Kebenaran Kamera'),
              content: const Text('Aplikasi memerlukan akses kamera untuk mengimbas dan menterjemah teks secara langsung.'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
                TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Benarkan')),
              ],
            ),
          );
          if (result != true) return;
        }

        final requestStatus = await Permission.camera.request();
        if (requestStatus.isGranted) {
          _tekanShutter();
        } else {
          _tunjukMesej('Kebenaran kamera diperlukan untuk imbas teks.');
        }
      },
      child: Container(
        width: 68,
        height: 68,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white,
          border: Border.all(color: Colors.white54, width: 4),
        ),
        alignment: Alignment.center,
        child: _capturedLoading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(strokeWidth: 2.5))
            : const Icon(Icons.camera_alt_rounded, color: Colors.black87),
      ),
    );
  }

  Widget _buildGalleryView() {
    if (_capturedImage == null) {
      return Container(
        color: Colors.black,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.image_search_rounded, color: Colors.white54, size: 64),
              const SizedBox(height: 16),
              const Text('Tiada imej dipilih', style: TextStyle(color: Colors.white70)),
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: _pilihDariGaleri,
                icon: const Icon(Icons.photo_library_rounded),
                label: const Text('Pilih dari Galeri'),
                style: FilledButton.styleFrom(backgroundColor: const Color(0xFFC97C6D)),
              ),
            ],
          ),
        ),
      );
    }

    return Stack(
      fit: StackFit.expand,
      children: [
        Positioned.fill(
          child: _capturedImageSize != null
              ? Center(
                  child: AspectRatio(
                    aspectRatio:
                        _capturedImageSize!.width / _capturedImageSize!.height,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.file(_capturedImage!, fit: BoxFit.fill),
                        _buildOverlay(_capturedBlocks, _capturedImageSize!),
                      ],
                    ),
                  ),
                )
              : Image.file(_capturedImage!, fit: BoxFit.contain),
        ),
        if (_capturedLoading)
          Container(
            color: Colors.black45,
            child: const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(color: Colors.white),
                  SizedBox(height: 10),
                  Text('Mengesan & menterjemah...',
                      style: TextStyle(color: Colors.white)),
                ],
              ),
            ),
          ),
        Positioned(
          bottom: 20,
          right: 20,
          child: FloatingActionButton(
            onPressed: _pilihDariGaleri,
            backgroundColor: const Color(0xFFC97C6D),
            child: const Icon(Icons.add_photo_alternate_rounded, color: Colors.white),
          ),
        ),
        if (_capturedError != null)
          Positioned(
            bottom: 100,
            left: 16,
            right: 16,
            child: _chipIndicator(_capturedError!, center: true),
          ),
      ],
    );
  }


  // ---------------- Mod teks-ke-teks ----------------

  Widget _buildTextView() {
    final colors = Theme.of(context).colorScheme;
    return Container(
      color: colors.surface,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
        children: [
          // Kotak Input
          Container(
            decoration: BoxDecoration(
              color: colors.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: colors.outline.withValues(alpha: 0.1)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.03),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: TextField(
              controller: _sourceController,
              minLines: 6,
              maxLines: 12,
              style: TextStyle(color: colors.onSurface, fontSize: 16),
              decoration: InputDecoration(
                hintText: 'Tulis atau tampal teks di sini...',
                hintStyle: TextStyle(color: colors.onSurface.withValues(alpha: 0.3)),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.all(20),
              ),
            ),
          ),
          const SizedBox(height: 20),
          // Butang Terjemah
          SizedBox(
            width: double.infinity,
            height: 56,
            child: FilledButton.icon(
              onPressed: _textLoading ? null : _translateTeks,
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFFC97C6D), // Rose accent
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              icon: _textLoading
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.translate_rounded),
              label: Text(_textLoading ? 'Sedang menterjemah...' : 'Terjemah Sekarang',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            ),
          ),
          // Kotak Hasil
          if (_textResult.isNotEmpty) ...[
            const SizedBox(height: 32),
            Row(
              children: [
                Icon(Icons.auto_awesome_rounded, size: 18, color: colors.primary),
                const SizedBox(width: 8),
                Text('HASIL TERJEMAHAN',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: colors.primary,
                    letterSpacing: 1.2,
                  )),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: colors.primaryContainer.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: colors.primary.withValues(alpha: 0.1)),
              ),
              child: SelectableText(
                _textResult,
                style: TextStyle(
                  color: colors.onSurface,
                  fontSize: 16,
                  height: 1.5,
                ),
              ),
            ),
            const SizedBox(height: 12),
            // Butang Copy (Tambahan untuk kemudahan)
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: _textResult));
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Teks disalin ke papan klip.')),
                  );
                },
                icon: const Icon(Icons.copy_rounded, size: 18),
                label: const Text('Salin'),
                style: TextButton.styleFrom(foregroundColor: colors.primary),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
