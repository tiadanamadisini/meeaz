import 'package:intl/intl.dart';

/// MVP default currency is MYR only (spec section 27: no multi-currency yet).
final _currencyFormat = NumberFormat.currency(locale: 'en_MY', symbol: 'RM', decimalDigits: 2);

String formatMoney(double value) => _currencyFormat.format(value);

String formatSignedMoney(double value) {
  final sign = value >= 0 ? '+' : '-';
  return '$sign${_currencyFormat.format(value.abs())}';
}

final _monthFormat = DateFormat('MMMM yyyy');
String formatMonthYear(DateTime d) => _monthFormat.format(d);

final _dateFormat = DateFormat('d MMM yyyy');
String formatDate(DateTime d) => _dateFormat.format(d);
