import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ForexGraphBridge {
  static const _channel = MethodChannel('com.meeaz.app/forex_graph');

  static Future<void> open(BuildContext context) async {
    if (defaultTargetPlatform != TargetPlatform.android) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Graf Forex hanya tersedia di Android.')),
      );
      return;
    }

    try {
      await _channel.invokeMethod<void>('open');
    } on PlatformException {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Graf Forex tidak dapat dibuka.')),
      );
    } on MissingPluginException {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Graf Forex tidak tersedia pada binaan ini.')),
      );
    }
  }
}