import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../models/account.dart';
import '../models/goal.dart';
import '../models/money_transaction.dart';
import 'ai_service.dart';
import 'calculation_engine.dart';
import 'db_service.dart';

class AppState extends ChangeNotifier {
  final DbService _db = DbService.instance;
  final AiService aiService = AiService(); // set backendBaseUrl before shipping
  static const _uuid = Uuid();

  List<Account> accounts = [];
  List<MoneyTransaction> transactions = [];
  List<Goal> goals = [];
  bool isLoading = true;
  bool aiPermissionGranted = true;

  void setAiPermission(bool value) {
    aiPermissionGranted = value;
    notifyListeners();
  }

  Future<void> load() async {
    isLoading = true;
    notifyListeners();
    accounts = await _db.getAccounts();
    
    // Auto-create default account if none exists
    if (accounts.isEmpty) {
      await addAccount(
        name: 'Tabungan Waguri',
        type: AccountType.cash,
        balance: 0.0,
      );
    }
    
    transactions = await _db.getTransactions();
    goals = await _db.getGoals();
    isLoading = false;
    notifyListeners();
  }

  // ---------- Accounts ----------
  Future<void> addAccount({required String name, required AccountType type, required double balance}) async {
    final a = Account(id: _uuid.v4(), name: name, type: type, balance: balance);
    await _db.upsertAccount(a);
    accounts.add(a);
    notifyListeners();
  }

  Future<void> deleteAccount(String id) async {
    await _db.deleteAccount(id);
    accounts.removeWhere((a) => a.id == id);
    notifyListeners();
  }

  // ---------- Transactions ----------
  Future<void> addTransaction({
    required String accountId,
    required TxType type,
    required double amount,
    required String category,
    required DateTime date,
    String note = '',
  }) async {
    final t = MoneyTransaction(
      id: _uuid.v4(),
      accountId: accountId,
      type: type,
      amount: amount,
      category: category,
      date: date,
      note: note,
    );
    await _db.upsertTransaction(t);
    transactions.insert(0, t);
    _applyBalanceDelta(accountId, type == TxType.income ? amount : -amount);
    notifyListeners();
  }

  Future<void> updateTransaction(MoneyTransaction updated) async {
    final old = transactions.firstWhere((t) => t.id == updated.id);
    // revert old balance effect, apply new
    _applyBalanceDelta(old.accountId, old.type == TxType.income ? -old.amount : old.amount);
    _applyBalanceDelta(updated.accountId, updated.type == TxType.income ? updated.amount : -updated.amount);
    await _db.upsertTransaction(updated);
    final idx = transactions.indexWhere((t) => t.id == updated.id);
    transactions[idx] = updated;
    notifyListeners();
  }

  Future<void> deleteTransaction(String id) async {
    final t = transactions.firstWhere((tx) => tx.id == id);
    _applyBalanceDelta(t.accountId, t.type == TxType.income ? -t.amount : t.amount);
    await _db.deleteTransaction(id);
    transactions.removeWhere((tx) => tx.id == id);
    notifyListeners();
  }

  void _applyBalanceDelta(String accountId, double delta) {
    final idx = accounts.indexWhere((a) => a.id == accountId);
    if (idx == -1) return;
    accounts[idx].balance += delta;
    _db.upsertAccount(accounts[idx]);
  }

  // ---------- Goals ----------
  Future<void> addGoal({
    required String name,
    required double targetAmount,
    required double currentAmount,
    required DateTime targetDate,
  }) async {
    final g = Goal(
      id: _uuid.v4(),
      name: name,
      targetAmount: targetAmount,
      currentAmount: currentAmount,
      targetDate: targetDate,
      createdAt: DateTime.now(),
    );
    await _db.upsertGoal(g);
    goals.insert(0, g);
    notifyListeners();
  }

  Future<void> updateGoal(Goal g) async {
    await _db.upsertGoal(g);
    final idx = goals.indexWhere((x) => x.id == g.id);
    if (idx != -1) goals[idx] = g;
    notifyListeners();
  }

  Future<void> deleteGoal(String id) async {
    await _db.deleteGoal(id);
    goals.removeWhere((g) => g.id == id);
    notifyListeners();
  }

  // ---------- Computed snapshot for dashboard / AI ----------
  double get totalBalance => CalculationEngine.totalBalance(accounts);

  double monthlyIncome(DateTime month) => CalculationEngine.monthlyIncome(transactions, month);
  double monthlyExpenses(DateTime month) => CalculationEngine.monthlyExpenses(transactions, month);

  FinancialSnapshot buildSnapshot() {
    final now = DateTime.now();
    final income = monthlyIncome(now);
    final expenses = monthlyExpenses(now);
    final avg = CalculationEngine.averages(transactions, now: now);
    final categories = CalculationEngine.categoryTotals(transactions, now);
    return FinancialSnapshot(
      currentBalance: totalBalance,
      monthlyIncome: income,
      monthlyExpenses: expenses,
      averageMonthlySavings: avg.avgSavings,
      savingsRate: CalculationEngine.savingsRate(income - expenses, income),
      topCategories: categories,
      activeGoals: goals,
      daysOfData: avg.daysOfData,
    );
  }

  // ---------- Danger zone ----------
  Future<void> deleteAllData() async {
    await _db.deleteAllData();
    accounts = [];
    transactions = [];
    goals = [];
    notifyListeners();
  }

  Future<void> clearAiChat() => _db.clearAiConversation();
}
