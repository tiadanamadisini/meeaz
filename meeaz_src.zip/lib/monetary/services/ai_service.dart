import 'dart:convert';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/goal.dart';
import 'calculation_engine.dart';

/// Snapshot of the numbers the AI is allowed to see.
class FinancialSnapshot {
  final double currentBalance;
  final double monthlyIncome;
  final double monthlyExpenses;
  final double averageMonthlySavings;
  final double savingsRate;
  final List<MapEntry<String, double>> topCategories;
  final List<Goal> activeGoals;
  final int daysOfData;

  FinancialSnapshot({
    required this.currentBalance,
    required this.monthlyIncome,
    required this.monthlyExpenses,
    required this.averageMonthlySavings,
    required this.savingsRate,
    required this.topCategories,
    required this.activeGoals,
    required this.daysOfData,
  });

  Map<String, dynamic> toJson() => {
        'currentBalance': currentBalance,
        'monthlyIncome': monthlyIncome,
        'monthlyExpenses': monthlyExpenses,
        'averageMonthlySavings': averageMonthlySavings,
        'savingsRate': savingsRate,
        'topCategories': {for (final e in topCategories) e.key: e.value},
        'goals': activeGoals
            .map((g) => {
                  'name': g.name,
                  'target': g.targetAmount,
                  'current': g.currentAmount,
                  'requiredMonthly': CalculationEngine.requiredMonthlySaving(g),
                })
            .toList(),
        'daysOfData': daysOfData,
      };
}

class AiResult {
  final String whatHappened;
  final List<String> actions;
  final String goalAdvice;
  final bool isOffline;

  AiResult({
    required this.whatHappened,
    required this.actions,
    required this.goalAdvice,
    this.isOffline = false,
  });
}

class AiService {
  final List<String> _apiKeys = [
    'AQ.Ab8RN6K8-LwFWF_NWwQs0277NWNhtLjFB35hhxxmD-KkZ6TC4Q',
    'AQ.Ab8RN6JURljh-4bNIVmWNFXkLLbYUX857Idt9u5QOHvjE8JFRg',
    'AQ.Ab8RN6IauWNSI5O95I5-oeoRSW3t7K-G5VA1XkRSBMd_3PPhyQ',
    'AQ.Ab8RN6KEv0EYZHLN6TYIbFhab_KLa918D333gjBRknYfdKUPog',
    'AQ.Ab8RN6I3q0EUKwSY621arqAR0SnQHiz89GrOBEFePP6Gl8v6-A'
  ];
  int _currentKeyIndex = 0;

  final List<String> _models = [
    'gemini-1.5-flash',      // Paling stabil & meluas
    'gemini-2.0-flash',      // Versi 2.0 (Laju)
    'gemini-1.5-pro',        // Paling bijak
    'gemini-2.0-flash-lite-preview-02-05',
    'gemini-3.6-flash',      // Eksperimental
  ];

  String _getNextKey() {
    final key = _apiKeys[_currentKeyIndex];
    _currentKeyIndex = (_currentKeyIndex + 1) % _apiKeys.length;
    return key;
  }

  Future<AiResult> analyze(FinancialSnapshot snapshot) async {
    Object? lastError;
    
    for (var modelName in _models) {
      try {
        final model = GenerativeModel(
          model: modelName,
          apiKey: _getNextKey(),
          systemInstruction: Content.system(
              'You are Waguri Kaoruko, a financial advisor friend. Analyze the financial data provided and give encouraging advice in Malay.'),
        );

        final prompt = 'Data: ${jsonEncode(snapshot.toJson())}. '
            'Task: Return a JSON object with keys: "whatHappened" (String summary in Malay), '
            '"actions" (List of Strings in Malay), "goalAdvice" (String in Malay). '
            'Do not include any text other than the JSON.';

        final response = await model.generateContent([Content.text(prompt)]);
        if (response.text != null) {
          String clean = _extractJson(response.text!);
          final data = jsonDecode(clean);
          return AiResult(
            whatHappened: data['whatHappened'] ?? '',
            actions: (data['actions'] as List?)?.map((e) => e.toString()).toList() ?? [],
            goalAdvice: data['goalAdvice'] ?? '',
          );
        }
      } catch (e) {
        lastError = e;
        print('Waguri AI Analyze ($modelName) failed: $e');
        continue;
      }
    }
    
    return _localFallbackAnalysis(snapshot, isOffline: true);
  }

  Future<String> chat(String question, FinancialSnapshot snapshot) async {
    Object? lastError;

    for (var modelName in _models) {
      try {
        final model = GenerativeModel(
          model: modelName,
          apiKey: _getNextKey(),
          systemInstruction: Content.system(
              'You are Waguri Kaoruko, a helpful and sweet friend from Kikyo Girls Academy. You are helping your friend manage their money. Answer in gentle Malay. Keep it short.'),
        );

        final prompt = 'Data: ${jsonEncode(snapshot.toJson())}. Question: $question';
        final response = await model.generateContent([Content.text(prompt)]);
        if (response.text != null) return response.text!;
      } catch (e) {
        lastError = e;
        print('Waguri AI Chat ($modelName) failed: $e');
        continue;
      }
    }

    return 'Waguri AI Coach sedang berehat sekejap. Cuba lagi nanti eh?';
  }

  Future<Map<String, dynamic>?> parseReceipt(String ocrText) async {
    for (var modelName in _models) {
      try {
        final model = GenerativeModel(
          model: modelName,
          apiKey: _getNextKey(),
          systemInstruction: Content.system(
              'You are an expert at parsing receipt text into JSON. Extract amount (double), category (one of: Makanan, Pengangkutan, Membeli-belah, Bil, Pendidikan, Hiburan, Kesihatan, Keluarga, Lain-lain), date (YYYY-MM-DD), and note (shop name or item).'),
        );

        final prompt = 'Parse this text into a JSON object. Return ONLY the JSON: $ocrText';
        final response = await model.generateContent([Content.text(prompt)]);
        if (response.text != null) {
          String clean = _extractJson(response.text!);
          return jsonDecode(clean);
        }
      } catch (e) {
        print('Waguri AI Parse ($modelName) failed: $e');
      }
    }
    return null;
  }

  String _extractJson(String text) {
    String clean = text.trim();
    clean = clean.replaceAll('```json', '').replaceAll('```', '').trim();
    if (clean.contains('{') && clean.contains('}')) {
      clean = clean.substring(clean.indexOf('{'), clean.lastIndexOf('}') + 1);
    }
    return clean;
  }

  AiResult _localFallbackAnalysis(FinancialSnapshot s, {bool isOffline = false}) {
    if (isOffline) {
      return AiResult(
        whatHappened: 'Waguri AI Coach sedang berehat sekejap. Data kewangan awak tetap selamat secara offline.',
        actions: const [],
        goalAdvice: '',
        isOffline: true,
      );
    }

    if (s.daysOfData < 7) {
      return AiResult(
        whatHappened: 'Masukkan lebih banyak transaksi untuk Waguri berikan nasihat yang lebih tepat.',
        actions: const ['Catat pendapatan dan perbelanjaan untuk beberapa hari lagi.'],
        goalAdvice: '',
      );
    }

    final buffer = StringBuffer();
    buffer.write('Simpanan bulanan purata awak adalah sekitar RM${s.averageMonthlySavings.toStringAsFixed(2)}, ');
    buffer.write('dengan kadar simpanan ${s.savingsRate.toStringAsFixed(0)}%.');
    final whatHappened = buffer.toString();

    final actions = <String>[];
    if (s.topCategories.isNotEmpty) {
      final top = s.topCategories.first;
      actions.add(
          'Perbelanjaan terbesar awak adalah dalam kategori ${top.key} (RM${top.value.toStringAsFixed(2)}). Kalau dapat kurangkan sikit dalam 10-15%, simpanan awak akan bertambah tau!');
    }
    if (s.savingsRate < 20) {
      actions.add('Kadar simpanan awak bawah 20%. Jom kita semak balik belanja langganan atau bil yang tak perlu.');
    } else {
      actions.add('Kadar simpanan awak nampak sihat! Teruskan disiplin macam ni eh?');
    }

    String goalAdvice = '';
    if (s.activeGoals.isNotEmpty) {
      final g = s.activeGoals.first;
      final required = CalculationEngine.requiredMonthlySaving(g);
      final gap = required - s.averageMonthlySavings;
      if (gap > 0) {
        goalAdvice =
            'Matlamat "${g.name}" awak perlukan sekitar RM${required.toStringAsFixed(2)} sebulan. '
            "Sekarang masih kurang RM${gap.toStringAsFixed(2)}/bulan. "
            'Awak boleh cuba tambah simpanan atau panjangkan sikit tempoh sasaran.';
      } else {
        goalAdvice = 'Matlamat "${g.name}" awak perlukan RM${required.toStringAsFixed(2)} sebulan, '
            'dan gaya simpanan awak sekarang dah cukup — awak berada di landasan yang betul!';
      }
    }

    return AiResult(whatHappened: whatHappened, actions: actions, goalAdvice: goalAdvice);
  }

  String _localFallbackChat(String question, FinancialSnapshot s) {
    final q = question.toLowerCase();
    if (q.contains('belanja') && (q.contains('minggu') || q.contains('week'))) {
      final weeklyBudget = (s.monthlyIncome - s.monthlyExpenses) / 4.345;
      return 'Berdasarkan bulan ini, awak ada lebih kurang RM${weeklyBudget.toStringAsFixed(2)} baki bajet fleksibel seminggu kalau kekalkan gaya belanja sekarang.';
    }
    if (q.contains('kenapa') || q.contains('why')) {
      if (s.topCategories.isNotEmpty) {
        return 'Simpanan awak berubah kebanyakannya sebab belanja dalam ${s.topCategories.first.key}, iaitu kategori tertinggi bulan ni.';
      }
      return "Waguri rasa data kita belum cukup untuk buat anggaran tepat lah...";
    }
    if (s.activeGoals.isNotEmpty && (q.contains('goal') || q.contains('capai') || q.contains('target'))) {
      final g = s.activeGoals.first;
      final required = CalculationEngine.requiredMonthlySaving(g);
      return 'Untuk capai "${g.name}", awak kena simpan RM${required.toStringAsFixed(2)} setiap bulan ikut tarikh tamat tu.';
    }
    return "Waguri rasa data kita belum cukup untuk buat anggaran tepat lah...";
  }
}
