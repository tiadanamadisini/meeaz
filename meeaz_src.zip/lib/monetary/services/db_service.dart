import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../models/account.dart';
import '../models/goal.dart';
import '../models/money_transaction.dart';

/// All local persistence. Offline-first: everything except the AI Coach
/// works with zero network access, per spec section 22.
class DbService {
  DbService._internal();
  static final DbService instance = DbService._internal();

  Database? _db;

  Future<Database> get database async {
    _db ??= await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final path = join(await getDatabasesPath(), 'moneytrack_ai.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE accounts(
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            type TEXT NOT NULL,
            balance REAL NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE transactions(
            id TEXT PRIMARY KEY,
            accountId TEXT NOT NULL,
            type TEXT NOT NULL,
            amount REAL NOT NULL,
            category TEXT NOT NULL,
            date TEXT NOT NULL,
            note TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE goals(
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            targetAmount REAL NOT NULL,
            currentAmount REAL NOT NULL,
            targetDate TEXT NOT NULL,
            createdAt TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE ai_conversation(
            id TEXT PRIMARY KEY,
            message TEXT NOT NULL,
            response TEXT NOT NULL,
            createdAt TEXT NOT NULL
          )
        ''');
      },
    );
  }

  // ---------- Accounts ----------
  Future<List<Account>> getAccounts() async {
    final db = await database;
    final rows = await db.query('accounts');
    return rows.map(Account.fromMap).toList();
  }

  Future<void> upsertAccount(Account a) async {
    final db = await database;
    await db.insert('accounts', a.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> deleteAccount(String id) async {
    final db = await database;
    await db.delete('accounts', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Transactions ----------
  Future<List<MoneyTransaction>> getTransactions() async {
    final db = await database;
    final rows = await db.query('transactions', orderBy: 'date DESC');
    return rows.map(MoneyTransaction.fromMap).toList();
  }

  Future<void> upsertTransaction(MoneyTransaction t) async {
    final db = await database;
    await db.insert('transactions', t.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> deleteTransaction(String id) async {
    final db = await database;
    await db.delete('transactions', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Goals ----------
  Future<List<Goal>> getGoals() async {
    final db = await database;
    final rows = await db.query('goals', orderBy: 'createdAt DESC');
    return rows.map(Goal.fromMap).toList();
  }

  Future<void> upsertGoal(Goal g) async {
    final db = await database;
    await db.insert('goals', g.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> deleteGoal(String id) async {
    final db = await database;
    await db.delete('goals', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- AI conversation log ----------
  Future<void> logAiMessage(String message, String response) async {
    final db = await database;
    await db.insert('ai_conversation', {
      'id': DateTime.now().microsecondsSinceEpoch.toString(),
      'message': message,
      'response': response,
      'createdAt': DateTime.now().toIso8601String(),
    });
  }

  Future<List<Map<String, dynamic>>> getAiConversation() async {
    final db = await database;
    return db.query('ai_conversation', orderBy: 'createdAt ASC');
  }

  Future<void> clearAiConversation() async {
    final db = await database;
    await db.delete('ai_conversation');
  }

  // ---------- Wipe everything (Settings > Delete all data) ----------
  Future<void> deleteAllData() async {
    final db = await database;
    await db.delete('accounts');
    await db.delete('transactions');
    await db.delete('goals');
    await db.delete('ai_conversation');
  }
}
