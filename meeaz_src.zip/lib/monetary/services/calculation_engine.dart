import '../models/account.dart';
import '../models/goal.dart';
import '../models/money_transaction.dart';

enum GoalStatus { onTrack, needsAdjustment, unknown }

/// All financial math lives here as pure, deterministic, testable functions.
/// Nothing in this file calls the AI — per spec, AI never does arithmetic.
class CalculationEngine {
  static double totalBalance(List<Account> accounts) =>
      accounts.fold(0.0, (sum, a) => sum + a.balance);

  static bool _inMonth(DateTime d, int year, int month) =>
      d.year == year && d.month == month;

  static double monthlyIncome(List<MoneyTransaction> txs, DateTime month) =>
      txs
          .where((t) => t.type == TxType.income && _inMonth(t.date, month.year, month.month))
          .fold(0.0, (s, t) => s + t.amount);

  static double monthlyExpenses(List<MoneyTransaction> txs, DateTime month) =>
      txs
          .where((t) => t.type == TxType.expense && _inMonth(t.date, month.year, month.month))
          .fold(0.0, (s, t) => s + t.amount);

  static double savings(double income, double expenses) => income - expenses;

  /// Returns 0-100. Guards against divide-by-zero.
  static double savingsRate(double savings, double income) {
    if (income <= 0) return 0;
    return (savings / income) * 100;
  }

  /// Average monthly income/expenses/savings over the last [months] months
  /// that actually contain data. Returns (value, daysOfDataUsed).
  static ({double avgIncome, double avgExpenses, double avgSavings, int daysOfData})
      averages(List<MoneyTransaction> txs, {int months = 3, DateTime? now}) {
    final today = now ?? DateTime.now();
    final cutoff = DateTime(today.year, today.month - months + 1, 1);
    final relevant = txs.where((t) => t.date.isAfter(cutoff.subtract(const Duration(days: 1)))).toList();

    if (relevant.isEmpty) {
      return (avgIncome: 0, avgExpenses: 0, avgSavings: 0, daysOfData: 0);
    }

    final earliest = relevant.map((t) => t.date).reduce((a, b) => a.isBefore(b) ? a : b);
    final daysOfData = today.difference(earliest).inDays + 1;

    // Group by year-month
    final Map<String, double> incomeByMonth = {};
    final Map<String, double> expenseByMonth = {};
    for (final t in relevant) {
      final key = '${t.date.year}-${t.date.month}';
      if (t.type == TxType.income) {
        incomeByMonth[key] = (incomeByMonth[key] ?? 0) + t.amount;
      } else {
        expenseByMonth[key] = (expenseByMonth[key] ?? 0) + t.amount;
      }
    }
    final monthKeys = <String>{...incomeByMonth.keys, ...expenseByMonth.keys};
    final n = monthKeys.isEmpty ? 1 : monthKeys.length;

    final totalIncome = incomeByMonth.values.fold(0.0, (s, v) => s + v);
    final totalExpense = expenseByMonth.values.fold(0.0, (s, v) => s + v);
    final avgIncome = totalIncome / n;
    final avgExpenses = totalExpense / n;

    return (
      avgIncome: avgIncome,
      avgExpenses: avgExpenses,
      avgSavings: avgIncome - avgExpenses,
      daysOfData: daysOfData,
    );
  }

  /// Income/expenses for each of the last [months] months, oldest first,
  /// ending at [now]'s month. Powers both the "Income vs Expenses" bar
  /// chart and the "Savings Trend" line chart (savings = income - expenses
  /// per entry) so the two charts always agree with each other.
  static List<({DateTime month, double income, double expenses})> monthlyHistory(
    List<MoneyTransaction> txs, {
    int months = 6,
    DateTime? now,
  }) {
    final today = now ?? DateTime.now();
    return List.generate(months, (i) {
      final offset = months - 1 - i;
      final m = DateTime(today.year, today.month - offset, 1);
      return (
        month: m,
        income: monthlyIncome(txs, m),
        expenses: monthlyExpenses(txs, m),
      );
    });
  }

  /// Top spending categories this month, sorted descending, top [limit].
  static List<MapEntry<String, double>> categoryTotals(
    List<MoneyTransaction> txs,
    DateTime month, {
    int limit = 5,
  }) {
    final Map<String, double> totals = {};
    for (final t in txs) {
      if (t.type == TxType.expense && _inMonth(t.date, month.year, month.month)) {
        totals[t.category] = (totals[t.category] ?? 0) + t.amount;
      }
    }
    final entries = totals.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return entries.take(limit).toList();
  }

  static double goalRemaining(Goal g) {
    final r = g.targetAmount - g.currentAmount;
    return r < 0 ? 0 : r;
  }

  static double goalProgressPercent(Goal g) {
    if (g.targetAmount <= 0) return 0;
    final p = (g.currentAmount / g.targetAmount) * 100;
    return p.clamp(0, 100).toDouble();
  }

  /// Whole months remaining until target date, minimum 1 to avoid divide-by-zero.
  static int monthsRemaining(Goal g, {DateTime? now}) {
    final today = now ?? DateTime.now();
    if (g.targetDate.isBefore(today)) return 0;
    int months = (g.targetDate.year - today.year) * 12 + (g.targetDate.month - today.month);
    if (g.targetDate.day < today.day) months -= 1;
    return months < 1 ? 1 : months;
  }

  static double requiredMonthlySaving(Goal g, {DateTime? now}) {
    final remaining = goalRemaining(g);
    final months = monthsRemaining(g, now: now);
    return remaining / months;
  }

  static double requiredWeeklySaving(Goal g, {DateTime? now}) {
    return requiredMonthlySaving(g, now: now) / 4.345; // avg weeks/month
  }

  /// "If I save RM___ per month, how many months to reach goal?"
  /// Pure code, not AI, per spec section 11.
  static int? monthsToGoalAtRate(Goal g, double monthlySaving) {
    if (monthlySaving <= 0) return null;
    final remaining = goalRemaining(g);
    if (remaining <= 0) return 0;
    return (remaining / monthlySaving).ceil();
  }

  static GoalStatus goalStatus({
    required double requiredMonthly,
    required double averageMonthlySavings,
    required int daysOfData,
  }) {
    if (daysOfData < 7) return GoalStatus.unknown;
    return averageMonthlySavings >= requiredMonthly ? GoalStatus.onTrack : GoalStatus.needsAdjustment;
  }
}
