import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/goal.dart';
import '../services/app_state.dart';

class CreateGoalScreen extends StatefulWidget {
  final Goal? existing;
  const CreateGoalScreen({super.key, this.existing});

  @override
  State<CreateGoalScreen> createState() => _CreateGoalScreenState();
}

class _CreateGoalScreenState extends State<CreateGoalScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _targetCtrl = TextEditingController();
  final _currentCtrl = TextEditingController();
  DateTime _targetDate = DateTime.now().add(const Duration(days: 180));

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    if (e != null) {
      _nameCtrl.text = e.name;
      _targetCtrl.text = e.targetAmount.toStringAsFixed(2);
      _currentCtrl.text = e.currentAmount.toStringAsFixed(2);
      _targetDate = e.targetDate;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;
    return Scaffold(
      appBar: AppBar(
        title: Text(isEdit ? 'Ubah Matlamat' : 'Cipta Matlamat'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Color(0xFFC97C6D)),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _nameCtrl,
              decoration: const InputDecoration(labelText: 'Nama matlamat', hintText: 'cth: Laptop Baharu'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Masukkan nama matlamat' : null,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _targetCtrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'Jumlah sasaran (RM)', prefixText: 'RM '),
              validator: (v) {
                final val = double.tryParse(v ?? '');
                if (val == null || val <= 0) return 'Masukkan jumlah yang sah';
                return null;
              },
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _currentCtrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'Simpanan sedia ada (RM)', prefixText: 'RM '),
              validator: (v) {
                final val = double.tryParse(v ?? '');
                if (val == null || val < 0) return 'Masukkan jumlah yang sah';
                return null;
              },
            ),
            const SizedBox(height: 16),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Tarikh sasaran'),
              subtitle: Text('${_targetDate.day}/${_targetDate.month}/${_targetDate.year}'),
              trailing: const Icon(Icons.calendar_today, size: 18),
              onTap: () async {
                final picked = await showDatePicker(
                  context: context,
                  initialDate: _targetDate,
                  firstDate: DateTime.now(),
                  lastDate: DateTime(2100),
                );
                if (picked != null) setState(() => _targetDate = picked);
              },
            ),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: _submit,
              style: FilledButton.styleFrom(backgroundColor: const Color(0xFFC97C6D)),
              child: Text(isEdit ? 'Simpan Perubahan' : 'Cipta Matlamat'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    final app = context.read<AppState>();
    final target = double.parse(_targetCtrl.text);
    final current = double.parse(_currentCtrl.text);

    if (widget.existing == null) {
      await app.addGoal(
        name: _nameCtrl.text.trim(),
        targetAmount: target,
        currentAmount: current,
        targetDate: _targetDate,
      );
    } else {
      final g = widget.existing!;
      g.name = _nameCtrl.text.trim();
      g.targetAmount = target;
      g.currentAmount = current;
      g.targetDate = _targetDate;
      await app.updateGoal(g);
    }
    if (mounted) Navigator.pop(context);
  }
}
