import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/goal.dart';
import '../services/app_state.dart';
import '../services/calculation_engine.dart';
import '../utils/formatters.dart';
import 'create_goal_screen.dart';

class GoalDetailScreen extends StatefulWidget {
  final Goal goal;
  const GoalDetailScreen({super.key, required this.goal});

  @override
  State<GoalDetailScreen> createState() => _GoalDetailScreenState();
}

class _GoalDetailScreenState extends State<GoalDetailScreen> {
  final _simCtrl = TextEditingController();
  int? _simResultMonths;
  bool _simTriedNoResult = false;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    // Re-fetch latest copy in case it was edited.
    final goal = app.goals.firstWhere((g) => g.id == widget.goal.id, orElse: () => widget.goal);

    final remaining = CalculationEngine.goalRemaining(goal);
    final progress = CalculationEngine.goalProgressPercent(goal);
    final months = CalculationEngine.monthsRemaining(goal);
    final requiredMonthly = CalculationEngine.requiredMonthlySaving(goal);
    final requiredWeekly = CalculationEngine.requiredWeeklySaving(goal);

    final avg = CalculationEngine.averages(app.transactions);
    final status = CalculationEngine.goalStatus(
      requiredMonthly: requiredMonthly,
      averageMonthlySavings: avg.avgSavings,
      daysOfData: avg.daysOfData,
    );

    return Scaffold(
      appBar: AppBar(
        title: Text(goal.name),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Color(0xFFC97C6D)),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_outlined),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => CreateGoalScreen(existing: goal)),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('Delete goal?'),
                  content: const Text('This cannot be undone.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                    TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
                  ],
                ),
              );
              if (confirm == true && context.mounted) {
                await context.read<AppState>().deleteGoal(goal.id);
                if (context.mounted) Navigator.pop(context);
              }
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('${formatMoney(goal.currentAmount)} / ${formatMoney(goal.targetAmount)}',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(value: progress / 100, minHeight: 10),
          ),
          const SizedBox(height: 6),
          Text('${progress.toStringAsFixed(1)}%'),
          const SizedBox(height: 20),
          _row('Baki Diperlukan', formatMoney(remaining)),
          _row('Bulan Tersisa', '$months'),
          _row('Simpanan Bulanan Perlu', formatMoney(requiredMonthly)),
          _row('Simpanan Mingguan Perlu', formatMoney(requiredWeekly)),
          _row('Tarikh Sasaran', formatDate(goal.targetDate)),
          const SizedBox(height: 20),
          _StatusCard(status: status, requiredMonthly: requiredMonthly, avgMonthly: avg.avgSavings),
          const SizedBox(height: 24),
          const Text('Simulator Matlamat', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          const Text('Jika saya simpan RM___ sebulan...', style: TextStyle(color: Colors.grey)),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _simCtrl,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'Simpanan bulanan (RM)', prefixText: 'RM '),
                ),
              ),
              const SizedBox(width: 12),
              FilledButton(
                onPressed: () {
                  final val = double.tryParse(_simCtrl.text);
                  setState(() {
                    if (val == null || val <= 0) {
                      _simResultMonths = null;
                      _simTriedNoResult = true;
                    } else {
                      _simResultMonths = CalculationEngine.monthsToGoalAtRate(goal, val);
                      _simTriedNoResult = false;
                    }
                  });
                },
                style: FilledButton.styleFrom(backgroundColor: const Color(0xFFC97C6D)),
                child: const Text('Kira'),
              ),
            ],
          ),
          if (_simResultMonths != null) ...[
            const SizedBox(height: 12),
            Text(
              _simResultMonths == 0
                  ? 'Awak dah capai matlamat ni!'
                  : 'Dengan kadar tu, awak akan capai matlamat dalam $_simResultMonths bulan.',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ] else if (_simTriedNoResult) ...[
            const SizedBox(height: 12),
            const Text('Masukkan jumlah bulanan yang sah.', style: TextStyle(color: Colors.red)),
          ],
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [100, 200, 300, 500].map((v) {
              final m = CalculationEngine.monthsToGoalAtRate(goal, v.toDouble());
              return Chip(label: Text('RM$v → ${m == null ? '-' : '$m mo'}'));
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: Colors.grey.shade600)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _StatusCard extends StatelessWidget {
  final GoalStatus status;
  final double requiredMonthly;
  final double avgMonthly;

  const _StatusCard({required this.status, required this.requiredMonthly, required this.avgMonthly});

  @override
  Widget build(BuildContext context) {
    if (status == GoalStatus.unknown) {
      return Card(
        color: Colors.grey.shade100,
        child: const Padding(
          padding: EdgeInsets.all(16),
          child: Text('Masukkan lebih banyak transaksi untuk Waguri semak status matlamat awak.'),
        ),
      );
    }
    final onTrack = status == GoalStatus.onTrack;
    return Card(
      color: onTrack ? Colors.green.shade50 : Colors.orange.shade50,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(onTrack ? Icons.check_circle : Icons.info_outline,
                    color: onTrack ? Colors.green : Colors.orange.shade800),
                const SizedBox(width: 8),
                Text(
                  onTrack ? 'Berada di Laluan' : 'Perlu Pelarasan',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: onTrack ? Colors.green.shade800 : Colors.orange.shade800,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'Simpanan purata semasa awak adalah ${formatMoney(avgMonthly)}/bulan. '
              'Matlamat awak memerlukan sekitar ${formatMoney(requiredMonthly)}/bulan.',
            ),
          ],
        ),
      ),
    );
  }
}
