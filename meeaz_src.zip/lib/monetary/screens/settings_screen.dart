import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/account.dart';
import '../services/app_state.dart';
import '../utils/formatters.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final rose = const Color(0xFFC97C6D);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Tetapan Kewangan'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Color(0xFFC97C6D)),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 30),
        children: [
          _section(
            context,
            title: 'Akaun Waguri',
            children: [
              ...app.accounts.map((a) => ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(
                      backgroundColor: rose.withValues(alpha: 0.1),
                      child: Icon(Icons.account_balance_wallet_outlined, color: rose, size: 20),
                    ),
                    title: Text(a.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Text(a.type.label, style: const TextStyle(fontSize: 12)),
                    trailing: Text(formatMoney(a.balance), style: const TextStyle(fontWeight: FontWeight.bold)),
                    onLongPress: () => context.read<AppState>().deleteAccount(a.id),
                  )),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => _showAddAccountSheet(context),
                  icon: const Icon(Icons.add),
                  label: const Text('Tambah Akaun Baharu'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: rose,
                    side: BorderSide(color: rose.withValues(alpha: 0.5)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          _section(
            context,
            title: 'Privasi & Data',
            children: [
              SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                title: const Text('Benarkan Waguri guna data saya'),
                subtitle: const Text('Diperlukan untuk analisis Waguri AI Coach.', style: TextStyle(fontSize: 12)),
                value: app.aiPermissionGranted,
                activeColor: rose,
                onChanged: (v) => context.read<AppState>().setAiPermission(v),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.download_outlined),
                title: const Text('Eksport Data (JSON)'),
                onTap: () => _exportData(context),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.chat_bubble_outline),
                title: const Text('Padam Sembang AI'),
                onTap: () async {
                  await context.read<AppState>().clearAiChat();
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Sembang AI telah dipadam.')));
                  }
                },
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.delete_forever_outlined, color: Colors.red),
                title: const Text('Padam Semua Data', style: TextStyle(color: Colors.red)),
                onTap: () => _confirmDeleteAll(context),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _section(BuildContext context, {required String title, required List<Widget> children}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title.toUpperCase(),
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w800,
            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.45),
            letterSpacing: 1.1,
          ),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.04),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(children: children),
        ),
      ],
    );
  }

  void _showAddAccountSheet(BuildContext context) {
    final nameCtrl = TextEditingController();
    final balanceCtrl = TextEditingController(text: '0');
    AccountType type = AccountType.cash;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 16,
        ),
        child: StatefulBuilder(
          builder: (ctx, setState) => Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('New Account', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              const SizedBox(height: 12),
              TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Account name')),
              const SizedBox(height: 12),
              DropdownButtonFormField<AccountType>(
                initialValue: type,
                decoration: const InputDecoration(labelText: 'Type'),
                items: AccountType.values
                    .map((t) => DropdownMenuItem(value: t, child: Text(t.label)))
                    .toList(),
                onChanged: (v) => setState(() => type = v ?? AccountType.cash),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: balanceCtrl,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Current balance (RM)', prefixText: 'RM '),
              ),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () async {
                  final name = nameCtrl.text.trim();
                  final balance = double.tryParse(balanceCtrl.text) ?? 0;
                  if (name.isEmpty) return;
                  await ctx.read<AppState>().addAccount(name: name, type: type, balance: balance);
                  if (ctx.mounted) Navigator.pop(ctx);
                },
                child: const Text('Add Account'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _exportData(BuildContext context) {
    final app = context.read<AppState>();
    final data = {
      'accounts': app.accounts.map((a) => a.toMap()).toList(),
      'transactions': app.transactions.map((t) => t.toMap()).toList(),
      'goals': app.goals.map((g) => g.toMap()).toList(),
    };
    final json = const JsonEncoder.withIndent('  ').convert(data);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Exported Data (JSON)'),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(child: SelectableText(json)),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close'))],
      ),
    );
  }

  void _confirmDeleteAll(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete all data?'),
        content: const Text('This removes all accounts, transactions, and goals. This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () async {
              await ctx.read<AppState>().deleteAllData();
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}
