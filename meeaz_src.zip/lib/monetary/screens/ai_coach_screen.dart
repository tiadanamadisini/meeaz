import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/ai_service.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';

class AiCoachScreen extends StatefulWidget {
  const AiCoachScreen({super.key});

  @override
  State<AiCoachScreen> createState() => _AiCoachScreenState();
}

class _ChatMessage {
  final String text;
  final bool fromUser;
  _ChatMessage(this.text, this.fromUser);
}

class _AiCoachScreenState extends State<AiCoachScreen> {
  AiResult? _result;
  bool _loading = false;
  final List<_ChatMessage> _chat = [];
  final _chatCtrl = TextEditingController();
  bool _chatLoading = false;

  static const _suggestedQuestions = [
    'Berapa saya boleh belanja minggu ini?',
    'Kenapa savings saya turun?',
    'Boleh analisis spending saya?',
  ];

  Future<void> _analyze() async {
    final app = context.read<AppState>();
    setState(() => _loading = true);
    final snapshot = app.buildSnapshot();
    final result = await app.aiService.analyze(snapshot);
    if (!mounted) return;
    setState(() {
      _result = result;
      _loading = false;
    });
  }

  Future<void> _sendChat(String text) async {
    if (text.trim().isEmpty) return;
    final app = context.read<AppState>();
    setState(() {
      _chat.add(_ChatMessage(text, true));
      _chatLoading = true;
      _chatCtrl.clear();
    });
    final snapshot = app.buildSnapshot();
    final answer = await app.aiService.chat(text, snapshot);
    if (!mounted) return;
    setState(() {
      _chat.add(_ChatMessage(answer, false));
      _chatLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Waguri AI Coach'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.brand),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (_result == null && !_loading)
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 24),
                child: Column(
                  children: [
                    const Icon(Icons.auto_awesome_outlined, size: 48, color: AppColors.brand),
                    const SizedBox(height: 12),
                    const Text('Dapatkan nasihat kewangan peribadi dari Waguri.',
                        textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      style: FilledButton.styleFrom(backgroundColor: AppColors.brand),
                      onPressed: _analyze,
                      icon: const Icon(Icons.insights),
                      label: const Text('Analisis Kewangan Saya'),
                    ),
                  ],
                ),
              ),
            ),
          if (_loading) const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator())),
          if (_result != null) _AnalysisCard(result: _result!, onRefresh: _analyze),
          const SizedBox(height: 24),
          const Divider(),
          const SizedBox(height: 8),
          const Text('Ask AI Coach', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _suggestedQuestions
                .map((q) => ActionChip(label: Text(q, style: const TextStyle(fontSize: 12)), onPressed: () => _sendChat(q)))
                .toList(),
          ),
          const SizedBox(height: 12),
          ..._chat.map((m) => Align(
                alignment: m.fromUser ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                  decoration: BoxDecoration(
                    color: m.fromUser ? AppColors.brand.withValues(alpha: 0.1) : Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(m.text),
                ),
              )),
          if (_chatLoading) const Padding(padding: EdgeInsets.all(8), child: LinearProgressIndicator(color: AppColors.brand)),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _chatCtrl,
                  decoration: const InputDecoration(hintText: 'Tanya Waguri pasal duit awak...'),
                  onSubmitted: _sendChat,
                ),
              ),
              IconButton(
                icon: const Icon(Icons.send, color: AppColors.brand),
                onPressed: () => _sendChat(_chatCtrl.text),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _AnalysisCard extends StatelessWidget {
  final AiResult result;
  final VoidCallback onRefresh;
  const _AnalysisCard({required this.result, required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    if (result.isOffline) {
      return Card(
        color: Colors.grey.shade100,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              const Icon(Icons.cloud_off, color: Colors.grey),
              const SizedBox(width: 12),
              Expanded(child: Text(result.whatHappened)),
            ],
          ),
        ),
      );
    }
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Apa yang telah berlaku?', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            Text(result.whatHappened),
            const SizedBox(height: 16),
            if (result.actions.isNotEmpty) ...[
              const Text('Apa yang perlu saya buat?', style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 6),
              ...result.actions.map((a) => Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Text('• $a'),
                  )),
              const SizedBox(height: 16),
            ],
            if (result.goalAdvice.isNotEmpty) ...[
              const Text('Nasihat matlamat', style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 6),
              Text(result.goalAdvice),
              const SizedBox(height: 12),
            ],
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: onRefresh,
                icon: const Icon(Icons.refresh, size: 16),
                label: const Text('Refresh'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
