import 'dart:io';
import 'package:flutter/material.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../models/money_transaction.dart';
import '../services/app_state.dart';
import 'add_transaction_screen.dart';

class ScanTransactionScreen extends StatefulWidget {
  const ScanTransactionScreen({super.key});

  @override
  State<ScanTransactionScreen> createState() => _ScanTransactionScreenState();
}

class _ScanTransactionScreenState extends State<ScanTransactionScreen> {
  final ImagePicker _picker = ImagePicker();
  final TextRecognizer _textRecognizer = TextRecognizer();
  bool _isProcessing = false;

  Future<void> _pickAndProcess(ImageSource source) async {
    final XFile? image = await _picker.pickImage(source: source);
    if (image == null) return;

    setState(() => _isProcessing = true);

    try {
      final inputImage = InputImage.fromFilePath(image.path);
      final recognizedText = await _textRecognizer.processImage(inputImage);
      
      final app = context.read<AppState>();
      final result = await app.aiService.parseReceipt(recognizedText.text);

      if (mounted) {
        setState(() => _isProcessing = false);
        if (result != null) {
          // Go to manual screen with pre-filled data for verification
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => AddTransactionScreen(
                prefilledAmount: double.tryParse(result['amount']?.toString() ?? ''),
                prefilledCategory: result['category']?.toString(),
                prefilledDate: DateTime.tryParse(result['date']?.toString() ?? ''),
                prefilledNote: result['note']?.toString(),
              ),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Maaf, AI gagal membaca resit. Sila masukkan manual.')),
          );
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const AddTransactionScreen()),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isProcessing = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Ralat: $e')),
        );
      }
    }
  }

  @override
  void dispose() {
    _textRecognizer.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Scan Resit / Bil'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Color(0xFFC97C6D)),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Center(
        child: _isProcessing
            ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TweenAnimationBuilder<double>(
                    tween: Tween(begin: 0.8, end: 1.2),
                    duration: const Duration(seconds: 1),
                    curve: Curves.easeInOut,
                    builder: (context, value, child) => Transform.scale(scale: value, child: child),
                    onEnd: () {}, // Not needed with repeat logic but this is a simple pulse
                    child: const Icon(Icons.document_scanner_rounded, size: 80, color: Color(0xFFC97C6D)),
                  ),
                  const SizedBox(height: 30),
                  const CircularProgressIndicator(color: Color(0xFFC97C6D)),
                  const SizedBox(height: 24),
                  const Text('Waguri sedang mengimbas resit anda...',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  const Text('Mohon tunggu sekejap ya~ 🌸',
                      style: TextStyle(fontSize: 13, color: Colors.grey)),
                ],
              )
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.receipt_long_rounded, size: 80, color: Color(0xFFC97C6D)),
                  const SizedBox(height: 30),
                  const Text('Pilih sumber gambar resit',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 40),
                  _actionButton(
                    'Kamera',
                    Icons.camera_alt_rounded,
                    () => _pickAndProcess(ImageSource.camera),
                  ),
                  const SizedBox(height: 16),
                  _actionButton(
                    'Galeri',
                    Icons.photo_library_rounded,
                    () => _pickAndProcess(ImageSource.gallery),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _actionButton(String label, IconData icon, VoidCallback onTap) {
    return SizedBox(
      width: 250,
      height: 55,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(icon),
        label: Text(label),
        style: ElevatedButton.styleFrom(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        ),
      ),
    );
  }
}
