import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'ai_coach_screen.dart';
import 'goals_screen.dart';
import 'home_screen.dart';
import 'transactions_screen.dart';

class RootScreen extends StatefulWidget {
  const RootScreen({super.key});

  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  int _index = 0;

  static const _screens = [
    HomeScreen(),
    TransactionsScreen(),
    GoalsScreen(),
    AiCoachScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(
              icon: Icon(CupertinoIcons.house),
              selectedIcon: Icon(CupertinoIcons.house_fill),
              label: 'Utama'),
          NavigationDestination(
              icon: Icon(CupertinoIcons.doc_text),
              selectedIcon: Icon(CupertinoIcons.doc_text_fill),
              label: 'Rekod'),
          NavigationDestination(
              icon: Icon(CupertinoIcons.flag),
              selectedIcon: Icon(CupertinoIcons.flag_fill),
              label: 'Matlamat'),
          NavigationDestination(
              icon: Icon(CupertinoIcons.sparkles),
              selectedIcon: Icon(CupertinoIcons.sparkles),
              label: 'Waguri AI'),
        ],
      ),
    );
  }
}
