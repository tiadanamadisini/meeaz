import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/account.dart';
import '../models/money_transaction.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';

class AddTransactionScreen extends StatefulWidget {
  final MoneyTransaction? existing;
  final double? prefilledAmount;
  final String? prefilledCategory;
  final DateTime? prefilledDate;
  final String? prefilledNote;

  const AddTransactionScreen({
    super.key,
    this.existing,
    this.prefilledAmount,
    this.prefilledCategory,
    this.prefilledDate,
    this.prefilledNote,
  });

  @override
  State<AddTransactionScreen> createState() => _AddTransactionScreenState();
}

class _AddTransactionScreenState extends State<AddTransactionScreen> {
  final _formKey = GlobalKey<FormState>();
  late TxType _type;
  final _amountCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();
  final _customCategoryCtrl = TextEditingController();
  String? _category;
  String? _accountId;
  DateTime _date = DateTime.now();
  bool _useCustomCategory = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _type = e?.type ?? TxType.expense;
    
    if (e != null) {
      _amountCtrl.text = e.amount.toStringAsFixed(2);
      _noteCtrl.text = e.note ?? '';
      _category = e.category;
      _accountId = e.accountId;
      _date = e.date;
    } else {
      _amountCtrl.text = widget.prefilledAmount?.toStringAsFixed(2) ?? '';
      _noteCtrl.text = widget.prefilledNote ?? '';
      _category = widget.prefilledCategory;
      _date = widget.prefilledDate ?? DateTime.now();
    }

    if (_category != null && !defaultCategories.contains(_category)) {
      _useCustomCategory = true;
      _customCategoryCtrl.text = _category!;
    }

    // Auto-select first account if not prefilled
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_accountId == null && mounted) {
        final app = context.read<AppState>();
        if (app.accounts.isNotEmpty) {
          setState(() => _accountId = app.accounts.first.id);
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final isEdit = widget.existing != null;

    return Scaffold(
      appBar: AppBar(
        title: Text(isEdit ? 'Edit Transaksi' : 'Tambah Transaksi'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.brand),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: app.accounts.isEmpty
          ? const _NoAccountNotice()
          : Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  SegmentedButton<TxType>(
                    segments: const [
                      ButtonSegment(value: TxType.expense, label: Text('Belanja'), icon: Icon(Icons.remove)),
                      ButtonSegment(value: TxType.income, label: Text('Masuk'), icon: Icon(Icons.add)),
                    ],
                    selected: {_type},
                    onSelectionChanged: (s) => setState(() => _type = s.first),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _amountCtrl,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(labelText: 'Jumlah (RM)', prefixText: 'RM '),
                    validator: (v) {
                      final val = double.tryParse(v ?? '');
                      if (val == null || val <= 0) return 'Masukkan jumlah yang sah';
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  if (!_useCustomCategory)
                    DropdownButtonFormField<String>(
                      initialValue: defaultCategories.contains(_category) ? _category : null,
                      decoration: const InputDecoration(labelText: 'Kategori'),
                      items: defaultCategories
                          .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                          .toList(),
                      onChanged: (v) => setState(() => _category = v),
                      validator: (v) => v == null ? 'Pilih kategori' : null,
                    )
                  else
                    TextFormField(
                      controller: _customCategoryCtrl,
                      decoration: const InputDecoration(labelText: 'Kategori kustom'),
                      validator: (v) => (v == null || v.trim().isEmpty) ? 'Masukkan nama kategori' : null,
                    ),
                  TextButton(
                    onPressed: () => setState(() => _useCustomCategory = !_useCustomCategory),
                    child: Text(_useCustomCategory ? 'Pilih dari senarai' : '+ Tambah kategori sendiri'),
                  ),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    initialValue: app.accounts.any((a) => a.id == _accountId) ? _accountId : null,
                    decoration: const InputDecoration(labelText: 'Akaun'),
                    items: app.accounts
                        .map((a) => DropdownMenuItem(value: a.id, child: Text('${a.name} (${a.type.label})')))
                        .toList(),
                    onChanged: (v) => setState(() => _accountId = v),
                    validator: (v) => v == null ? 'Pilih akaun' : null,
                  ),
                  const SizedBox(height: 16),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Tarikh'),
                    subtitle: Text('${_date.day}/${_date.month}/${_date.year}'),
                    trailing: const Icon(Icons.calendar_today, size: 18),
                    onTap: () async {
                      final picked = await showDatePicker(
                        context: context,
                        initialDate: _date,
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2100),
                      );
                      if (picked != null) setState(() => _date = picked);
                    },
                  ),
                  TextFormField(
                    controller: _noteCtrl,
                    decoration: const InputDecoration(labelText: 'Nota (opsional)'),
                  ),
                  const SizedBox(height: 24),
                  FilledButton(
                    onPressed: () => _submit(context),
                    style: FilledButton.styleFrom(backgroundColor: AppColors.brand),
                    child: Text(isEdit ? 'Simpan Perubahan' : 'Tambah Transaksi'),
                  ),
                ],
              ),
            ),
    );
  }

  Future<void> _submit(BuildContext context) async {
    if (!_formKey.currentState!.validate()) return;
    final app = context.read<AppState>();
    final amount = double.parse(_amountCtrl.text);
    final category = _useCustomCategory ? _customCategoryCtrl.text.trim() : _category!;

    try {
      if (widget.existing == null) {
        await app.addTransaction(
          accountId: _accountId!,
          type: _type,
          amount: amount,
          category: category,
          date: _date,
          note: _noteCtrl.text.trim(),
        );
      } else {
        await app.updateTransaction(widget.existing!.copyWith(
          accountId: _accountId,
          type: _type,
          amount: amount,
          category: category,
          date: _date,
          note: _noteCtrl.text.trim(),
        ));
      }
      if (context.mounted) Navigator.pop(context);
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Something went wrong. Please try again.')),
        );
      }
    }
  }
}

class _NoAccountNotice extends StatelessWidget {
  const _NoAccountNotice();
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.account_balance_wallet_outlined, size: 48, color: AppColors.brand),
            const SizedBox(height: 12),
            const Text('Sila cipta akaun dahulu (cth: Tunai, Bank) sebelum menambah transaksi.',
                textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: () => Navigator.pop(context),
              style: FilledButton.styleFrom(backgroundColor: AppColors.brand),
              child: const Text('Kembali'),
            ),
          ],
        ),
      ),
    );
  }
}
