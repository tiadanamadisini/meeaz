import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../services/calculation_engine.dart';
import '../theme/app_theme.dart';
import '../utils/formatters.dart';
import '../widgets/empty_state.dart';
import '../widgets/goal_progress_card.dart';
import 'create_goal_screen.dart';
import 'goal_detail_screen.dart';

class GoalsScreen extends StatelessWidget {
  const GoalsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final avg = CalculationEngine.averages(app.transactions);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Matlamat Simpanan'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.brand),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: app.goals.isEmpty
          ? EmptyState(
              icon: Icons.flag_outlined,
              message: 'Give your money a purpose.',
              actionLabel: '+ Create Goal',
              onAction: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateGoalScreen())),
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  color: Colors.grey.shade50,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Statistics', style: TextStyle(fontWeight: FontWeight.w600)),
                        const SizedBox(height: 8),
                        Text('Average monthly income: ${formatMoney(avg.avgIncome)}'),
                        Text('Average monthly expenses: ${formatMoney(avg.avgExpenses)}'),
                        Text('Average monthly savings: ${formatMoney(avg.avgSavings)}'),
                        const SizedBox(height: 4),
                        Text(
                          avg.daysOfData > 0
                              ? 'Average based on ${avg.daysOfData} days of data.'
                              : 'Not enough data yet.',
                          style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                ...app.goals.map((g) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: GoalProgressCard(
                        goal: g,
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => GoalDetailScreen(goal: g)),
                        ),
                      ),
                    )),
              ],
            ),
      floatingActionButton: app.goals.isEmpty
          ? null
          : FloatingActionButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateGoalScreen())),
              child: const Icon(Icons.add),
            ),
    );
  }
}
