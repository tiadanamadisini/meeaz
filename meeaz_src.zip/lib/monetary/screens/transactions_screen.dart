import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/money_transaction.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/empty_state.dart';
import '../widgets/transaction_tile.dart';
import 'add_transaction_screen.dart';
import 'scan_transaction_screen.dart';

enum _TypeFilter { all, income, expense }
enum _DateFilter { thisWeek, thisMonth, all }

class TransactionsScreen extends StatefulWidget {
  const TransactionsScreen({super.key});

  @override
  State<TransactionsScreen> createState() => _TransactionsScreenState();
}

class _TransactionsScreenState extends State<TransactionsScreen> {
  _TypeFilter _typeFilter = _TypeFilter.all;
  _DateFilter _dateFilter = _DateFilter.thisMonth;

  List<MoneyTransaction> _apply(List<MoneyTransaction> txs) {
    final now = DateTime.now();
    return txs.where((t) {
      final typeOk = switch (_typeFilter) {
        _TypeFilter.all => true,
        _TypeFilter.income => t.type == TxType.income,
        _TypeFilter.expense => t.type == TxType.expense,
      };
      final dateOk = switch (_dateFilter) {
        _DateFilter.all => true,
        _DateFilter.thisMonth => t.date.year == now.year && t.date.month == now.month,
        _DateFilter.thisWeek => now.difference(t.date).inDays <= 7 && t.date.isBefore(now.add(const Duration(days: 1))),
      };
      return typeOk && dateOk;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final filtered = _apply(app.transactions);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Rekod Transaksi'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.brand),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Column(
              children: [
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _chip('Semua', _typeFilter == _TypeFilter.all, () => setState(() => _typeFilter = _TypeFilter.all)),
                      _chip('Masuk', _typeFilter == _TypeFilter.income, () => setState(() => _typeFilter = _TypeFilter.income)),
                      _chip('Belanja', _typeFilter == _TypeFilter.expense, () => setState(() => _typeFilter = _TypeFilter.expense)),
                    ],
                  ),
                ),
                const SizedBox(height: 6),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _chip('Minggu ni', _dateFilter == _DateFilter.thisWeek, () => setState(() => _dateFilter = _DateFilter.thisWeek)),
                      _chip('Bulan ni', _dateFilter == _DateFilter.thisMonth, () => setState(() => _dateFilter = _DateFilter.thisMonth)),
                      _chip('Semua', _dateFilter == _DateFilter.all, () => setState(() => _dateFilter = _DateFilter.all)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: filtered.isEmpty
                ? EmptyState(
                    icon: Icons.receipt_long_outlined,
                    message: 'Mula catat transaksi pertama awak hari ini.',
                    actionLabel: '+ Tambah Transaksi',
                    onAction: () => _showAddOptions(context),
                  )
                : ListView.separated(
                    itemCount: filtered.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, i) {
                      final tx = filtered[i];
                      return TransactionTile(
                        tx: tx,
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => AddTransactionScreen(existing: tx)),
                        ),
                        onDelete: () => context.read<AppState>().deleteTransaction(tx.id),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddOptions(context),
        backgroundColor: AppColors.brand,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }

  void _showAddOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Tambah Transaksi',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: const CircleAvatar(
                backgroundColor: AppColors.brand,
                child: Icon(Icons.camera_alt_rounded, color: Colors.white),
              ),
              title: const Text('Scan Resit / Bil'),
              subtitle: const Text('Gunakan AI untuk baca bil secara automatik'),
              onTap: () {
                Navigator.pop(ctx);
                Navigator.push(context, MaterialPageRoute(builder: (_) => const ScanTransactionScreen()));
              },
            ),
            const Divider(),
            ListTile(
              leading: const CircleAvatar(
                backgroundColor: Colors.blueGrey,
                child: Icon(Icons.edit_note_rounded, color: Colors.white),
              ),
              title: const Text('Masukkan Manual'),
              subtitle: const Text('Taip butiran transaksi sendiri'),
              onTap: () {
                Navigator.pop(ctx);
                Navigator.push(context, MaterialPageRoute(builder: (_) => const AddTransactionScreen()));
              },
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  Widget _chip(String label, bool selected, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(label: Text(label), selected: selected, onSelected: (_) => onTap()),
    );
  }
}
