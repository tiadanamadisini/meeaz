import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../services/calculation_engine.dart';
import '../services/forex_graph_bridge.dart';
import '../theme/app_theme.dart';
import '../utils/formatters.dart';
import '../widgets/balance_card.dart';
import '../widgets/charts/category_donut_chart.dart';
import '../widgets/charts/goal_progress_chart.dart';
import '../widgets/charts/income_expense_bar_chart.dart';
import '../widgets/charts/savings_trend_chart.dart';
import '../widgets/dashboard_section.dart';
import '../widgets/empty_state.dart';
import '../widgets/stat_card.dart';
import 'add_transaction_screen.dart';
import 'scan_transaction_screen.dart';
import 'create_goal_screen.dart';
import 'goal_detail_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final now = DateTime.now();

    // ---- Core numbers (this month) ----
    final income = app.monthlyIncome(now);
    final expenses = app.monthlyExpenses(now);
    final saved = CalculationEngine.savings(income, expenses);
    final rate = CalculationEngine.savingsRate(saved, income);
    final categories = CalculationEngine.categoryTotals(app.transactions, now);

    // ---- 6-month history, feeds Graf 2 (bar) and Graf 3 (line) ----
    final history =
        CalculationEngine.monthlyHistory(app.transactions, months: 6, now: now);
    final savingsPoints = [
      for (final h in history) (month: h.month, savings: h.income - h.expenses),
    ];

    // ---- Averages, feeds Graf 4 (goal actual vs required) ----
    final avg = CalculationEngine.averages(app.transactions, now: now);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Waguri Track Monetary'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              color: AppColors.brand),
          onPressed: () => Navigator.of(context, rootNavigator: true).pop(),
          tooltip: 'Kembali ke Utama',
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.show_chart_rounded),
            tooltip: 'Buka graf Forex',
            onPressed: () => ForexGraphBridge.open(context),
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => app.load(),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
          children: [
            // ---- Balance ----
            BalanceCard(balance: app.totalBalance),
            const SizedBox(height: AppSpacing.lg),
            Text(formatMonthYear(now),
                style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: AppSpacing.md),

            // ---- Quick stats (2x2 grid) ----
            Row(
              children: [
                Expanded(
                  child: StatCard(
                    icon: Icons.south_west_rounded,
                    label: 'Pendapatan',
                    value: formatMoney(income),
                    accent: AppColors.income,
                  ),
                ),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: StatCard(
                    icon: Icons.north_east_rounded,
                    label: 'Perbelanjaan',
                    value: formatMoney(expenses),
                    accent: AppColors.expense,
                  ),
                ),
              ],
            ),
            Divider(
                height: 1, color: Theme.of(context).colorScheme.outlineVariant),
            const SizedBox(height: AppSpacing.md),
            Row(
              children: [
                Expanded(
                  child: StatCard(
                    icon: Icons.savings_rounded,
                    label: 'Simpanan',
                    value: formatMoney(saved),
                    accent: AppColors.savings,
                  ),
                ),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: StatCard(
                    icon: Icons.percent_rounded,
                    label: 'Kadar Simpanan',
                    value: '${rate.toStringAsFixed(0)}%',
                    accent: AppColors.brand,
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.xxl),

            // ---- Graf 1: Spending by Category (Donut) ----
            DashboardSection(
              title: 'Belanja Ikut Kategori',
              subtitle: 'Ke mana duit awak pergi bulan ni',
              child: CategoryDonutChart(categories: categories),
            ),
            const SizedBox(height: AppSpacing.lg),

            // ---- Graf 2: Income vs Expenses (Bar) ----
            DashboardSection(
              title: 'Pendapatan vs Perbelanjaan',
              subtitle: '6 bulan kebelakangan',
              child: IncomeExpenseBarChart(data: history),
            ),
            const SizedBox(height: AppSpacing.lg),

            // ---- Graf 3: Savings Trend (Line) ----
            DashboardSection(
              title: 'Trend Simpanan',
              subtitle: 'Simpanan bulan demi bulan',
              child: SavingsTrendChart(points: savingsPoints),
            ),
            const SizedBox(height: AppSpacing.lg),

            // ---- Graf 4: Goal Progress (Ring + Actual vs Required) ----
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Matlamat Semasa',
                    style: Theme.of(context).textTheme.titleMedium),
                if (app.goals.isNotEmpty)
                  TextButton(
                    onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const CreateGoalScreen())),
                    child: const Text('+ Baru'),
                  ),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            if (app.goals.isEmpty)
              EmptyState(
                icon: Icons.flag_outlined,
                message: 'Berikan duit awak tujuan yang bermakna.',
                actionLabel: '+ Cipta Matlamat',
                onAction: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const CreateGoalScreen())),
              )
            else
              Padding(
                padding: const EdgeInsets.symmetric(vertical: AppSpacing.md),
                child: GoalProgressChart(
                  goal: app.goals.first,
                  averageMonthlySavings: avg.avgSavings,
                  daysOfData: avg.daysOfData,
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) =>
                            GoalDetailScreen(goal: app.goals.first)),
                  ),
                ),
              ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddOptions(context),
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('Tambah Transaksi',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
    );
  }

  void _showAddOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Tambah Transaksi',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: const CircleAvatar(
                backgroundColor: AppColors.brand,
                child: Icon(Icons.camera_alt_rounded, color: Colors.white),
              ),
              title: const Text('Scan Resit / Bil'),
              subtitle:
                  const Text('Gunakan AI untuk baca bil secara automatik'),
              onTap: () {
                Navigator.pop(ctx);
                _scanBill(context);
              },
            ),
            const Divider(),
            ListTile(
              leading: const CircleAvatar(
                backgroundColor: Colors.blueGrey,
                child: Icon(Icons.edit_note_rounded, color: Colors.white),
              ),
              title: const Text('Masukkan Manual'),
              subtitle: const Text('Taip butiran transaksi sendiri'),
              onTap: () {
                Navigator.pop(ctx);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const AddTransactionScreen()));
              },
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  Future<void> _scanBill(BuildContext context) async {
    Navigator.push(context,
        MaterialPageRoute(builder: (_) => const ScanTransactionScreen()));
  }
}
