import 'package:flutter/material.dart';
import '../models/money_transaction.dart';
import '../utils/formatters.dart';

class TransactionTile extends StatelessWidget {
  final MoneyTransaction tx;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  const TransactionTile({super.key, required this.tx, required this.onTap, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    final isIncome = tx.type == TxType.income;
    return Dismissible(
      key: ValueKey(tx.id),
      direction: DismissDirection.endToStart,
      background: Container(
        color: Colors.red.shade400,
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: const Icon(Icons.delete, color: Colors.white),
      ),
      confirmDismiss: (_) async {
        onDelete();
        return true;
      },
      child: ListTile(
        onTap: onTap,
        leading: CircleAvatar(
          backgroundColor: isIncome ? Colors.green.shade50 : Colors.red.shade50,
          child: Icon(
            isIncome ? Icons.arrow_downward : Icons.arrow_upward,
            color: isIncome ? Colors.green : Colors.red,
            size: 20,
          ),
        ),
        title: Text(tx.category),
        subtitle: Text(tx.note.isEmpty ? formatDate(tx.date) : '${formatDate(tx.date)} · ${tx.note}'),
        trailing: Text(
          isIncome ? formatSignedMoney(tx.amount) : formatSignedMoney(-tx.amount),
          style: TextStyle(
            color: isIncome ? Colors.green.shade700 : Colors.red.shade700,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}
