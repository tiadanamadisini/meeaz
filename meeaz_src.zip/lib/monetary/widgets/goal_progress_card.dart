import 'package:flutter/material.dart';
import '../models/goal.dart';
import '../services/calculation_engine.dart';
import '../utils/formatters.dart';

class GoalProgressCard extends StatelessWidget {
  final Goal goal;
  final VoidCallback? onTap;

  const GoalProgressCard({super.key, required this.goal, this.onTap});

  @override
  Widget build(BuildContext context) {
    final progress = CalculationEngine.goalProgressPercent(goal) / 100;
    final required = CalculationEngine.requiredMonthlySaving(goal);

    return Card(
      margin: EdgeInsets.zero,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(goal.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              Text(
                '${formatMoney(goal.currentAmount)} / ${formatMoney(goal.targetAmount)}',
                style: TextStyle(color: Colors.grey.shade700),
              ),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: LinearProgressIndicator(value: progress, minHeight: 8),
              ),
              const SizedBox(height: 6),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('${(progress * 100).toStringAsFixed(0)}%'),
                  Text('Sasaran: ${formatDate(goal.targetDate)}', style: const TextStyle(fontSize: 12)),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                'Simpanan perlu: ${formatMoney(required)}/bulan',
                style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
