import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../models/goal.dart';
import '../../services/calculation_engine.dart';
import '../../theme/app_theme.dart';
import '../../utils/formatters.dart';
import '../dashboard_section.dart';

/// Graf 4 — Goal Progress (Progress Ring + Actual vs Required)
///
/// Answers two questions at once: "how far am I?" (the ring, e.g. 60%)
/// and "am I on pace?" (actual average monthly savings vs. the monthly
/// amount actually required to hit the target date).
class GoalProgressChart extends StatelessWidget {
  final Goal goal;
  final double averageMonthlySavings;
  final int daysOfData;
  final VoidCallback? onTap;

  const GoalProgressChart({
    super.key,
    required this.goal,
    required this.averageMonthlySavings,
    required this.daysOfData,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final progressPct = CalculationEngine.goalProgressPercent(goal) / 100;
    final required = CalculationEngine.requiredMonthlySaving(goal);
    final status = CalculationEngine.goalStatus(
      requiredMonthly: required,
      averageMonthlySavings: averageMonthlySavings,
      daysOfData: daysOfData,
    );

    final (chipLabel, chipColor, chipBg, chipIcon) = switch (status) {
      GoalStatus.onTrack => (
          'Pada Landasan',
          AppColors.income,
          AppColors.income.withValues(alpha: 0.14),
          Icons.trending_up_rounded
        ),
      GoalStatus.needsAdjustment => (
          'Perlu Tingkatkan Simpanan',
          AppColors.warning,
          AppColors.warning.withValues(alpha: 0.14),
          Icons.priority_high_rounded
        ),
      GoalStatus.unknown => (
          'Data Belum Cukup',
          colors.onSurfaceVariant,
          colors.surfaceContainerHighest,
          Icons.hourglass_bottom_rounded
        ),
    };

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppRadius.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                SizedBox(
                  width: 76,
                  height: 76,
                  child: CustomPaint(
                    painter: _RingPainter(
                      progress: progressPct,
                      trackColor: colors.outlineVariant,
                      progressColor: colors.primary,
                    ),
                    child: Center(
                      child: Text(
                        '${(progressPct * 100).toStringAsFixed(0)}%',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: AppSpacing.lg),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(goal.name,
                          style: Theme.of(context).textTheme.titleMedium,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 4),
                      Text(
                        '${formatMoney(goal.currentAmount)} / ${formatMoney(goal.targetAmount)}',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                      const SizedBox(height: 8),
                      StatusChip(
                          label: chipLabel,
                          color: chipColor,
                          background: chipBg,
                          icon: chipIcon),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.xl),
            Text(
              'Purata Sebenar vs Diperlukan / bulan',
              style: Theme.of(context)
                  .textTheme
                  .bodySmall
                  ?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: AppSpacing.md),
            _CompareBar(
              label: 'Diperlukan',
              value: required,
              maxValue: math.max(required, averageMonthlySavings),
              color: colors.primary,
              trackColor: colors.surfaceContainerHighest,
            ),
            const SizedBox(height: AppSpacing.sm),
            _CompareBar(
              label: 'Sebenar',
              value: averageMonthlySavings,
              maxValue: math.max(required, averageMonthlySavings),
              color: averageMonthlySavings >= required
                  ? AppColors.income
                  : AppColors.warning,
              trackColor: colors.surfaceContainerHighest,
            ),
          ],
        ),
      ),
    );
  }
}

class _CompareBar extends StatelessWidget {
  final String label;
  final double value;
  final double maxValue;
  final Color color;
  final Color trackColor;

  const _CompareBar(
      {required this.label,
      required this.value,
      required this.maxValue,
      required this.color,
      required this.trackColor});

  @override
  Widget build(BuildContext context) {
    final ratio =
        maxValue <= 0 ? 0.0 : (value / maxValue).clamp(0.0, 1.0).toDouble();
    return Row(
      children: [
        SizedBox(
          width: 66,
          child: Text(label,
              style: Theme.of(context)
                  .textTheme
                  .bodyMedium
                  ?.copyWith(fontWeight: FontWeight.w600)),
        ),
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(AppRadius.pill),
            child: LinearProgressIndicator(
              value: ratio,
              minHeight: 10,
              backgroundColor: trackColor,
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
        ),
        const SizedBox(width: 8),
        SizedBox(
          width: 76,
          child: Text(
            formatMoney(value),
            textAlign: TextAlign.right,
            style: Theme.of(context)
                .textTheme
                .bodySmall
                ?.copyWith(fontWeight: FontWeight.w700),
          ),
        ),
      ],
    );
  }
}

class _RingPainter extends CustomPainter {
  final double progress;
  final Color trackColor;
  final Color progressColor;
  static const _stroke = 8.0;

  _RingPainter(
      {required this.progress,
      required this.trackColor,
      required this.progressColor});

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = (math.min(size.width, size.height) - _stroke) / 2;
    final rect = Rect.fromCircle(center: center, radius: radius);

    canvas.drawArc(
      rect,
      0,
      2 * math.pi,
      false,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = _stroke
        ..color = trackColor,
    );

    canvas.drawArc(
      rect,
      -math.pi / 2,
      2 * math.pi * progress.clamp(0.0, 1.0).toDouble(),
      false,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeWidth = _stroke
        ..color = progressColor,
    );
  }

  @override
  bool shouldRepaint(covariant _RingPainter oldDelegate) =>
      oldDelegate.progress != progress ||
      oldDelegate.trackColor != trackColor ||
      oldDelegate.progressColor != progressColor;
}
