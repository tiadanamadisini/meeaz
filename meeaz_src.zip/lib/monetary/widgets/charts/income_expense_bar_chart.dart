import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../theme/app_theme.dart';

/// Graf 2 — Income vs Expenses (Bar Chart)
///
/// One grouped pair of bars per month so the user can instantly see which
/// month their spending overtook their income (that month's expense bar
/// turns into the warning color as a visual flag).
class IncomeExpenseBarChart extends StatelessWidget {
  final List<({DateTime month, double income, double expenses})> data;

  const IncomeExpenseBarChart({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    final maxVal = data.fold<double>(
      0,
      (m, d) => [m, d.income, d.expenses].reduce((a, b) => a > b ? a : b),
    );

    if (maxVal <= 0) {
      return SizedBox(
        height: 120,
        child: Center(
          child: Text('Belum ada transaksi untuk dipaparkan.',
              style: Theme.of(context).textTheme.bodySmall),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const LegendDotInline(color: AppColors.income, label: 'Pendapatan'),
            const SizedBox(width: 16),
            const LegendDotInline(
                color: AppColors.expense, label: 'Perbelanjaan'),
            const SizedBox(width: 16),
            LegendDotInline(
              color: AppColors.warning,
              label: 'Lebih Belanja',
              textColor: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ],
        ),
        const SizedBox(height: AppSpacing.lg),
        SizedBox(
          height: 170,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              for (final d in data)
                Expanded(
                  child: _MonthBars(
                    income: d.income,
                    expenses: d.expenses,
                    maxVal: maxVal,
                    monthLabel: DateFormat('MMM').format(d.month),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _MonthBars extends StatelessWidget {
  final double income;
  final double expenses;
  final double maxVal;
  final String monthLabel;

  const _MonthBars({
    required this.income,
    required this.expenses,
    required this.maxVal,
    required this.monthLabel,
  });

  @override
  Widget build(BuildContext context) {
    final over = expenses > income && income > 0;
    const chartHeight = 140.0;
    final incomeH = maxVal <= 0 ? 0.0 : (income / maxVal) * chartHeight;
    final expenseH = maxVal <= 0 ? 0.0 : (expenses / maxVal) * chartHeight;

    return Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        SizedBox(
          height: chartHeight,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              _Bar(height: incomeH, color: AppColors.income),
              const SizedBox(width: 4),
              _Bar(
                  height: expenseH,
                  color: over ? AppColors.warning : AppColors.expense),
            ],
          ),
        ),
        const SizedBox(height: 6),
        Text(
          monthLabel,
          style: TextStyle(
            fontSize: 11,
            fontWeight: over ? FontWeight.w800 : FontWeight.w600,
            color: over
                ? AppColors.warning
                : Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }
}

class _Bar extends StatelessWidget {
  final double height;
  final Color color;
  const _Bar({required this.height, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 9,
      height: height < 2 ? 2 : height,
      decoration: BoxDecoration(
        color: color,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(3)),
      ),
    );
  }
}

/// Small inline legend dot (kept local to bar/line charts that don't use
/// the DashboardSection LegendDot's default text style sizing).
class LegendDotInline extends StatelessWidget {
  final Color color;
  final String label;
  final Color? textColor;
  const LegendDotInline(
      {super.key, required this.color, required this.label, this.textColor});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
        const SizedBox(width: 6),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                fontWeight: FontWeight.w600,
                color:
                    textColor ?? Theme.of(context).colorScheme.onSurfaceVariant,
              ),
        ),
      ],
    );
  }
}
