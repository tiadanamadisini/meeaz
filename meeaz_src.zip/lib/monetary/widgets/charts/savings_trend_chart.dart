import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../theme/app_theme.dart';
import '../../utils/formatters.dart';

/// Graf 3 — Savings Trend (Line Chart)
///
/// Plots month-by-month savings (income - expenses) so the user sees the
/// *shape* of their progress — climbing, dipping, recovering — instead of
/// a single flat "Savings = RMxxx" number.
class SavingsTrendChart extends StatelessWidget {
  final List<({DateTime month, double savings})> points;

  const SavingsTrendChart({super.key, required this.points});

  @override
  Widget build(BuildContext context) {
    if (points.isEmpty || points.every((p) => p.savings == 0)) {
      return SizedBox(
        height: 120,
        child: Center(
          child: Text('Belum cukup data untuk trend simpanan.',
              style: Theme.of(context).textTheme.bodySmall),
        ),
      );
    }

    final values = points.map((p) => p.savings).toList();
    final maxV = values.reduce((a, b) => a > b ? a : b);
    final minV = values.reduce((a, b) => a < b ? a : b);
    final last = points.last;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              formatMoney(last.savings),
              style: Theme.of(context)
                  .textTheme
                  .titleLarge
                  ?.copyWith(color: AppColors.savings),
            ),
            const SizedBox(width: 8),
            Padding(
              padding: const EdgeInsets.only(bottom: 3),
              child: Text('bulan ini',
                  style: Theme.of(context).textTheme.bodySmall),
            ),
          ],
        ),
        const SizedBox(height: AppSpacing.lg),
        SizedBox(
          height: 140,
          child: CustomPaint(
            size: Size.infinite,
            painter: _LineChartPainter(
              values: values,
              maxV: maxV,
              minV: minV,
              trackColor: Theme.of(context).colorScheme.outlineVariant,
              surfaceColor: Theme.of(context).colorScheme.surface,
            ),
          ),
        ),
        const SizedBox(height: AppSpacing.sm),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            for (final p in points)
              Text(DateFormat('MMM').format(p.month),
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall
                      ?.copyWith(fontWeight: FontWeight.w600)),
          ],
        ),
      ],
    );
  }
}

class _LineChartPainter extends CustomPainter {
  final List<double> values;
  final double maxV;
  final double minV;
  final Color trackColor;
  final Color surfaceColor;

  _LineChartPainter(
      {required this.values,
      required this.maxV,
      required this.minV,
      required this.trackColor,
      required this.surfaceColor});

  @override
  void paint(Canvas canvas, Size size) {
    final n = values.length;
    if (n == 0) return;

    // Vertical range always includes zero so a dip below zero is visible.
    final rangeMax = maxV <= 0 ? 1.0 : maxV;
    final rangeMin = minV >= 0 ? 0.0 : minV;
    final span = (rangeMax - rangeMin) == 0 ? 1.0 : (rangeMax - rangeMin);

    final dx = n <= 1 ? 0.0 : size.width / (n - 1);
    Offset pointAt(int i) {
      final x = dx * i;
      final t = (values[i] - rangeMin) / span; // 0..1
      final y = size.height - (t * size.height);
      return Offset(x, y.clamp(0.0, size.height).toDouble());
    }

    final points = List.generate(n, pointAt);

    // Zero baseline (dashed) when the series dips negative.
    if (rangeMin < 0) {
      final zeroY = size.height - (((0 - rangeMin) / span) * size.height);
      final dashPaint = Paint()
        ..color = trackColor
        ..strokeWidth = 1;
      const dashWidth = 4.0, dashGap = 4.0;
      double startX = 0;
      while (startX < size.width) {
        canvas.drawLine(Offset(startX, zeroY),
            Offset(startX + dashWidth, zeroY), dashPaint);
        startX += dashWidth + dashGap;
      }
    }

    // Gradient fill under the line down to the baseline.
    final baselineY = rangeMin < 0
        ? size.height - (((0 - rangeMin) / span) * size.height)
        : size.height;
    final fillPath = Path()..moveTo(points.first.dx, baselineY);
    for (final p in points) {
      fillPath.lineTo(p.dx, p.dy);
    }
    fillPath.lineTo(points.last.dx, baselineY);
    fillPath.close();
    final fillPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          AppColors.savings.withValues(alpha: 0.22),
          AppColors.savings.withValues(alpha: 0.0)
        ],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawPath(fillPath, fillPaint);

    // The line itself.
    final linePath = Path()..moveTo(points.first.dx, points.first.dy);
    for (var i = 1; i < points.length; i++) {
      final prev = points[i - 1];
      final curr = points[i];
      final midX = (prev.dx + curr.dx) / 2;
      linePath.cubicTo(midX, prev.dy, midX, curr.dy, curr.dx, curr.dy);
    }
    final linePaint = Paint()
      ..color = AppColors.savings
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(linePath, linePaint);

    // Dots at each point; last one emphasized.
    for (var i = 0; i < points.length; i++) {
      final isLast = i == points.length - 1;
      final r = isLast ? 5.0 : 3.0;
      canvas.drawCircle(points[i], r, Paint()..color = surfaceColor);
      canvas.drawCircle(
        points[i],
        r,
        Paint()
          ..color = AppColors.savings
          ..style = PaintingStyle.stroke
          ..strokeWidth = isLast ? 2.5 : 2,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _LineChartPainter oldDelegate) =>
      oldDelegate.values != values ||
      oldDelegate.maxV != maxV ||
      oldDelegate.minV != minV ||
      oldDelegate.trackColor != trackColor ||
      oldDelegate.surfaceColor != surfaceColor;
}
