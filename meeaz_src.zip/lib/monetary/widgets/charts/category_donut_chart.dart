import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../utils/formatters.dart';

/// Graf 1 — Spending by Category (Donut Chart)
///
/// Shows where money actually goes this month, at a glance: a ring split
/// into one arc per category, with total spend in the center and a legend
/// (color, name, % share, amount) on the side.
class CategoryDonutChart extends StatelessWidget {
  final List<MapEntry<String, double>> categories;

  const CategoryDonutChart({super.key, required this.categories});

  @override
  Widget build(BuildContext context) {
    final total = categories.fold<double>(0, (s, c) => s + c.value);

    if (categories.isEmpty || total <= 0) {
      return SizedBox(
        height: 120,
        child: Center(
          child: Text('Belum ada belanja bulan ni.',
              style: Theme.of(context).textTheme.bodySmall),
        ),
      );
    }

    final slices = <_Slice>[
      for (var i = 0; i < categories.length; i++)
        _Slice(
          label: categories[i].key,
          value: categories[i].value,
          color:
              AppColors.categoryPalette[i % AppColors.categoryPalette.length],
        ),
    ];

    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        SizedBox(
          width: 128,
          height: 128,
          child: CustomPaint(
            painter: _DonutPainter(
              slices: slices,
              total: total,
              trackColor: Theme.of(context).colorScheme.outlineVariant,
            ),
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    formatMoney(total),
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 2),
                  Text('Jumlah', style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: AppSpacing.xl),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              for (final s in slices) _LegendRow(slice: s, total: total),
            ],
          ),
        ),
      ],
    );
  }
}

class _Slice {
  final String label;
  final double value;
  final Color color;
  _Slice({required this.label, required this.value, required this.color});
}

class _LegendRow extends StatelessWidget {
  final _Slice slice;
  final double total;
  const _LegendRow({required this.slice, required this.total});

  @override
  Widget build(BuildContext context) {
    final pct = total <= 0 ? 0.0 : (slice.value / total) * 100;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Container(
              width: 8,
              height: 8,
              decoration:
                  BoxDecoration(color: slice.color, shape: BoxShape.circle)),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              slice.label,
              style: Theme.of(context)
                  .textTheme
                  .bodyMedium
                  ?.copyWith(fontWeight: FontWeight.w600),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Text(
            '${pct.toStringAsFixed(0)}%',
            style: Theme.of(context)
                .textTheme
                .bodySmall
                ?.copyWith(fontWeight: FontWeight.w700),
          ),
        ],
      ),
    );
  }
}

class _DonutPainter extends CustomPainter {
  final List<_Slice> slices;
  final double total;
  final Color trackColor;
  static const _strokeWidth = 16.0;
  static const _gapRad = 0.045;

  _DonutPainter(
      {required this.slices, required this.total, required this.trackColor});

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final radius = (math.min(size.width, size.height) - _strokeWidth) / 2;
    final center = rect.center;
    final arcRect = Rect.fromCircle(center: center, radius: radius);

    // Background track.
    final track = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = _strokeWidth
      ..color = trackColor;
    canvas.drawArc(arcRect, 0, 2 * math.pi, false, track);

    double start = -math.pi / 2;
    for (final s in slices) {
      final sweep = (s.value / total) * 2 * math.pi;
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = _strokeWidth
        ..strokeCap = StrokeCap.butt
        ..color = s.color;
      final drawSweep = math.max(sweep - _gapRad, 0.001);
      canvas.drawArc(arcRect, start, drawSweep, false, paint);
      start += sweep;
    }
  }

  @override
  bool shouldRepaint(covariant _DonutPainter oldDelegate) =>
      oldDelegate.slices != slices ||
      oldDelegate.total != total ||
      oldDelegate.trackColor != trackColor;
}
