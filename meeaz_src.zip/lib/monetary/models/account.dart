enum AccountType { cash, bank, ewallet, creditCard }

extension AccountTypeLabel on AccountType {
  String get label {
    switch (this) {
      case AccountType.cash:
        return 'Tunai';
      case AccountType.bank:
        return 'Bank';
      case AccountType.ewallet:
        return 'E-Wallet';
      case AccountType.creditCard:
        return 'Kad Kredit';
    }
  }
}

class Account {
  final String id;
  String name;
  AccountType type;
  double balance;

  Account({
    required this.id,
    required this.name,
    required this.type,
    required this.balance,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'type': type.name,
        'balance': balance,
      };

  factory Account.fromMap(Map<String, dynamic> map) => Account(
        id: map['id'] as String,
        name: map['name'] as String,
        type: AccountType.values.firstWhere(
          (t) => t.name == map['type'],
          orElse: () => AccountType.cash,
        ),
        balance: (map['balance'] as num).toDouble(),
      );
}
