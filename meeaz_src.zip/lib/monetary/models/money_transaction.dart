enum TxType { income, expense }

const List<String> defaultCategories = [
  'Makanan',
  'Pengangkutan',
  'Membeli-belah',
  'Bil',
  'Pendidikan',
  'Hiburan',
  'Kesihatan',
  'Keluarga',
  'Lain-lain',
];

class MoneyTransaction {
  final String id;
  final String accountId;
  final TxType type;
  final double amount;
  final String category;
  final DateTime date;
  final String note;

  MoneyTransaction({
    required this.id,
    required this.accountId,
    required this.type,
    required this.amount,
    required this.category,
    required this.date,
    this.note = '',
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'accountId': accountId,
        'type': type.name,
        'amount': amount,
        'category': category,
        'date': date.toIso8601String(),
        'note': note,
      };

  factory MoneyTransaction.fromMap(Map<String, dynamic> map) => MoneyTransaction(
        id: map['id'] as String,
        accountId: map['accountId'] as String,
        type: TxType.values.firstWhere(
          (t) => t.name == map['type'],
          orElse: () => TxType.expense,
        ),
        amount: (map['amount'] as num).toDouble(),
        category: map['category'] as String,
        date: DateTime.parse(map['date'] as String),
        note: (map['note'] as String?) ?? '',
      );

  MoneyTransaction copyWith({
    String? accountId,
    TxType? type,
    double? amount,
    String? category,
    DateTime? date,
    String? note,
  }) =>
      MoneyTransaction(
        id: id,
        accountId: accountId ?? this.accountId,
        type: type ?? this.type,
        amount: amount ?? this.amount,
        category: category ?? this.category,
        date: date ?? this.date,
        note: note ?? this.note,
      );
}
