import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';

class ImageService {
  static const String _gayaVisual =
      '2D anime illustration, clean line art, flat cel-shaded colours, '
      'expressive anime composition, natural proportions, clear subject '
      'separation, detailed but uncluttered background, soft even lighting, '
      'not 3D, not photorealistic, not a realistic photo.';

  Future<String?> generateImage(String arahanPengguna, {bool includeKaoruko = false, String? timeContext}) async {
    final backendUrl = dotenv.env['BACKEND_URL'] ?? 'http://localhost:3000';
    
    String promptGabungan = 'User image request: $arahanPengguna. ';
    
    if (includeKaoruko) {
      promptGabungan += 'Character: Kaoruko Waguri from "The Fragrant Flower Blooms with Dignity". '
          'Appearance: Long flowing black hair with blunt bangs, soft purple eyes, gentle and shy expression, '
          'wearing white Kikyo Girls Academy school sweater or modest casual clothes. ';
    }
    
    if (timeContext != null) {
      promptGabungan += 'Time-based Context: $timeContext. ';
    }
    
    promptGabungan += _gayaVisual;

    try {
      // Pollinations AI boleh dipanggil terus tanpa backend!
      final url = 'https://image.pollinations.ai/prompt/${Uri.encodeComponent(promptGabungan)}';
      final response = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 60));

      if (response.statusCode == 200) {
        return base64Encode(response.bodyBytes);
      } else {
        throw Exception('Ralat penjanaan imej: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Gagal jana gambar: $e');
    }
  }
}
