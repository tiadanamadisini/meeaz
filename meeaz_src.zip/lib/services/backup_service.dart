import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:share_plus/share_plus.dart';
import 'package:file_picker/file_picker.dart';

/// Servis untuk Export dan Import semua data aplikasi (Chat, Highlights, Profile, Tetapan).
class BackupService {
  static const List<String> _keysToBackup = [
    'kaoruko_chat_history',
    'home_highlights',
    'nama_pengguna',
    'gambar_pengguna',
    'kata_laluan',
    'dark_mode',
    'bahasa_aplikasi',
    'tutorial_sudah_dilihat',
    'last_morning_greeting',
    'last_night_greeting',
    'user_important_facts',
  ];

  /// Kumpul semua data dari SharedPreferences dan jana fail JSON untuk dikongsi.
  static Future<void> exportSemuaData() async {
    final prefs = await SharedPreferences.getInstance();
    final Map<String, dynamic> backupData = {};

    for (final key in _keysToBackup) {
      if (prefs.containsKey(key)) {
        final value = prefs.get(key);
        backupData[key] = value;
      }
    }

    final payload = {
      'app': 'MeeazProject',
      'version': '1.0.0',
      'timestamp': DateTime.now().toIso8601String(),
      'data': backupData,
    };

    final jsonString = jsonEncode(payload);
    final bytes = Uint8List.fromList(utf8.encode(jsonString));

    await Share.shareXFiles(
      [
        XFile.fromData(
          bytes,
          name: 'meeaz_backup_${DateTime.now().millisecondsSinceEpoch}.json',
          mimeType: 'application/json',
        ),
      ],
      text: 'Backup data Meeaz Project (Kaoruko Waguri)',
    );
  }

  /// Pilih fail JSON backup dan masukkan semula ke dalam SharedPreferences.
  static Future<bool> importSemuaData() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['json'],
      );

      if (result == null || result.files.isEmpty) return false;

      final file = result.files.first;
      final bytes = file.bytes ?? (file.path != null ? await File(file.path!).readAsBytes() : null);
      
      if (bytes == null) return false;

      final decoded = jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
      
      if (decoded['app'] != 'MeeazProject') {
        throw Exception('Fail ini bukan fail backup Meeaz Project yang sah.');
      }

      final data = decoded['data'] as Map<String, dynamic>;
      final prefs = await SharedPreferences.getInstance();

      // Clear data lama sebelum import (Optional, tapi lebih bersih)
      // await prefs.clear(); 

      for (final entry in data.entries) {
        final key = entry.key;
        final value = entry.value;

        if (value is String) {
          await prefs.setString(key, value);
        } else if (value is bool) {
          await prefs.setBool(key, value);
        } else if (value is int) {
          await prefs.setInt(key, value);
        } else if (value is double) {
          await prefs.setDouble(key, value);
        } else if (value is List) {
          await prefs.setStringList(key, value.cast<String>());
        }
      }

      return true;
    } catch (e) {
      rethrow;
    }
  }
}
