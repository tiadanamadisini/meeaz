import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:archive/archive.dart';
import 'package:xml/xml.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';

/// Hasil extract satu dokumen — nama fail + teks yang berjaya diambil.
class HasilDokumen {
  final String namaFail;
  final String teks;
  HasilDokumen({required this.namaFail, required this.teks});
}

/// Servis untuk pilih fail PDF/PPTX dari peranti dan extract teks
/// kandungan dia, supaya boleh dihantar sebagai konteks kepada AI.
class DocumentService {
  // Had panjang teks dihantar ke API — elak lebihi token limit &
  // memperlahankan respons untuk dokumen yang sangat panjang.
  static const int _hadAksara = 12000;

  /// Buka file picker, pengguna pilih 1 fail PDF/PPTX. Pulangkan null
  /// kalau pengguna batal pilih.
  Future<HasilDokumen?> pilihDanExtract() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'pptx'],
      withData: true,
    );

    if (result == null || result.files.isEmpty) return null;

    final fail = result.files.first;
    final namaFail = fail.name;
    final bytes = fail.bytes ??
        (fail.path != null ? await File(fail.path!).readAsBytes() : null);

    if (bytes == null) {
      throw Exception('Tidak dapat membaca fail "$namaFail".');
    }

    final extension = namaFail.split('.').last.toLowerCase();

    String teksMentah;
    if (extension == 'pdf') {
      teksMentah = _extractPdf(bytes);
    } else if (extension == 'pptx') {
      teksMentah = _extractPptx(bytes);
    } else {
      throw Exception('Jenis fail tidak disokong. Guna PDF atau PPTX sahaja.');
    }

    final teksBersih = teksMentah.trim();
    if (teksBersih.isEmpty) {
      throw Exception(
          'Tiada teks dapat diambil dari "$namaFail" (mungkin dokumen imej/scan sahaja).');
    }

    final teksDipotong = teksBersih.length > _hadAksara
        ? '${teksBersih.substring(0, _hadAksara)}\n\n[...dipotong, dokumen terlalu panjang...]'
        : teksBersih;

    return HasilDokumen(namaFail: namaFail, teks: teksDipotong);
  }

  // ---------------- PDF ----------------
  String _extractPdf(List<int> bytes) {
    PdfDocument document;
    try {
      document = PdfDocument(inputBytes: bytes);
    } catch (e) {
      // Jika fail dilindungi kata laluan, Syncfusion akan melontar ralat.
      // Di sini kita boleh kembangkan untuk minta password daripada pengguna.
      throw Exception('Fail PDF mungkin dilindungi kata laluan atau rosak.');
    }
    
    final buffer = StringBuffer();
    try {
      for (int i = 0; i < document.pages.count; i++) {
        final teksMukaSurat =
            PdfTextExtractor(document).extractText(startPageIndex: i);
        buffer.writeln(teksMukaSurat);
      }
    } finally {
      document.dispose();
    }
    return buffer.toString();
  }

  // ---------------- PPTX ----------------
  // PPTX sebenarnya fail ZIP yang mengandungi XML untuk setiap slide di
  // ppt/slides/slideN.xml. Kita extract semua teks dalam tag <a:t>.
  String _extractPptx(List<int> bytes) {
    final archive = ZipDecoder().decodeBytes(bytes);
    final buffer = StringBuffer();

    // Susun ikut nombor slide (slide1.xml, slide2.xml, ...) supaya
    // teks keluar dalam urutan yang betul.
    final slideFiles = archive.files
        .where((f) =>
            f.name.startsWith('ppt/slides/slide') && f.name.endsWith('.xml'))
        .toList()
      ..sort((a, b) {
        final numA = int.tryParse(
                RegExp(r'slide(\d+)\.xml').firstMatch(a.name)?.group(1) ??
                    '0') ??
            0;
        final numB = int.tryParse(
                RegExp(r'slide(\d+)\.xml').firstMatch(b.name)?.group(1) ??
                    '0') ??
            0;
        return numA.compareTo(numB);
      });

    int slideKe = 0;
    for (final file in slideFiles) {
      slideKe++;
      final content = file.content as List<int>;
      final xmlString = String.fromCharCodes(content);

      try {
        final document = XmlDocument.parse(xmlString);
        final teksElemen = document.findAllElements('a:t');
        final teksSlide =
            teksElemen.map((e) => e.innerText).where((t) => t.trim().isNotEmpty);

        if (teksSlide.isNotEmpty) {
          buffer.writeln('--- Slaid $slideKe ---');
          buffer.writeln(teksSlide.join(' '));
          buffer.writeln();
        }
      } catch (_) {
        // Slaid rosak/tak boleh parse — skip, teruskan ke slaid seterusnya.
        continue;
      }
    }

    return buffer.toString();
  }
}
