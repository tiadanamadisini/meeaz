import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/message.dart';
import 'chat_service.dart';

class MemoryService {
  static const String _factsKey = 'user_important_facts';
  static final MemoryService _instance = MemoryService._internal();
  factory MemoryService() => _instance;
  MemoryService._internal();

  /// Mengambil fakta yang disimpan mengenai pengguna.
  Future<String> getFacts() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_factsKey) ?? 'Tiada maklumat khusus mengenai pengguna lagi.';
  }

  /// Menyimpan fakta ringkas mengenai pengguna.
  Future<void> saveFacts(String facts) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_factsKey, facts);
  }

  /// Menggunakan AI untuk mengekstrak fakta penting daripada perbualan terbaharu
  /// dan menggabungkannya dengan memori sedia ada secara ringkas.
  Future<void> extractAndSummarize(List<Message> recentMessages) async {
    if (recentMessages.isEmpty) return;

    final existingFacts = await getFacts();
    
    // Bina teks perbualan untuk dianalisis
    final conversation = recentMessages.map((m) => '${m.sender == Sender.user ? "User" : "Kaoruko"}: ${m.text}').join('\n');
    
    final prompt = '''
Sila ekstrak fakta baru yang penting tentang pengguna (rutin, minat, pilihan, maklumat peribadi) daripada perbualan di bawah.
Kemudian, kemas kini senarai fakta sedia ada dengan menggabungkan maklumat baru ini.
Pastikan hasil akhir adalah ringkas, padat (dalam bentuk bullet points atau perenggan pendek), dan tidak melebihi 250 patah perkataan.

FAKTA SEDIA ADA:
$existingFacts

PERBUALAN TERBAHARU:
$conversation

Keluarkan hasil akhir dalam Bahasa Melayu yang santai. Kemas kini sahaja, jangan buat intro.
''';

    try {
      // Gunakan ChatService untuk mendapatkan API Key yang betul (Rotation)
      final chatService = ChatService();
      final model = GenerativeModel(
        model: 'gemini-1.5-flash',
        apiKey: chatService.getNextKeyForMemory(),
      );

      final response = await model.generateContent([
        Content.text(prompt),
      ]);

      final newFacts = response.text;
      if (newFacts != null && newFacts.trim().isNotEmpty) {
        await saveFacts(newFacts.trim());
      }
    } catch (e) {
      // Abaikan ralat memori supaya tidak mengganggu user chat
    }
  }
}
