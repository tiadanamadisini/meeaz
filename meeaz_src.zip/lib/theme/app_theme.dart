import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  static const brand = Color(0xFFC97C6D);
  static const brandDark = Color(0xFFA85E50);
  static const brandSoft = Color(0xFFF3E2DD);
  static const background = Color(0xFFFBF8F6);
  static const surface = Color(0xFFFFFFFF);
  static const surfaceAlt = Color(0xFFF5F0ED);
  static const border = Color(0xFFE8DFDA);
  static const textPrimary = Color(0xFF2E2320);
  static const textSecondary = Color(0xFF746A65);
  static const textMuted = Color(0xFF9C928D);
  static const income = Color(0xFF2E7D5B);
  static const incomeSoft = Color(0xFFE1F0E9);
  static const expense = Color(0xFFD1665C);
  static const expenseSoft = Color(0xFFFAE4E2);
  static const savings = Color(0xFF3E6FA8);
  static const savingsSoft = Color(0xFFE3ECF6);
  static const warning = Color(0xFFC98A2E);
  static const warningSoft = Color(0xFFF7ECDA);

  static const List<Color> categoryPalette = [
    brand,
    savings,
    income,
    warning,
    Color(0xFF7C6FA8),
    Color(0xFF4FA3A0),
    Color(0xFFB5654F),
    textMuted,
  ];
}

class AppSpacing {
  AppSpacing._();

  static const xs = 4.0;
  static const sm = 8.0;
  static const md = 12.0;
  static const lg = 16.0;
  static const xl = 20.0;
  static const xxl = 28.0;
}

class AppRadius {
  AppRadius._();

  static const sm = 4.0;
  static const md = 6.0;
  static const lg = 8.0;
  static const pill = 999.0;
}

class AppTheme {
  AppTheme._();

  static ThemeData get theme => light;

  static ThemeData get light {
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.brand,
      brightness: Brightness.light,
    ).copyWith(
      primary: AppColors.brandDark,
      onPrimary: Colors.white,
      secondary: AppColors.income,
      surface: AppColors.surface,
      onSurface: AppColors.textPrimary,
      outline: AppColors.border,
    );

    return _build(scheme, AppColors.background, AppColors.textSecondary);
  }

  static ThemeData get dark {
    const background = Color(0xFF171514);
    const surface = Color(0xFF211D1B);
    const border = Color(0xFF39312D);
    const primaryText = Color(0xFFF4EEEA);
    const secondaryText = Color(0xFFB8AAA3);
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.brand,
      brightness: Brightness.dark,
    ).copyWith(
      primary: const Color(0xFFE0A092),
      onPrimary: const Color(0xFF321A15),
      secondary: const Color(0xFF82B89D),
      surface: surface,
      onSurface: primaryText,
      outline: border,
    );

    return _build(scheme, background, secondaryText);
  }

  static ThemeData _build(
    ColorScheme scheme,
    Color background,
    Color secondaryText,
  ) {
    const radius = BorderRadius.all(Radius.circular(AppRadius.lg));

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: background,
      splashFactory: InkRipple.splashFactory,
      visualDensity: VisualDensity.standard,
      appBarTheme: AppBarTheme(
        backgroundColor: background,
        foregroundColor: scheme.onSurface,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          color: scheme.onSurface,
          fontSize: 19,
          fontWeight: FontWeight.w700,
        ),
      ),
      cardTheme: CardThemeData(
        color: scheme.surface,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: radius,
          side: BorderSide(color: scheme.outlineVariant),
        ),
      ),
      textTheme: TextTheme(
        headlineLarge: TextStyle(
          color: scheme.onSurface,
          fontSize: 30,
          fontWeight: FontWeight.w800,
        ),
        headlineMedium: TextStyle(
          color: scheme.onSurface,
          fontSize: 26,
          fontWeight: FontWeight.w700,
        ),
        titleLarge: TextStyle(
          color: scheme.onSurface,
          fontSize: 20,
          fontWeight: FontWeight.w700,
        ),
        titleMedium: TextStyle(
          color: scheme.onSurface,
          fontSize: 16,
          fontWeight: FontWeight.w700,
        ),
        bodyLarge:
            TextStyle(color: scheme.onSurface, fontSize: 16, height: 1.4),
        bodyMedium:
            TextStyle(color: scheme.onSurface, fontSize: 14, height: 1.4),
        bodySmall: TextStyle(color: secondaryText, fontSize: 12, height: 1.35),
        labelLarge: TextStyle(
          color: scheme.onSurface,
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: scheme.surface,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        border: OutlineInputBorder(
          borderRadius: radius,
          borderSide: BorderSide(color: scheme.outline),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: radius,
          borderSide: BorderSide(color: scheme.outline),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: radius,
          borderSide: BorderSide(color: scheme.primary, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: radius,
          borderSide: BorderSide(color: scheme.error),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          minimumSize: const Size(48, 48),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
          shape: RoundedRectangleBorder(borderRadius: radius),
          textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size(48, 48),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
          shape: RoundedRectangleBorder(borderRadius: radius),
          textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(48, 48),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          shape: RoundedRectangleBorder(borderRadius: radius),
          side: BorderSide(color: scheme.outline),
          textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: scheme.surface,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        indicatorColor: scheme.primary.withValues(alpha: 0.12),
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return TextStyle(
            fontSize: 11,
            fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
            color: selected ? scheme.primary : secondaryText,
          );
        }),
      ),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: scheme.primary,
        foregroundColor: scheme.onPrimary,
        elevation: 1,
        shape: RoundedRectangleBorder(borderRadius: radius),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: radius),
      ),
      dividerTheme:
          DividerThemeData(color: scheme.outlineVariant, thickness: 1),
    );
  }
}
